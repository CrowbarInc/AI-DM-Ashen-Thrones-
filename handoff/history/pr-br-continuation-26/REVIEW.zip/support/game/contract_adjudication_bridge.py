"""Contract-first bridge for the unparsed adjudication arm.

Ordinary gameplay that reaches this arm already has an authoritative
Resolution Contract. Specialized resolvers are chosen from that contract.
They do not read a segmented trailing clause as a second semantic owner.

Category A exclusions are the only pre-contract routes this cycle leaves
alone. They are not chat sentences.
"""
from __future__ import annotations

import re
from typing import Any, Mapping

from game.adjudication import resolve_adjudication_query
from game.interaction_context import _looks_like_place_existence_question
from game.player_commitment import EXECUTED_NOW

# Named, enumerable, testable. A chat sentence is not on this list.
CATEGORY_A_EXCLUSIONS: tuple[dict[str, Any], ...] = (
    {
        "id": "session_administration",
        "entry": "HTTP session administration, not /api/chat",
        "examples": ("snapshot", "load", "reset", "new_campaign", "response_mode", "editors"),
    },
    {
        "id": "initiative_status_line",
        "entry": "api.action roll_initiative",
        "examples": ("roll_initiative",),
    },
    {
        "id": "end_turn_status_line",
        "entry": "api.action end_turn with no enemy",
        "examples": ("end_turn",),
    },
    {
        "id": "campaign_start_cue",
        "entry": "api._is_campaign_start_turn_request",
        "examples": ("start the campaign", "begin the campaign"),
    },
)

CATEGORY_A_IDS = tuple(row["id"] for row in CATEGORY_A_EXCLUSIONS)

RESOLVER_FAMILIES = (
    "earshot",
    "nearby_presence",
    "place_location",
    "feasibility",
    "state_query",
    "roll_mechanical",
    "generic_adjudication",
)

_SOCIAL_PRIMARY_RE = re.compile(
    r"\b(?:i\s+ask|ask\s+the|ask\s+(?:him|her|them|you)|have\s+you\s+heard|"
    r"did\s+you\s+hear|what\s+have\s+you\s+heard|thank\s+you|ask(?:s|ed|ing)?)\b",
    re.IGNORECASE,
)
_PRESENCE_RE = re.compile(
    r"\b(?:who(?:'s| is)\s+(?:nearby|here|around)|"
    r"anyone(?:\s+else)?\s+(?:nearby|here|around|in\s+earshot)|"
    r"in\s+earshot|who\s+can\s+hear|"
    r"listen(?:ing)?\s+for\s+anyone|"
    r"is\s+anyone(?:\s+else)?\s+(?:nearby|here|in\s+earshot))\b",
    re.IGNORECASE,
)
_PLACE_RE = re.compile(
    r"\b(?:supplies|shelter|tavern|inn|lodging)\b",
    re.IGNORECASE,
)
_ROLL_RE = re.compile(
    r"\b(?:sleight of hand|skill\s+check|saving\s+throw|\bdc\b|"
    r"need(?:ed)?\s+(?:to\s+)?(?:a\s+)?roll|roll\s+needed|does\s+this\s+need|"
    r"is\s+a\s+roll\s+needed|need\s+a\s+roll)\b",
    re.IGNORECASE,
)
_STATE_RE = re.compile(
    r"\b(?:what\s+actions?\s+are\s+available|where\s+is\s+my|what\s+is\s+my|how\s+many)\b",
    re.IGNORECASE,
)
_FEASIBILITY_RE = re.compile(
    r"\b(?:can\s+i|could\s+i|would\s+i|would\s+the|is\s+it\s+possible|how\s+far|distance|\barmed\b)\b",
    re.IGNORECASE,
)
_ATTACK_RE = re.compile(r"\b(?:attack|strike|stab|slash|smite)\b", re.IGNORECASE)
_TRAVEL_RE = re.compile(
    r"\b(?:go|walk|head|travel|leave|return)\b|\bfollow\s+the\s+(?:road|path|trail|way)\b",
    re.IGNORECASE,
)
# Adjudication families the contract may name. Selection reads this set.
# It does not rediscover the family from raw tokens.
_ADJUDICATION_SUBJECTS = frozenset(
    {
        "earshot",
        "nearby_presence",
        "place_location",
        "feasibility",
        "state_query",
        "roll_mechanical",
    }
)


def category_a_ids() -> tuple[str, ...]:
    return CATEGORY_A_IDS


def is_category_a(exclusion_id: str | None) -> bool:
    return str(exclusion_id or "").strip() in CATEGORY_A_IDS


def construction_source(contract: Mapping[str, Any] | None) -> str:
    """deterministic or structured_interpretation. Existing construction fields only."""
    construction = contract.get("construction") if isinstance(contract, Mapping) else None
    if not isinstance(construction, Mapping):
        return "deterministic"
    if (
        str(construction.get("proposal_source") or "") == "model_assisted"
        and not construction.get("model_proposal_rejected")
        and construction.get("model_interpreter_invoked")
    ):
        return "structured_interpretation"
    return "deterministic"


def contract_authorizes_specialized_resolution(contract: Mapping[str, Any] | None) -> bool:
    """True only when an ordinary-gameplay contract already exists."""
    if not isinstance(contract, Mapping):
        return False
    if not str(contract.get("contract_id") or "").strip():
        return False
    return bool(str(contract.get("operation") or "").strip())


def direct_feasibility_question(text: str | None) -> bool:
    """A modal possibility question, not an addressed social ask."""
    raw = str(text or "")
    if _explicit_social_address(raw):
        return False
    return bool(_FEASIBILITY_RE.search(raw) and "?" in raw)


def _explicit_social_address(raw: str) -> bool:
    """Speech addressed to someone. Place and combat words inside it are content."""
    if _SOCIAL_PRIMARY_RE.search(raw):
        return True
    return bool(
        re.search(
            r"\b(?:tell|order|command|speak(?:ing)?\s+to|talk(?:ing)?\s+to)\b",
            raw,
            re.IGNORECASE,
        )
    )


def derive_resolution_subject(
    text: str | None,
    *,
    operation: str,
    proposed_operation: str | None,
    commitment: str,
    dimension: str | None = None,
) -> str:
    """Name the resolution subject while the contract is being built.

    This is the interpretation step. After the contract exists, resolver
    selection reads ``construction.resolution_subject`` and does not run these
    checks again.
    """
    raw = str(text or "")
    operation = str(operation or "").strip().lower()
    proposed = str(proposed_operation or operation or "").strip().lower()
    commitment = str(commitment or "").strip()
    dimension = str(dimension or "").strip().lower()

    if _explicit_social_address(raw):
        return "social"
    # An uncommitted plan is not a place, presence, or feasibility question,
    # even when the plan mentions those words.
    if commitment != EXECUTED_NOW and "?" not in raw:
        if operation == "ask" or proposed in {"act", "follow", "ask"}:
            return "social" if operation == "ask" else "action"
        return "action"
    if operation in {"ask", "perceive", "inspect"}:
        presence = bool(_PRESENCE_RE.search(raw)) or (
            operation == "perceive" and dimension == "sound" and bool(re.search(r"\banyone\b", raw, re.IGNORECASE))
        )
        if presence:
            if re.search(r"\bearshot\b|\bwho can hear\b|\blisten", raw, re.IGNORECASE):
                return "earshot"
            return "nearby_presence"
    if operation == "ask" and (
        _PLACE_RE.search(raw) or _looks_like_place_existence_question(raw)
    ):
        return "place_location"
    if operation == "ask" and _ROLL_RE.search(raw):
        return "roll_mechanical"
    if operation == "ask" and _STATE_RE.search(raw):
        return "state_query"
    if operation == "ask" and _FEASIBILITY_RE.search(raw):
        return "feasibility"
    if operation in {"inspect", "perceive"}:
        return "perception"
    if operation in {"act", "follow", "confirm"} and commitment == EXECUTED_NOW:
        if _ATTACK_RE.search(raw):
            return "combat"
        from game.intent_parser import is_qualified_pursuit_shaped

        pursuit = is_qualified_pursuit_shaped(raw)
        if operation == "follow" or pursuit:
            if pursuit and not _TRAVEL_RE.search(raw):
                return "perception"
        if operation == "follow" or _TRAVEL_RE.search(raw):
            return "travel"
        return "world_action"
    if operation in {"ask", "repeat"}:
        return "social"
    return "unspecified"


def select_resolver_family(contract: Mapping[str, Any] | None) -> str | None:
    """Choose an adjudication family from the contract subject only.

    Raw player text is not read here. A missing subject selects nothing.
    """
    if not contract_authorizes_specialized_resolution(contract):
        return None
    assert isinstance(contract, Mapping)
    construction = contract.get("construction") if isinstance(contract.get("construction"), Mapping) else {}
    subject = str(construction.get("resolution_subject") or "").strip()
    if subject in _ADJUDICATION_SUBJECTS:
        return subject
    return None


def resolve_selected_family(
    family: str | None,
    contract: Mapping[str, Any] | None,
    *,
    scene: dict,
    session: dict,
    world: dict,
    character: dict,
    has_active_interaction: bool = False,
) -> dict | None:
    """Run one already-selected resolver. Refuses to run without a contract.

    The contract operation and addressee are not rewritten. A resolver that
    cannot answer returns None so the caller can use contract-aware generation
    or nonresolution.
    """
    if family not in RESOLVER_FAMILIES:
        return None
    if not contract_authorizes_specialized_resolution(contract):
        return None
    assert isinstance(contract, Mapping)
    construction = contract.get("construction") if isinstance(contract.get("construction"), Mapping) else {}
    subject = str(construction.get("resolution_subject") or "").strip()
    operation = str(contract.get("operation") or "").strip().lower()
    # A contract that already named a non-adjudication subject cannot be
    # overridden by a caller-supplied place, presence, or earshot family.
    if family in {"earshot", "nearby_presence", "place_location"} and (
        subject == "social" or (operation == "ask" and subject not in _ADJUDICATION_SUBJECTS)
    ):
        return None
    text = str(contract.get("raw_input") or "").strip()
    if not text:
        return None
    result = resolve_adjudication_query(
        text,
        scene=scene,
        session=session,
        world=world,
        character=character,
        has_active_interaction=has_active_interaction,
        resolver_family=family,
    )
    if not isinstance(result, dict):
        return None
    # The resolver reports facts. It does not replace the contract's operation.
    result = dict(result)
    result["resolver_family"] = family
    result["contract_id"] = str(contract.get("contract_id") or "")
    result["contract_operation"] = str(contract.get("operation") or "")
    result["contract_interlocutor_id"] = str(contract.get("interlocutor_id") or "")
    return result
