# NEXT_SESSION

Start here:

```text
Read docs/NEXT_SESSION.md and the authoritative documents it references before making changes.
```

## Project

Ashen Thrones

## Current Era

Product Realization

## Current Objective

Preserve the clean post-policy baseline. Do not begin Calibration Round #2, State ↔ Narration Consistency, simulated-player work, or new Product Realization features until this baseline is reviewed.

## Established Facts

- Architecture Reconciliation Era completed; Campaign 6 chassis closed (`AR-CA_campaign6_chassis_strategy_closeout.md`).
- A validation reliability crisis was discovered and the validation estate was rationalized.
- Known technical reds were cleaned. RC-11, RC-13, and GD-01 were resolved as expectation/governance maintenance, not product changes.
- Validation authority hierarchy:
  - structural PASS ≠ semantic playability
  - automated playability PASS = SUPPORTING_EVIDENCE
  - behavioral gauntlets = DIAGNOSTIC
  - protected replay = controlled structural/runtime invariants, not live-model semantic quality
  - semantic calibration = primary calibrated semantic authority
- RC-10 and RC-21 were analyzed in `docs/rc10_rc21_policy_resolution_dossier.md` and then implemented.
- RC-10 = A is MADE and implemented: the retired `compatibility_local_opening_deterministic` raw token is owned exclusively by the opening-fallback evidence helper.
- RC-21 = B + C is MADE and implemented: social redirects create official follow-up from authored/realized scene evidence; narration alone does not instantiate an NPC; the lead registry is canonical; `pending_leads` and clue surfaces are projections.
- Latest full-suite baseline from this campaign: 6,450 collected, 6,351 passed, 0 failed, 99 skipped.

## Decisions Pending

None for RC-10 or RC-21.

## Decisions Made

- RC-10 = A. Evidence-only raw-token fence. See `docs/rc10_rc21_policy_resolution_dossier.md` and `docs/rc10_rc21_policy_implementation.md`.
- RC-21 = B + C. Authored-scene follow-up plus canonical lead registry. Same documents.

## Current Known Defects

None currently known in the green baseline.

A first full-suite pass hit one Windows `PermissionError` on a BY2 temp `combat.json` rename. Isolated re-run and a second full suite both passed. Treat that as an environmental lock, not a product defect.

## Authoritative Documents

1. `docs/rc10_rc21_policy_implementation.md`
2. `docs/rc10_rc21_policy_resolution_dossier.md`
3. `artifacts/policy_resolution/policy_decision_summary.md`
4. `artifacts/policy_implementation/residue_deferral.md`
5. `handoff/CURRENT_REVIEW.md`
6. `docs/state_authority_model.md`
7. `docs/compatibility_residue_register.md`

## Validation Baseline

6,450 collected, 6,351 passed, 0 failed, 99 skipped. See `artifacts/policy_implementation/post_implementation_suite.xml`.

Before this campaign: 6,450 collected, 6,347 passed, 4 failed, 99 skipped. The four former failures were exactly RC-10 (1) and RC-21 (3). All four are now green.

## Deliberately Deferred Residue

- `compat_pending_lead_needed` still keys off a scene target only.
- Intent parsing still reads `pending_leads` as the pursuit surface.
- Broader lead/clue overlap reduction remains deferred in `docs/current_focus.md`.

Do not treat those as open RC-10/RC-21 questions.

## Do Not Reopen Without Evidence

- Validation-authority hierarchy
- RC-11 / RC-13 expectation maintenance
- GD-01 CO99 governance-context advance
- Confirmed baseline repair and validation cleanup
- Semantic calibration as semantic authority
- Protected replay as structural/runtime authority
- Architecture Reconciliation chassis doctrine
- RC-10 = A
- RC-21 = B + C

## Recommended Next Action

Review this clean post-policy baseline. After review, the next Product Realization action is Calibration Round #2 or State ↔ Narration Consistency — not a new policy question and not a general lead-system refactor.

## Last Updated

2026-09-19 / `rc10_rc21_policy_implementation_20260919`
