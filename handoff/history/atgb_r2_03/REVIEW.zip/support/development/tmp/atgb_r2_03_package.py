from pathlib import Path
import json, sys, ast, hashlib, subprocess, re
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT))
A=ROOT/'artifacts/atgb/atgb_r2_03'; R=ROOT/'development/reports/atgb_r2_03'
R.mkdir(parents=True,exist_ok=True)
def put(p,s): p.write_text(s.strip()+'\n',encoding='utf-8')
def dump(p,x): put(p,json.dumps(x,ensure_ascii=False,indent=2))
rows=json.loads((A/'historical_trace_excerpts.json').read_text()); results=json.loads((A/'deterministic_results.json').read_text())
reports={
'01_baseline_and_evidence_inventory.md':'''# 01 — Baseline and Evidence Inventory

ATGB-R2-03 · 2026-10-19 · bounded offline investigation; no implementation authority.

HEAD is `b012c3d7e5887fdfb09d10bb9cc0f0220de09df9`. The dirty worktree, rather than HEAD alone, is the inspected implementation. `baseline.json`, full entry status, and SHA-256 manifest identify it. The pass protects 1,311 existing files across game, data, tests, static, experiments, the two primary historical runs and prior R2 evidence. No protected file changed. Existing unrelated changes were preserved.

Mandatory orientation read: docs/DEVELOPMENT_CONSTITUTION.md, docs/NEXT_SESSION.md, docs/validation_evidence_standard.md and docs/product_realization_validation.md. The requested support/docs/NEXT_SESSION.md does not exist in this checkout; `support/` is a review-export path convention. The canonical docs/NEXT_SESSION.md was used. No AGENTS.md was found by the repository search. Reports/evidence/export and the constitution-required handoff update are the only persistent outputs.

## Historical authorities and original evidence

| Artifact | Use and authority |
| --- | --- |
| development/reports/atgb_05_baseline_preservation.md; artifacts/atgb/atgb_05a/assessment/ATGB_04_review_judgments.json | v1 has 37 authoritative captures, not 37 successes. Assessment is provisional AI-assisted; authenticated human scoring remains pending. |
| artifacts/atgb/atgb_03/S02/transcript.md, result.json and stores/*/session_log.jsonl | Original S02 trial 1; exact input, raw interpretation, adapted record, host decision, emitted text, usage and emission metadata. |
| artifacts/atgb/atgb_03c/S05/transcript.md, result.json and stores/*/session_log.jsonl | Original S05 trial 1; includes the failed S05.2 exchange, disclosed rumor and S05.3 raw interpretation. |
| data/validation/atgb/baselines/frontier-gate-v1/ | Frozen source content and disclosure boundaries; curfew time is unauthored; patrol-route clue requires investigation. |
| development/reports/atgb_r2_01/02_failure_family_reconstruction.md | Prioritization distinguishes subject from addressee and recognizes non-answer evidence. Original logs checked independently here. |
| development/reports/atgb_r2_02/08_final_verdict_and_handoff.md; artifacts/atgb/atgb_r2_02/historical_replay_after.json | Accepted speech-participant repair within deterministic scope, 46 focused passes; historical regression 351 pass / 2 preexisting fail. Neither count is a new result of this pass. |
| development/reports/atgb_r1_06/{04_evidence_selection_analysis,06_pr_eg_comparison_and_causal_verdict}.md; docs/NEXT_SESSION.md | R1 selection/projection distinction; R1-07 remains pending live acceptance. S08.2 is not reopened. |
| artifacts/pr_eg_r6_r5/{07_CONVERSATIONAL_CONTEXT,14_REFERENT_INTERVENTION,15_QUESTION_PROPOSITION_INTERVENTION,32_REPAIR_PRIORITIZATION}.md | Existing PR-EG binding/witness and paired question/source findings. Experimental bind failures are not demonstrated on this legacy GM evidence route. No integration is recommended. |

## Evidence discipline

**Observed** means original captured output, current source, or a labeled offline execution. **Inferred** means the evidence supports the relationship without its original request/runtime step being captured. **Unknown** marks missing evidence. Raw completion fields are co-produced; their internal temporal ordering is unknown.

Original provider request messages are not retained for these turns. `request.chat` is the API input, not the model request. Reconstructed current messages are explicitly labeled and kept separately. Selected public passages provably reached the historical adapter; complete historical candidate sets and exact history truncation remain inferred from source, not recovered requests. Final historical sessions are not preturn snapshots. Current probes use explicit minimal session inputs, not a claimed byte-identical historical replay.

No additional Case C was selected: the primary sequence plus controls already distinguishes subject, selection, authorization and realization. No corpus audit or new benchmark was run. All judgments in this pass remain UNREVIEWED pending external review.
''',
'02_s02_evidence_binding_reconstruction.md':'''# 02 — S02 Evidence-Binding Reconstruction

## Exact sequence and subjects

S02.1: “I read the notices.” The delivered answer establishes only categories: “The notice board lists taxes, curfew rules, and a warning about a missing patrol.” No clue is discovered. No NPC is an established addressee; these are GM information questions.

| Turn | Exact player input | Raw communication and selected evidence | Final response |
| --- | --- | --- | --- |
| S02.2 | When does the curfew start? | GM/QUESTION; subject `curfew start time`; visible:0 | The notice board lists taxes, curfew rules, and a warning about a missing patrol. |
| S02.3 | I wasn't asking where the patrol went. I asked when it starts. | GM/CLARIFICATION; subject `Timing of the missing patrol start`; reply:1 | The notice board lists taxes, curfew rules, and a warning about a missing patrol. |
| S02.4 | All right. What did the warning say about where they were last seen? | GM/QUESTION; subject `Content of the warning about where the missing patrol was last seen`; visible:0 | The notice board lists taxes, curfew rules, and a warning about a missing patrol. |

S02.3's preceding explicit question makes curfew the supported antecedent of “it.” Its negated patrol-location clause is not a request to ask about patrol departure time. S02.4 explicitly changes to the missing-patrol warning; “they” is sufficiently grounded to the patrol. All three historical host decisions are ANSWER / communication_before_execution / answer_only, with no resolver or narration call. Relevant raw JSON, adapted records, original logs and final emission metadata are packaged separately; the table does not replace them.

## Existence, access, request, selection, authorization and emission

| Information | Authored existence | Player access at these turns | Model supply | Selected / host acceptance / final use |
| --- | --- | --- | --- | --- |
| Board category sentence | Visible fact index 0 | Delivered S02.1; public | Observed in adapted projection; exact complete request unknown | Selected all three (reply:1 repeats it); validated public reference and emitted verbatim |
| Curfew start hour | No authored start time in frozen baseline | Not established | No evidence of any supplied hour; current request contains none | No hour selected, accepted or emitted |
| Patrol last-seen northwest mud track | discoverable_clues.notice_patrol_route | Undiscovered in S02; interactable notice_board reveals it through investigate | Current public builder omits gated clue; original complete request unknown | Not selected or emitted; cannot treat world-state existence as disclosure permission |
| Known exit “Follow the missing patrol rumor” | Public scene exit | Public route option | Present in current scene evidence reconstruction | Not a last-seen location answer and not permission to execute travel |

S02.1 was routed as a conversational answer, not an investigation. Its wording does not establish that a clue was resolved. This investigation does not silently convert “read” into authority for a completed discovery. Whether a future product change should route such reading differently is excluded.

The builder supplies public scene summary, visible facts and recent delivered passages. Current request capture confirms previous player questions plus those passages are available within its two-turn history. The originals do not establish that every reconstructed passage was supplied then. The historically selected sentence is nonetheless directly proven available and inadequate: it gives neither time nor last-seen place.

## Earliest supported failures and E1–E4

S02.2: **Observed E2** — correct subject, selection of a related non-answer. Classification **Unanswerable** for the requested hour under established authorized evidence. A truthful limitation is warranted. No clarification of the subject is needed. The actual response is incomplete and nonresponsive; it does not invent a curfew time.

S02.3: **Observed subject misbinding plus E2** in one raw completion. Subject is curfew, not patrol start. Classification **Unanswerable** after resolving that subject. Selection of the repeated category sentence also fails. The model's unasked clarification question is “Do you have information about when the missing patrol starts rather than where it went?” The host does not emit that question because evidence is present. Internal order of subject and selection errors is unknown. Changing only the subject does not repair the host answer.

S02.4: **Observed E2** — subject correctly understood, category evidence selected as though it answered location. Classification **Unanswerable** on this public projection. The undiscovered clue is not an authorized replacement. A limitation, or separately authorized inspection route, would be honest; this pass validates only the limitation route.

E1 is not supported as a defect omitting an already public answer: no curfew hour exists and the last-seen clue is gated. Exact original context omission cannot be ruled out globally because messages are absent. E3 is not supported for S02: selected passages survive adaptation and decision unchanged. E4 is not the earliest failure: the plan already contains the non-answer, and captured final text equals that plan with zero generation attempts. Structural authorization establishes disclosure membership, not semantic sufficiency. No separate named response_plan record is captured on these turns: the ANSWER decision, answer_only policy and accepted speech metadata are the observed plan/emission evidence; no hidden planning text is reconstructed.
''',
'03_s05_subject_continuity_reconstruction.md':'''# 03 — S05 Subject-Continuity Reconstruction

## Historical sequence

1. S05.1 player: “Runner, what did you hear about the patrol?” Final: `Tavern Runner mutters, "Word is, the runner heard the patrol vanished near muddy footprints northwest of the crates."` The runner's hearsay is disclosed; the runner becomes active.
2. S05.2 player: “And the board, what does it say about the same patrol?” Final: “I cannot provide a validated response to that request.” This establishes a request about a second account, but no board detail. The runner remains active. This turn is context only; its failure is not independently diagnosed here.
3. S05.3 actual player text: **“Tell me more about that.”** The request's “Can you tell me more about that?” is representative wording, not the historical line. Final: “Which person do you mean: Gate Guard or Gate Serjeant or Tavern Runner? Nothing has been attempted.”

## Four roles

**Addressee:** tavern_runner, supported by established interaction. The old wrong-person question was repaired in R2-02 and is not reopened.

**Subject:** broadly the missing patrol. The requested account/detail is not unique: the immediately preceding request concerned the board, the most recent actual informative answer was runner hearsay, and the immediately preceding delivered line was a validation failure. Neither “more” nor “that” selects uniquely among those relationships. The failure line itself can motivate a request for explanation, but contains no new world subject. Do not infer future S05.4 (“The runner's version, not the notice.”) as context that existed at S05.3.

**Evidence:** the runner's disclosed rumor is valid public evidence for a restatement, not proof of additional details or of the notice's wording. The board's last-seen clue remains gated. The current builder also labels the S05.2 failure `npc_latest_reply` because its resolution still has a target; that label does not convert the failure into informative NPC testimony.

**Authority:** communication.subject describes intent and cannot establish a fact. NPC evidence must still pass the resolver's speaker, topic, relevance, sufficiency and disclosure checks.

## Model and host

**Observed historical interpretation:** NPC/CLARIFICATION, subject “More information about the patrol rumor from the Tavern Runner,” one ASK tavern_runner, unresolved_references [], evidence npc:tavern_runner:patrol_rumor. Its summary and requested outcome commit to runner detail; this is a plausible reading, not proven unique. The old host discards that route at unresolved_addressee and asks the wrong clarification slot. That historical cause is settled by R2-02.

**Observed current replay:** unchanged captured record yields EXECUTE / single_authoritative_component / ASK tavern_runner, with no immediate response text. proposed_record retains subject and evidence. Changing communication.subject alone to the board account gives the same routing; subject is not an executable semantic plan. The bridge copies communication and selected public evidence into metadata, so there is no wholesale loss of those fields.

The synthetic in-memory social control, with prior patrol_rumor revealed, resolves the correct runner but yields topic_revealed null, requested_subject `more`, reply_plan_kind genuine_uncertainty. The fallback requires authored_topic_relevant_to_question and authored_answer_sufficient_for_question against **raw player text**, not communication.subject. The former does not resolve a bare follow-up to a unique topic. The host's downstream lexical assessment therefore does not adopt the model's proposed rumor binding. This is a demonstrated current boundary, not evidence that the rumor had to be disclosed or that the model interpretation was correct. Full historical preturn continuity state is unavailable.

## Ambiguity verdict

**Partially resolved:** recipient and broad patrol subject are known; runner-versus-board account and requested new detail remain materially ambiguous. The account choice is genuinely ambiguous in the available record. A targeted question is justified. A guaranteed runner-rumor continuation is not justified. Safe proposed clarification: “Do you mean the runner's rumor, or what you wanted to learn from the notice board?” This names only established accounts and claims no board fact. The existing GM/CLARIFICATION contract emits it in the offline adapter/decision control without a new schema or state store.

Original full provider context is **Unknown**. Current captured assembly includes both prior exchanges (the rumor and failure) and public rumor evidence. Thus context enlargement is not demonstrated necessary. The new replay does not establish that a live model will choose the better clarification or that every “that” requires clarification.
''',
'04_source_ownership_and_data_flow.md':'''# 04 — Source Ownership and Data Flow

The companion `source_ownership_map.json` records exact current function locations, caller/consumer boundaries, inputs, outputs and fallbacks. `source_excerpts.txt` preserves those functions with one-based lines and whole-file hashes for review.

## Production path

`api.chat` → current deterministic continuity → `live_chat_interpretation.interpret_production_turn` when needed → production communication validation and PR-DR adaptation → API record reconsideration → `decision_from_interpretation_record` → `_communication_decision` → either nonmutating GM answer or ASK bridge/social resolver → sealed emission.

This describes the actual legacy communication path exercised in original logs. It does not substitute the experimental PR-EG bind/coverage pipeline merely because those names sound relevant.

## Ownership boundaries

| Owner | Input → output / caller and consumer | Authority and fallback |
| --- | --- | --- |
| semantic_interpreter.player_visible_turns | Log → last two player/GM pairs, each side 240 chars; used by production interpretation | Visible history only; metadata excluded. Not persistent topic authority. |
| conversational_orchestration.public_conversation_evidence | Scene + last four log entries → scene, visible:index, reply:index (1200 chars), causal receipts, latest speech and disclosed topic passages | Candidate construction. Excludes undiscovered clues/private NPC knowledge. IDs are request-local, not durable referents. |
| live_chat_interpretation.interpret_production_turn | Current message, catalog, recent pairs, public evidence, active_npc_id, last_subject and pending context → adapted record or blocked outcome carrying record | Existing semantic owner for communication recipient/purpose/subject/evidence refs. Does not adjudicate facts. Subject is free text. last_subject comes from last_gm_exchange and is usually prior player input, not an accepted semantic topic. |
| live_chat_interpretation.valid_communication | Communication object + host evidence map → bool | Exact fields and enum/type/reference membership validation. [] passes. No relevance or sufficiency test. Model cannot supply passage values. |
| player_interpretation_bridge.reconcile_reference_annotations | Proposed action refs + player text + catalog/context → reconciled record/diagnostics | Existing operation/addressee grounding, including bounded authored subject checks. Does not create general conversation topics; explicitly preserves unresolved deictic subjects. |
| ordinary_semantic_ownership.assess_addressee_grounding | Text, scene/world/session, proposed NPC → recipient grounding/authority | Present interlocutor and explicit speech roles. R2-02 repair accepted. Does not resolve what “that” means. |
| conversational_orchestration.decision_from_delivered_exchange | Text + delivered history/session → continuity decision or None | Prior delivered speech may answer/restate or clarify before a model record is used. Synthetic minimal sessions do not stand for complete historical continuity state. |
| conversational_orchestration._communication_decision | Adapted communication + public_evidence/context → ANSWER/CLARIFY or None for resolver | GM: joins selected public passage values. No fact retrieval or general sufficiency check. Empty QUESTION returns unestablished-information fallback; CLARIFICATION without evidence emits clarification_question. |
| conversational_orchestration.decision_from_interpretation_record | Record + bridge metadata/context → decision envelope | Calls continuity, ownership correction, communication branch, then action fallback. A single ASK goes to EXECUTE; unsupported/unclear interpretation clarifies or declines. |
| player_interpretation_bridge.normalized_action_from_interpretation | Record + catalog/grounding → normalized action and metadata or rejection | Validates operation/entity compatibility; copies communication and public evidence, not free-text subject into an authoritative topic key. |
| social.resolve_social_action | Normalized ASK, raw input, scene/world + copied session → social result; may mutate the provided in-memory session | Existing topic selection and disclosure owner. No topic → bounded uncertainty/refusal plan. Not a stateless function; experiments use copies only. |
| social._next_topic_to_reveal / authored_topic_relevant_to_question / authored_answer_sufficient_for_question | NPC authored topics, runtime reveal state, raw question → eligible topic/selection | Speaker ownership, subject relevance and requested detail sufficiency are separate predicates. Selected public refs alone do not override them. |
| dialogue_authority.authorize_npc_disclosure | NPC + candidate topic → permission/provenance | Final NPC disclosure gate; topic ownership/public epistemic policy. No model authorization. |
| api._nonmutating_conversational_decision_response | Decision → GM response, nonmutating resolution, context/log output | Applies host speech expression/audit then seal; original S02 text already equals the decision, zero generation attempts. We inspect source, not invoke the disk-writing API in this pass. |
| immutable_valid_response.seal_host_speech | Host text, resolution and speaker → accepted immutable speech | Preserves accepted text; does not turn a related sentence into an answer. Original hard-valid/contract-satisfying labels are structural, not proof of semantic adequacy. |

## Where the relationship is lost

S02.2/.4: subject-to-answer relationship first fails in communication.evidence_refs selection. S02.3: subject antecedent and evidence relationship both wrong in the raw completion. Host projection faithfully narrows to selected text, then realizes it faithfully. S05.3: original addressee problem is repaired; current record preserves the proposed subject but downstream lexical relevance does not treat it as a uniquely bound topic. Since that binding is not uniquely supported, bypassing the host would be the wrong repair.

The narrowest next owner is the **existing production interpretation contract** at interpret_production_turn's communication.subject/purpose/evidence_refs boundary. No missing architecture or new memory subsystem is established. PR-EG R5's witness/bind and paired proposition interventions are related lessons about separation, not directly exercised causes or integration authority.
''',
'05_deterministic_discrimination.md':'''# 05 — Deterministic Discrimination

Execution: `development/tmp/atgb_r2_03_probe.py` with bundled Python 3.12.14 and existing .venv site-packages. The script is packaged as an investigation artifact, not a production tool or frozen fixture modification. See exact inputs and outputs in deterministic_results.json and adapter_controls.json. No provider execution occurred. Provider and live interpretation are disabled in environment; socket.socket raises in the experiment block; request_interpretation is replaced only for offline request capture and saved JSON adapter controls.

## Arms and outcomes

16 decision invocations, four current request reconstructions, four raw-JSON adapter controls, three membership controls and one corrected social-resolver control were executed. The 16 decision invocations include an intentional duplicate S05 input used for resolver handoff, not 16 independent examples.

| Substitution | Outcome | Causal meaning |
| --- | --- | --- |
| Four unchanged captured adapted records | S02 repeats its category sentence; current S05 EXECUTE ASK runner | Reproduces S02 behavior at current decision boundary and accepted R2-02 recipient repair. |
| S02.3 communication.subject only → `curfew start time` | Same category sentence | Subject string alone cannot control selection or realization. |
| S02.2/.3/.4 evidence refs → []; projected evidence → {} | .2/.4 unestablished-information answer; .3 emits wrong patrol-start clarification | Selection matters, but .3 also has wrong disposition/question. |
| S02.3 corrected subject + empty evidence | Still wrong patrol-start clarification | Correct subject plus no evidence is insufficient if purpose and clarification text remain wrong. |
| Three S02 supported QUESTION dispositions + empty evidence + no operations | All return `That has not been established in the information available to you.` | Existing contract and GM owner can honestly handle an understood question whose answer is unavailable. |
| S05 alternative board subject only | Same ASK route; proposed record retained | No unique topic binding is established merely by changing a string. |
| S05 assume GM/RECALL, no action, unchanged disclosed rumor evidence | Emits rumor passage | Positive transport control: host can use the valid rumor on that route. This is an assumed reading and restatement, not a solution to “more.” |
| S05 GM/CLARIFICATION, [], no action, supported account question | Focused runner-versus-board clarification | Existing host can ask the right slot without inventing facts. |

The raw adapter controls use original captured raw JSON with precisely recorded communication/disposition substitutions. The legacy adapter may mark zero-operation OTHER as SAFE_ABSTENTION/clarification_required; it still carries a structurally valid record. The same record reconsideration used by api.chat returns ANSWER for the three understood S02 questions and CLARIFY for S05. These adapter labels are retained, not reported as four accepted execution records. No full HTTP request or disk-writing API is invoked.

Membership controls: visible:0 accepted; [] accepted; nonexistent clue:notice_patrol_route rejected. Membership acceptance is not answer sufficiency. No injection of a gated clue or fabricated hour was attempted. **There is no valid nonempty historical evidence substitution that supplies the missing curfew hour or undisclosed posted route.** Experiment B therefore tests removal of non-answer evidence, not an invented correct answer. The S05 recall control supplies genuinely authorized evidence under an explicitly different reading.

## Resolver and integrity

The corrected synthetic S05 resolver call uses keyword arguments, minimal known recipient context and patrol_rumor in revealed_topics. It resolves Tavern Runner, yields genuine_uncertainty, reveals no topic and leaves the copied world unchanged. It does update the copied session's runtime/addressability as expected. No copied session is saved to a gameplay store. A first resolver invocation mistakenly used positional arguments in the wrong order; its “empty scene_id” result is **INVALID investigative harness output**, retained separately in invalid_initial_social_invocation.json. It supports no product diagnosis. The corrected run replaces it as the valid control.

All 16 decision inputs remain equal to deep copies. All 1,311 protected file hashes remain unchanged, including frozen baseline, canonical game state, production, prompts/schema source and experimental files. `integrity.json` records zero protected changes and zero added protected files at experiment completion, before the new review configuration was written. Repository status before/after records report/export additions separately.

Limitations: minimal session replay, no exact original provider requests, no historical full preturn snapshots, no live sampling, no new gameplay evaluation, no response-naturalness measurement, no independent held-out or broad regression result. Offline substitutions show host capability and causal dependencies, not that new prompt wording would reliably produce them.
''',
'06_player_impact_and_candidate_repairs.md':'''# 06 — Player Impact and Candidate Repairs

The repeated S02 sentence stalls information gathering despite progressively clearer questions. It makes a player repeat themselves and obscures the difference between an unknown fact and a misunderstood request. S02.3 additionally invalidates the player's correction by changing its subject. S05's wrong-person clarification broke continuity; that part is repaired. Its remaining uncertainty should concern which account/detail is intended, preserving player choice rather than selecting an unsupported topic. Rumor restatement must stay hearsay; board information must not be invented.

Observed recurrence is three S02 selections of related non-answers plus one S05 ambiguous follow-up. No frequency statistic or claim that most NPC conversations fail follows. Expected exposure extends to ordinary specific questions about broad public summaries, corrections with pronouns/negated alternatives, and follow-ups after failed or competing accounts. Those families arise naturally beyond these phrases, but future reliability is unmeasured.

| Candidate | Mechanism / earliest decision / existing owner | Boundary and benefit | Authority / performance | Validation / risk |
| --- | --- | --- | --- | --- |
| 1. Focus production interpretation guidance on resolved question + requested detail + evidence sufficiency **(recommended)** | S02.2/.4 raw refs select related non-answers; .3 raw subject/disposition misbind; S05 account ambiguity goes unmarked. Existing interpret_production_turn communication contract. | Small instruction clarification using existing subject, purpose, status, clarification_question and evidence_refs fields: recover question antecedent; distinguish a matching topic from requested detail; select [] with QUESTION when fact unavailable; targeted clarification only for unresolved meaning. Preserve no-action semantics. | No new authority, schema, state or provider call. Same public map and validation. Small extra prompt tokens if needed; measure actual delta in implementation. Same call count; latency and accuracy unproven. | Offline adapter/decision controls with sufficient, insufficient, partial, competing-account and no-antecedent fixtures; unrelated vocabulary; R1/R2 regression. Separately authorized live original/variation trials mandatory. Risk: over-abstention, clarification suppression or enum conflicts. |
| 2. Add GM answer-sufficiency gate before joining selected passages | Demonstrated host acceptance of inadequate selected text is downstream of raw selection. Existing _communication_decision, with social sufficiency helpers considered. | Could reject related non-answers deterministically for supported dimensions. Existing helpers are lexical and NPC-oriented; not demonstrated correct for arbitrary GM context or implicit correction. | No extra call; no disclosure bypass. CPU cost small in principle, unmeasured. | Must avoid converting incidental temporal/location words into false support, and protect legitimate partial/recall/descriptions. Does not repair S02.3 raw subject or S05 ambiguity. Medium semantic-regression risk; not preferred over the demonstrated earlier interpretation boundary. |
| 3. Adopt selected NPC topic as resolved follow-up topic | Current bridge preserves proposed subject/evidence, but social rechecks raw text and returns uncertainty. Existing social selector/continuity owner. | Could enable already-disclosed topic recall for genuinely unique follow-ups. S05 does not prove unique account, and “more” is not necessarily restatement. | Must recheck speaker, disclosed topic and sufficiency; no new facts. No extra call/state in principle. | Positive unique-thread and negative competing/failed-account controls required. High risk of hardwiring last-topic bias and overriding honest ambiguity. Insufficient case support for implementation now. |

Candidate 1 addresses the earliest demonstrated boundary without changing deterministic gameplay authority. It is a bounded **live interpretation dependency**, not a proven repair. Current instructions already forbid unsupported selection and require ambiguity handling; the evidence proves a contract-compliant but semantically poor completion, not that a particular missing sentence caused it. Proposed wording efficacy is a hypothesis requiring live acceptance. Do not expand the proposal into broad prompt optimization, new semantic classifiers or experimental integration.
''',
'07_recommended_next_scope.md':'''# 07 — Recommended Next Scope

**One next action: ATGB-R2-04 — bounded production question-to-evidence interpretation contract implementation and qualification, after external review and separate authorization.** Verdict C describes its live dependence. No additional offline investigation is recommended by default.

Owner: game/live_chat_interpretation.py::interpret_production_turn, the existing production communication interpretation boundary, consumed by unchanged orchestration/bridge authorities. Primary development failure class: **semantic** — explicit existing instructions already prohibit unsupported evidence and nonunique demonstrative guesses; the captured completion nevertheless chooses a non-answer or wrong subject. No missing architecture or proven structural validation defect is established. Contract wording may improve this behavior but is not established as its cause.

## Proposed bounded implementation target

Clarify only the current instructions tying existing communication.subject, purpose and evidence_refs to the underlying question and requested detail. Distinguish resolved meaning with an unavailable fact (QUESTION, no asserted answer evidence) from unresolved conversational meaning (targeted CLARIFICATION). Preserve pronoun antecedents from prior questions and do not promote a negated alternative into the subject. Where competing accounts remain, ask about those accounts without requesting the already known recipient. Implement through existing fields and one interpretation request. No promise that this wording will work follows from deterministic controls.

No hardcoded historical answers, phrase-specific referent rules, broad rewrite, new prompt stage, parallel classifier, automatic retry, extra call, persistent topic store, hidden clue access, gameplay-system change, PR-EG integration, R2-02 reopening, R1/S08.2 reopening, or conversational-style overhaul. Do not route S02.4 through an inspection automatically as part of this scope.

## Deterministic acceptance

1. Raw existing-contract controls survive adaptation and API record reconsideration: valid public sufficient evidence answers; membership-invalid refs reject; no fact is minted from subject or provider prose.
2. Correct curfew subject without authorized timing facts produces an honest limitation; board categories alone are never treated as a posted last-seen answer in the evaluated controls. An unavailable fact does not become a missing player-intent parameter.
3. S02.3's corrected question remains curfew timing; no ASK with missing target or mechanical revision is executed. Retain the R1 accepted mechanical guards and pending-intent behavior.
4. Unique prior-topic follow-ups, multiple competing accounts, no antecedent, partial evidence, prior refusal/failure, explicit recipient switch and off-scene recipient have separate controls with unrelated scenario vocabulary. Do not demand resolution where none is supported.
5. R2-02 deterministic recipient behavior remains accepted. Production, state and disclosure authority remain with existing owners; no new persisted structure or provider call.
6. Measure exact prompt/schema byte/token diff and bounded call count; schema shape stays unchanged. Run relevant focused regression slices and report preexisting failures separately.

## Live acceptance (requires separate explicit provider authority)

Live raw interpretations, actual requests, host decisions, final text and before/after state must be captured for original S02.2–.4 and S05.3 context plus bounded unrelated variations. Evaluate subject correctness, requested-detail sufficiency, uncertainty versus ambiguity, no hidden disclosure, no action from a pure question, no unnecessary recipient clarification and no stale rumor substitution after a newer failure. A repeated generic sentence or wrong-topic correction is a failure even if structural acceptance says PASS. A limitation is acceptable when the fact is unauthored; targeted account clarification is acceptable for S05.

Original reproduction, authored related variations, held-out generalization when actually available, and unrelated regression remain separate claims. Frozen ATGB is exposed evidence, not new held-out evidence. Use the established behavioral evidence standard and human review; deterministic substitution is not a benchmark score. Reconsider benchmark cadence at the eventual communication milestone; this recommendation grants no benchmark/provider authority.

## Stop conditions

Stop if the target requires schema/state changes, new provider stages, weakening disclosure checks or broad architecture changes. Stop validation on provider/tool failure under the separately authorized trial policy, preserve failed-call evidence and never infer product success. Withhold live acceptance if output reliability is unmeasured. If the bounded contract change fails live, report the raw boundary result for review rather than widening the repair automatically. This pass stops at its review ZIP.
''',
'08_final_verdict_and_handoff.md':'''# 08 — Final Verdict and Handoff

**C — Live interpretation dependency.**

S02.2/.4 first fail at selecting an authorized but non-answering public sentence. S02.3 also misbinds the corrected subject to patrol timing. Their completion fields are co-produced; no internal order is claimed. The host preserves selected passages, and the final response faithfully emits an already inadequate plan. No relevant authorized hour/location answer was lost by host rejection. Empty-evidence QUESTION controls yield honest limitations through the existing adapter/decision path.

S05.3's known runner recipient remains correct after accepted R2-02. The broad patrol subject is known, but account/detail is partially unresolved after the intervening board failure. Historical model selection of runner detail is plausible, not uniquely supported. Current host preserves the proposed fields but its NPC selector does not turn them into a bound topic; it safely returns uncertainty in the synthetic resolver control. A supplied focused account clarification reaches the response using the existing contract. These results do not justify adopting a proposed rumor binding as fact.

**One recommended ATGB-R2-04 scope:** bounded production question-to-evidence interpretation contract implementation/qualification at interpret_production_turn, as specified in report 07. No additional offline investigation is necessary before that bounded attempt; no implementation or live authority carries forward from this pass. Its effectiveness requires separately authorized live validation. This is not verdict A because deterministic host capability does not prove a wording repair or live selection reliability.

Remaining uncertainty: original complete model requests, historical full preturn continuity snapshots, live cause of instruction noncompliance and reliability of the proposed change. The earliest runtime semantic mismatch is supported; which instruction/model factor produced it remains unknown. Ordinary specific public-information questions and ambiguous follow-ups can expose the mechanism beyond historical scenarios; prevalence and general improvement remain unmeasured.

## Behavioral Evidence

Packet: artifacts/validation_evidence/atgb_r2_03/. Two historical scenario runs / four investigated turns; no new live run. Original raw completions and emitted replies are retained separately from 16 decision controls, four adapter controls, four current-request reconstructions, three membership controls and one valid synthetic resolver control. No repair-effect, gameplay benchmark, broad regression or independent-generalization result. All new causal judgments are UNREVIEWED. No new evaluator-disagreement claim; historical judgments remain intact. Invalid initial resolver invocation is labeled and excluded from conclusions.

## Scope confirmations

- No production changes; no prompt or schema changes.
- No live provider calls or connectivity diagnostics.
- No new persistent gameplay/conversation state; reports and offline evidence are persistent deliverables only.
- No experimental PR-EG integration.
- Frozen ATGB baseline unchanged.
- No unauthorized gameplay-state mutations; resolver changes occurred only in disposable in-memory copies.
- No secrets included; explicit allowlist export, filename policy and content scan apply.
- Existing worktree changes preserved; no commit or push performed.

Stop after producing CURRENT_REVIEW(YYYYMMDD-HHMMSS).zip. Await external review before ATGB-R2-04.
'''
}
for name,content in reports.items():put(R/name,content)

# Exact current function ownership and reviewable source excerpts, no broad tree copy.
owners={
'game/live_chat_interpretation.py':['production_interpretation_schema','valid_communication','interpret_production_turn'],
'game/conversational_orchestration.py':['public_conversation_evidence','decision_from_delivered_exchange','_communication_decision','decision_from_interpretation_record'],
'game/player_interpretation_bridge.py':['reconcile_reference_annotations','normalized_action_from_interpretation'],
'game/ordinary_semantic_ownership.py':['assess_addressee_grounding'],
'game/conversational_continuity.py':['record_delivered_exchange','continuity_directive'],
'game/semantic_interpreter.py':['player_visible_turns'],
'game/social.py':['authored_topic_relevant_to_question','authored_answer_sufficient_for_question','_next_topic_to_reveal','resolve_social_action'],
'game/dialogue_authority.py':['authorize_npc_disclosure','topic_supports_requested_information'],
'game/api.py':['_nonmutating_conversational_decision_response'],
'game/immutable_valid_response.py':['seal_host_speech']}
mapping=[]; excerpts=[]
for path,names in owners.items():
 p=ROOT/path; text=p.read_text(encoding='utf-8'); lines=text.splitlines(); h=hashlib.sha256(p.read_bytes()).hexdigest()
 for node in ast.parse(text).body:
  if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name in names:
   mapping.append({'path':path,'function':node.name,'start_line':node.lineno,'end_line':node.end_lineno,'file_sha256':h,'signature':ast.get_source_segment(text,node.args),'ownership_document':'development/reports/atgb_r2_03/04_source_ownership_and_data_flow.md'})
   # Long resolver limited to implicated branch; others complete for traceability.
   spans=[(node.lineno,node.end_lineno)] if node.name!='resolve_social_action' else [(3895,3935),(4250,4340),(4450,4515)]
   for lo,hi in spans:
    excerpts.append(f'\n## {path}::{node.name} lines {lo}-{hi}; sha256={h}\n'+'\n'.join(f'{i+1}: {lines[i]}' for i in range(lo-1,min(hi,len(lines)))))
dump(A/'source_ownership_map.json',mapping);put(A/'source_excerpts.txt','\n'.join(excerpts))
# Authoritative historical provenance hashes, separate from reconstructed outputs.
paths=['docs/DEVELOPMENT_CONSTITUTION.md','docs/validation_evidence_standard.md','docs/product_realization_validation.md','artifacts/atgb/atgb_03/S02/result.json','artifacts/atgb/atgb_03/S02/transcript.md','artifacts/atgb/atgb_03c/S05/result.json','artifacts/atgb/atgb_03c/S05/transcript.md','artifacts/atgb/atgb_r2_01/representative_traces.json','artifacts/atgb/atgb_r2_02/historical_replay_after.json']
for r in rows:
 paths.extend([r['log_source'],r['source']])
dump(A/'historical_provenance.json',[{'path':p,'sha256':hashlib.sha256((ROOT/p).read_bytes()).hexdigest()} for p in sorted(set(paths))])

from tools.validation_evidence import build_packet,write_packet
examples=[]
for r in rows:
 examples.append({'example_id':r['turn_id'],'scenario_run_id':r['source'],'turn_index':int(r['turn_id'].split('.')[1]),'player_input':r['player_input'],'player_input_classification':['representative_player_behavior'], 'simulated_player_rationale':'Fixed authored ATGB line; not a new human-captured utterance.', 'prior_context':r['preceding_conversation'],'exact_gm_output':r['final_player_facing_response'],'historical_result':r['historical_rubric'],'semantic_result':r['historical_rubric']['response'].upper(),'semantic_result_provenance':'Preserved provisional historical response judgment, not a new automated score','mandatory_gates':{'historical_unavailability':{'status':'UNAVAILABLE','reason':'No new standard gate scoring performed'}},'diagnostic_result':{'status':'NOT_RUN'},'automated_evaluation':{'status':'NOT_RUN','reason':'Causal analysis, not new scoring'},'runtime_validity':r['runtime_validity'],'final_emission_metadata':{'source':'context_and_original_logs.json','narration_invoked':r['narration_invoked']},'continuation_decision':'Historical sequence only; no new gameplay execution','source_artifact_path':r['log_source'],'human_review':{'status':'UNREVIEWED','rationale':'New causal assessment awaits external review; imported historical rubric preserved'},'evaluator_disagreement':{'present':False,'rationale':'No new evaluator comparison performed'},'calibration_reference':None})
packet=build_packet(campaign={'campaign_id':'atgb_r2_03','what_was_tested':'Four historical turns reconstructed; 16 deterministic decision controls plus offline adapter and authorization controls. No repair implemented.','runtime_path':'Original captured API logs plus current production function replay, in-memory copies only','gm_boundary':'Historical live interpretations retained; no new model call or final API emission','player_input_mode':'Fixed authored historical ATGB input, not human-captured live play','run_count':2,'turn_count':4,'automated_conclusion':'C — live interpretation dependency; historical failures are not repair-effect results'},claim_types=['runtime_evidence'],examples=examples,missing_concepts=[],limitations=['Original full provider requests unavailable; current request reconstruction is not historical capture.','Historical imported assessment is AI-assisted, not authenticated human review.','No live improvement, benchmark score, independent generalization or broad regression claim.','S05 account ambiguity is material; do not invent a unique topic.'],evidence_scope='historical_causal_reconstruction')
write_packet(ROOT/'artifacts/validation_evidence/atgb_r2_03',packet)

nextp=ROOT/'docs/NEXT_SESSION.md'; old=nextp.read_text(encoding='utf-8')
if '## Latest investigation — ATGB-R2-03' not in old:
 (A/'NEXT_SESSION_before.md').write_bytes(nextp.read_bytes())
 marker='## Latest repair — ATGB-R2-02'
 addition='''## Latest investigation — ATGB-R2-03

2026-10-19: **C — Live interpretation dependency.** Offline only; no repair.
S02.2/.4 select public but non-answering board categories; S02.3 also misbinds
curfew timing to patrol timing. Curfew hour is unauthored; posted last-seen clue
is gated, not an omitted public answer. S05.3 keeps the repaired runner recipient
but runner-versus-board account remains ambiguous after the intervening failure.
Existing contract can emit honest limitation or targeted account clarification.
16 decision controls, four raw adapter controls, four current-request captures,
three membership controls and one valid synthetic resolver control; no live call.
Original complete requests/preturn snapshots unavailable. 1,311 protected hashes
unchanged. No production/prompt/schema/gameplay/frozen/experimental changes.
Reports: development/reports/atgb_r2_03/; evidence: artifacts/atgb/atgb_r2_03/;
packet: artifacts/validation_evidence/atgb_r2_03/; review: handoff/CURRENT_REVIEW.md
and timestamped ZIP. Recommend one separately authorized R2-04 bounded production
question-to-evidence interpretation-contract implementation/qualification, with
live acceptance required; no extra offline investigation by default. R2-02 stays
accepted in deterministic scope; R1-07 live acceptance pending; S08.2 not reopened.
Stop for external review. No commit/push; preexisting dirty tree preserved.

'''
 old=old.replace('Updated 2026-10-19 / ATGB-R2-02.','Updated 2026-10-19 / ATGB-R2-03.').replace(marker,addition+marker)
 put(nextp,old)

(A/'repository_status_after.txt').write_bytes(subprocess.check_output(['git','status','--short'],cwd=ROOT))
config={'campaign_id':'atgb_r2_03','campaign_name':'ATGB-R2-03 Question-Subject and Evidence-Binding Investigation','campaign_date':'2026-10-19','purpose':'Read-only causal investigation; no implementation or provider authority.','objective_status':'C — Live interpretation dependency','executive_summary':'S02 selects related non-answer evidence; S02.3 also misbinds the curfew subject. S05 recipient repair holds but account ambiguity remains. Existing contract supports honest limitations and focused clarification. Recommend one bounded production interpretation-contract implementation/qualification after review; live reliability remains unproven.','changes':{'production':['None; no prompt/schema/state/PR-EG integration changes.'],'validation':['No frozen fixtures or scoring changes. Offline controls only.'],'tooling':['Disposable investigation scripts only, packaged with evidence.'],'documentation':['Eight reports and required docs/NEXT_SESSION.md update.'],'generated_artifacts':['Original trace excerpts, separately labeled controls, source map, integrity manifest and review export.']},'testing':{'focused':'16 decision controls, 4 raw adapter controls, 3 authorization controls, 4 current-request reconstructions, 1 valid synthetic resolver control.','broader':'Not run; no production modifications.','full_suite':'Not run.','runtime_validation':'Production functions on in-memory copies; no HTTP/gameplay-store execution.','model_runtime_boundary':'No provider call; socket guard and patched request stub. Original complete model requests unavailable.','new_regressions':'No broad regression claim; protected source/state hashes unchanged.','pre_existing_failures':'Prior R2-02 slice recorded 2 failures; not rerun here. Invalid initial resolver invocation retained as harness error, excluded from product conclusions.'},'known_problems':{'campaign_specific':['Original complete provider requests and historical preturn snapshots missing.','Proposed prompt wording efficacy unproven; deterministic substitutions are not live reliability.'],'pre_existing':['Extensive dirty/untracked tree preserved.','R1-07 pending live acceptance; R2-02 accepted only within deterministic scope.']},'decisions_requiring_human_review':['Review verdict C and bounded report-07 scope before separately authorizing R2-04.'],'missing_concepts':['No new architecture is justified.'],'does_not_prove':['Implemented repair, live selection reliability, gameplay benchmark score, independent generalization, full regression green, or unique S05 rumor antecedent.'],'recommended_next_step':'Stop for external review. One proposed R2-04: bounded production question-to-evidence interpretation contract implementation and qualification; separate live authority required.','primary_report':'development/reports/atgb_r2_03/08_final_verdict_and_handoff.md','evidence_packets':['artifacts/validation_evidence/atgb_r2_03'],'self_contained_review_test':'Eight reports, exact original and substituted records, source ownership/excerpts, integrity and status are packaged. Historical and reconstructed evidence are labeled separately.','configuration_source':'data/validation/review_handoffs/atgb_r2_03_question_subject_evidence_binding.json','supporting_files':[]}
files=list(R.glob('*.md'))+list(A.glob('*'))+[ROOT/'development/tmp/atgb_r2_03_probe.py',ROOT/'development/tmp/atgb_r2_03_package.py',ROOT/'development/tmp/atgb_r2_03_verify.py',nextp]
for p in files:
 if p.is_file() and p != R/'08_final_verdict_and_handoff.md':
  config['supporting_files'].append({'path':p.relative_to(ROOT).as_posix(),'role':'report' if p.parent==R else 'evidence','why':'Bounded investigation provenance, exact controls, ownership or integrity.','behavioral_evidence':p.suffix=='.json' and 'results' in p.name,'human_review_required':True})
dump(ROOT/'data/validation/review_handoffs/atgb_r2_03_question_subject_evidence_binding.json',config)
print('Eight reports, source map, packet, handoff orientation and review config prepared')
