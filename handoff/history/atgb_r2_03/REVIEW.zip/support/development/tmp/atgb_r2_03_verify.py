from pathlib import Path
import json,hashlib,re,sys,subprocess
ROOT=Path(__file__).resolve().parents[2]; A=ROOT/'artifacts/atgb/atgb_r2_03'
sys.path.insert(0,str(ROOT))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
before=json.loads((A/'protected_before.json').read_text())
changed=[p for p,h in before.items() if not (ROOT/p).exists() or sha(ROOT/p)!=h]
rows=json.loads((A/'historical_trace_excerpts.json').read_text())
historical=[]
for r in rows:
 log=[json.loads(l) for l in (ROOT/r['log_source']).read_text().splitlines() if l.strip()]
 original=log[int(r['turn_id'].split('.')[1])-1]
 raw=json.loads(original['resolution']['metadata']['live_chat_interpretation']['raw_interpretation'])
 historical.append({'turn_id':r['turn_id'],'raw_matches_original':raw==r['model_interpretation'],'input_matches':r['player_input']==original['player_input'],'final_matches':r['final_player_facing_response']==original['player_facing_text'],'source_hash_matches':sha(ROOT/r['source'])==r['source_sha256'],'log_hash_matches':sha(ROOT/r['log_source'])==r['log_sha256']})
arms=json.loads((A/'deterministic_results.json').read_text())
adapters=json.loads((A/'adapter_controls.json').read_text())
assert len(arms)==16 and all(x['inputs_unchanged'] for x in arms)
assert len(adapters)==4
for a in adapters:
 assert a['adapter_outcome'].get('record') is not None
 d=a['reconsidered_host_decision']
 assert d['category']==('CLARIFY' if a['turn_id']=='S05.3' else 'ANSWER')
 assert not d['requires_authoritative_execution']
assert not changed
assert all(all(v for k,v in row.items() if k!='turn_id') for row in historical)
from tools.validation_evidence import validate_packet
errors=validate_packet(json.loads((ROOT/'artifacts/validation_evidence/atgb_r2_03/evidence_manifest.json').read_text()))
assert not errors
scan_files=list((ROOT/'development/reports/atgb_r2_03').glob('*.md'))+list(A.glob('*'))
patterns=[re.compile(r'sk-[A-Za-z0-9_-]{16,}'),re.compile(r'Bearer\s+[A-Za-z0-9._-]{16,}'),re.compile(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----')]
hits=[]
for p in scan_files:
 if p.is_file():
  t=p.read_text(encoding='utf-8',errors='replace')
  if any(x.search(t) for x in patterns):hits.append(p.relative_to(ROOT).as_posix())
assert not hits
info={'protected_file_count':len(before),'changed_protected_files':changed,'historical_provenance_checks':historical,'decision_invocations':len(arms),'all_decision_inputs_unchanged':True,'raw_adapter_controls':len(adapters),'packet_validation_errors':errors,'secret_value_pattern_hits':hits,'scope':'No production/prompt/schema/frozen/gameplay/experimental modifications; new review configuration only under data/validation/review_handoffs. No provider calls, commit or push.','evidence_limit':'No live reliability or benchmark claim. Source hash equality verifies preexisting changes preserved, not a clean worktree.'}
(A/'verification.json').write_text(json.dumps(info,indent=2)+'\n',encoding='utf-8')
print(json.dumps(info))
