import os
os.environ['ASHEN_DISABLE_PROVIDER_CALLS'] = '1'
os.environ['ASHEN_DISABLE_LIVE_INTERPRETATION'] = '1'
import json, hashlib, subprocess, sys, copy
from pathlib import Path
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
OUT = ROOT / 'artifacts/atgb/atgb_r2_03'
OUT.mkdir(parents=True, exist_ok=True)
def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False, default=str)+'\n', encoding='utf-8')
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def manifest():
    paths=[]
    for folder in ['game','data','experiments','tests','static','artifacts/atgb/atgb_03/S02','artifacts/atgb/atgb_03c/S05','artifacts/atgb/atgb_r2_01','artifacts/atgb/atgb_r2_02']:
        paths.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts)
    return {p.relative_to(ROOT).as_posix():digest(p) for p in sorted(set(paths))}
if sys.argv[-1] == 'baseline':
    save('protected_before.json', manifest())
    (OUT/'repository_status_before.txt').write_bytes(subprocess.check_output(['git','status','--short'], cwd=ROOT))
    save('baseline.json', {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(), 'branch':subprocess.check_output(['git','branch','--show-current'],cwd=ROOT,text=True).strip(), 'support_handoff_exists':(ROOT/'support/docs/NEXT_SESSION.md').exists(), 'production_changed_by_this_pass':False})
    print('Baseline recorded')
    sys.exit()
from unittest.mock import patch
from game.conversational_orchestration import public_conversation_evidence, decision_from_interpretation_record
from game.live_chat_interpretation import valid_communication
from game.player_interpretation_bridge import normalized_action_from_interpretation
from game.defaults import default_character
from game.social import resolve_social_action
rows=json.loads((ROOT/'artifacts/atgb/atgb_r2_01/representative_traces.json').read_text())
selected=[r for r in rows if r['turn_id'] in ['S02.2','S02.3','S02.4','S05.3']]
scene=json.loads((ROOT/'data/validation/atgb/baselines/frontier-gate-v1/scenes/frontier_gate.json').read_text())
world=json.loads((ROOT/'data/validation/atgb/baselines/frontier-gate-v1/world.json').read_text())
hist={}
for sid,folder in [('S02','atgb_03'),('S05','atgb_03c')]:
    lp=next((ROOT/f'artifacts/atgb/{folder}/{sid}/stores').glob('*/session_log.jsonl'))
    hist[sid]=[json.loads(l) for l in lp.read_text(encoding='utf-8').splitlines() if l.strip()]
save('historical_trace_excerpts.json', selected)
contexts=[]
for r in selected:
    sid=r['turn_id'].split('.')[0]; n=int(r['turn_id'].split('.')[1])-1
    candidates=public_conversation_evidence(scene, hist[sid][:n])
    original=hist[sid][n]
    contexts.append({'turn_id':r['turn_id'],'classification':'current-source reconstruction, not captured historical request','preceding_log':hist[sid][:n], 'candidate_evidence':candidates, 'original_log_turn':original})
save('context_and_original_logs.json', contexts)
session={'active_scene_id':'frontier_gate','turn_counter':2,'clocks':{'suspicion':0,'unrest':0,'danger':0},'interaction_context':{'active_interaction_target_id':'tavern_runner','active_interaction_kind':'social','interaction_mode':'social','engagement_level':'engaged'}}
results=[]
def run(r, variant, rec):
    s=copy.deepcopy(session if r['turn_id']=='S05.3' else {'active_scene_id':'frontier_gate'})
    w=copy.deepcopy(world); sc=copy.deepcopy(scene)
    before=copy.deepcopy((s,w,sc,rec))
    d=decision_from_interpretation_record(rec, player_text=r['player_input'],scene=sc, world=w, session=s).to_public_dict()
    results.append({'turn_id':r['turn_id'],'variant':variant,'exact_input_record':rec,'decision':d,'inputs_unchanged':before==(s,w,sc,rec)})
    return d
with patch('socket.socket', side_effect=AssertionError('network forbidden')):
    for r in selected:
        original=copy.deepcopy(r['adapted_interpretation'])
        run(r,'captured_record_unchanged',original)
        if r['turn_id']=='S02.3':
            x=copy.deepcopy(original); x['communication']['subject']='curfew start time'
            run(r,'subject_only',x)
        if r['turn_id'].startswith('S02'):
            x=copy.deepcopy(original); x['communication']['evidence_refs']=[]; x['public_evidence']={}
            run(r,'evidence_selection_only_empty',x)
            if r['turn_id']=='S02.3':
                x['communication']['subject']='curfew start time'
                run(r,'subject_and_empty_evidence',x)
            x=copy.deepcopy(original)
            x['communication'].update(subject='curfew start time' if r['turn_id']!='S02.4' else 'Posted last-seen location of missing patrol', purpose='QUESTION', evidence_refs=[])
            x['public_evidence']={}; x['action_components']=[]; x['communication_mode']='OTHER'; x['clarification_question']=''
            run(r,'supported_question_disposition_and_no_answer_evidence',x)
        if r['turn_id']=='S05.3':
            x=copy.deepcopy(original); x['communication']['subject']='Notice-board account of the same missing patrol'
            run(r,'alternative_supported_subject_only',x)
            x=copy.deepcopy(original); x['communication']['recipient']='GM'; x['communication']['purpose']='RECALL'; x['action_components']=[]
            run(r,'explicitly_assumed_GM_recall_control_not_unique_resolution',x)
            x=copy.deepcopy(original); x['communication'].update(recipient='GM',purpose='CLARIFICATION',subject='Which account of the missing patrol?',evidence_refs=[])
            x['action_components']=[]; x['public_evidence']={}; x['clarification_question']="Do you mean the runner's rumor, or what you wanted to learn from the notice board?"; x['communication_mode']='OTHER'
            run(r,'supported_account_clarification_control',x)
            d=run(r,'resolver_input',copy.deepcopy(original))
            s=copy.deepcopy(session); w=copy.deepcopy(world)
            # Restore the two historical runtime snapshots from the log is not possible;
            # use documented synthetic state with prior rumor revealed, copies only.
            s['npc_runtime']={'tavern_runner':{'revealed_topics':['patrol_rumor']}}
            normalized,meta=normalized_action_from_interpretation(d['proposed_record'],scene=scene,world=w,player_text=r['player_input'],session=s)
            before=copy.deepcopy((s,w))
            resolution=resolve_social_action(scene_envelope=copy.deepcopy(scene), session=s, world=w, normalized_action=normalized, raw_player_text=r['player_input'], character=default_character())
            save('s05_social_control.json',{'classification':'synthetic in-memory resolver control; not historical full-state replay','session_before':before[0], 'normalized_action':normalized,'bridge_metadata':meta,'resolution':resolution,'session_after':s,'world_changed_in_memory':w!=before[1]})
    # Membership-only authorization control; public values cannot be provided by a model.
    validations=[]
    evidence=public_conversation_evidence(scene,hist['S02'][:1])
    for refs in [['visible:0'],[],['clue:notice_patrol_route']]:
        c={'recipient':'GM','purpose':'QUESTION','subject':'curfew start time','evidence_refs':refs}
        validations.append({'communication':c,'accepted':valid_communication(c,evidence)})
    save('authorization_controls.json', validations)
    # Capture current production request assembly without invoking dispatch.
    from game.live_chat_interpretation import interpret_production_turn
    requests=[]
    for r in selected:
        sid=r['turn_id'].split('.')[0]; n=int(r['turn_id'].split('.')[1])-1
        def capture(messages, *, estimated_input):
            requests.append({'turn_id':r['turn_id'], 'classification':'current source request reconstruction, not original provider messages', 'messages':messages,'estimated_input':estimated_input})
            return {'ok':False,'sent':False,'reason':'offline_capture_only'}
        with patch('game.live_chat_interpretation.production_live_interpretation_enabled', return_value=True), patch('game.live_chat_interpretation.request_interpretation', side_effect=capture):
            interpret_production_turn(player_text=r['player_input'],mode='AUTO',scene=scene,world=world,log=hist[sid][:n],session=copy.deepcopy(session if sid=='S05' else {'active_scene_id':'frontier_gate'}))
    save('current_request_reconstructions.json',requests)
    adapter_controls=[]
    for r in selected:
        sid=r['turn_id'].split('.')[0]; n=int(r['turn_id'].split('.')[1])-1
        raw=json.loads(hist[sid][n]['resolution']['metadata']['live_chat_interpretation']['raw_interpretation'])
        if sid=='S02':
            raw['communication'].update(purpose='QUESTION',subject='curfew start time' if n!=3 else 'Posted last-seen location of missing patrol',evidence_refs=[])
            raw['communication_mode']='OTHER';raw['action_components']=[];raw['clarification_question']=''
        else:
            raw['communication'].update(recipient='GM',purpose='CLARIFICATION',subject='Which account of the missing patrol?',evidence_refs=[])
            raw['communication_mode']='OTHER';raw['action_components']=[];raw['clarification_question']="Do you mean the runner's rumor, or what you wanted to learn from the notice board?"
        with patch('game.live_chat_interpretation.production_live_interpretation_enabled',return_value=True),patch('game.live_chat_interpretation.request_interpretation',return_value={'ok':True,'sent':False,'text':json.dumps(raw)}):
            s=copy.deepcopy(session if sid=='S05' else {'active_scene_id':'frontier_gate'})
            outcome=interpret_production_turn(player_text=r['player_input'],mode='AUTO',scene=scene,world=world,log=hist[sid][:n],session=s)
            decision=decision_from_interpretation_record(outcome.get('record'),player_text=r['player_input'],scene=scene,world=world,session=s).to_public_dict()
            adapter_controls.append({'turn_id':r['turn_id'],'exact_substituted_raw':raw,'adapter_outcome':outcome,'reconsidered_host_decision':decision})
    save('adapter_controls.json',adapter_controls)
save('deterministic_results.json', results)
after=manifest(); before=json.loads((OUT/'protected_before.json').read_text())
save('integrity.json',{'protected_file_count':len(before),'changed':[p for p,h in before.items() if after.get(p)!=h],'added_protected_files':sorted(set(after)-set(before)), 'network_guard':'socket.socket raises; all experiment arms completed','provider_calls':0,'disk_gameplay_writes':0})
print(json.dumps({'arms':len(results),'inputs_unchanged':all(r['inputs_unchanged'] for r in results),'protected_count':len(before),'changed':[p for p,h in before.items() if after.get(p)!=h]}))
