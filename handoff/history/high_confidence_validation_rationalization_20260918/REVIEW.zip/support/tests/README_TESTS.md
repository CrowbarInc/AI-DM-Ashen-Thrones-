# Running tests

For multi-surface changes, start with the [feature-lane verification guide](../docs/feature_lane_verification.md) to choose the correct owner tests, projection checks, replay/governance checks, and documentation lane before editing.

For governance artifact refreshes, generated reports, manifests, inventories, or registry-backed docs, use the [governance refresh workflow](../docs/governance_refresh_workflow.md) before changing commands or generated outputs.

## Test ownership rules (Blocks A–D)

These rules keep the suite maintainable without turning CI into a heavy transcript or harness gate.

- **Direct-owner tests** — Each governed seam has a **practical primary direct-owner** module (see `tests/TEST_AUDIT.md` and `tests/TEST_CONSOLIDATION_PLAN.md`). Those files own **detailed invariants** (schemas, layer order, legality families, helper semantics). Extend the owner first; avoid parallel “second homes” for the same contract.
- **Smoke tests** — Cross-layer and pipeline modules should assert **wiring and orchestration** only (routes, sequencing, presence of keys, thin post-transform smoke). They must not grow into duplicate full **legality matrices** already owned elsewhere.
- **Transcript tests** — Transcript- and harness-backed modules preserve **multi-turn story, ordering, and playability** behavior. Prefer structural or milestone checks over re-locking strings that a direct owner already pins.
- **Gauntlets and playability validation** — Behavioral gauntlets, manual gauntlets, and playability suites remain **end-to-end or slice harnesses** for behavior in motion; they complement—not replace—focused pytest owners.
- **Evaluators** — Offline evaluators (for example behavioral gauntlet and playability helpers) **score** deterministic slices; they must **not** become live **legality enforcement** or gate substitutes.
- **Downstream consumer suites** — Verify that a consumer **observes or ships** behavior through an owner boundary; they are **not** alternate homes for canonical invariants.
- **Compatibility residue suites** — Intentionally preserved historical coverage; **not** canonical ownership.
- **`general` in inventory** — `likely_architecture_layer: general` is a **weak heuristic bucket**, not a validation layer. Direct owners with a declared validation layer must not rest on `general` in the inventory (enforced by `tests/test_ownership_registry.py`).
- **New validation rules** — Before adding **broad** coverage across many files, add or extend **one canonical owner** for the new rule, then optional smoke elsewhere. `tests/test_ownership_registry.py` locks registry identity (required groups, derived index, inventory integration, governance errors, allowlist reasons, stable neighbor relationships). Cross-file duplicate `test_*` **base names** stay **heuristic** triage (derived at `py -3 tools/test_audit.py --check`; allowlisted pairs require reasons in `tests/ownership_registry_contract.py`); see `tests/TEST_AUDIT.md`.
- **Governance suite placement (CM8)** — Do **not** add structural import guards, gate magnet checks, replay projection policy, smoke-facade locks, or write-path parity tests to `tests/test_ownership_registry.py` by default. Use the focused owner module instead:

  | Policy domain | Owner test module |
  |---|---|
  | Registry identity + inventory integration | `tests/test_ownership_registry.py` |
  | Committed inventory JSON shape | `tests/test_inventory_governance.py` |
  | Gate magnet / smoke facade / downstream neighbor locks | `tests/test_gate_boundary_governance.py` |
  | Replay bridge / protected manifest / projection split | `tests/test_replay_boundary_governance.py` |
  | BU4 CSV / producer-stamp write-path parity | `tests/test_ownership_write_path_governance.py` |
  | BD/BV compat barrel / import-cap guards | `tests/test_compat_import_governance.py` |
  | BN gate-context / preflight import guards | `tests/test_gate_context_ownership_guards.py` |
  | BJ delegate closeout / thin-boundary locks | `tests/test_gate_delegate_closeout_locks.py` |

  The registry file includes `test_registry_module_scope_guard_identity_only` to reject accidental re-bloat.
- **Gate magnet guard (BA-7)** — Gate-layer **direct-owner** suites (for example `tests/test_final_emission_gate.py`) must not import replay read-side projection helpers (`tests/helpers/golden_replay_projection.py`, classifier, or dashboard helpers) or grow golden-replay/dashboard/classifier ownership assertions. FEM meta projection (`tests/test_final_emission_meta.py`) and gauntlet/classifier neighbors keep those contracts. Enforced by `tests/test_gate_boundary_governance.py` (`test_ba7_gate_direct_owners_*`).

**Quick maintenance loop (local, low noise):** `py -3 tools/test_audit.py` → `py -3 -m pytest tests/test_ownership_registry.py tests/test_inventory_governance.py tests/test_gate_boundary_governance.py tests/test_replay_boundary_governance.py tests/test_ownership_write_path_governance.py -q` → `python scripts/check_split_owner_acceptance_matrix.py` → `py -3 -m pytest --collect-only -q` → day-to-day `py -3 -m pytest -m "not transcript and not slow" -q`. Details: *Command cheat sheet* below and `tests/TEST_AUDIT.md`.

**Block C prompt / strict-social split (final):** strict-social **first-sentence** and **question-resolution** legality matrices live in `tests/test_social_exchange_emission.py`. `tests/test_prompt_and_guard.py` keeps **retry prompt text** for unresolved-question / social-contract failures, **`enforce_question_resolution_rule` prepend** behavior, **validator-voice detect/rewrite** at the GM layer, and thin smoke near the prompt stack for that boundary. **`apply_final_emission_gate` orchestration** remains owned by `tests/test_final_emission_gate.py`.

## Objective #12 — validation coverage (contributor workflow)

Objective #12 is **governance and tooling only**: it does **not** add a runtime layer, a policy engine, or a new scoring path.

- **`tests/validation_coverage_registry.py`** is the **canonical declaration layer** — one row per feature/domain, with `required_surfaces` and typed pointers (transcript modules, behavioral axes, manual gauntlet IDs, playability smoke node IDs, unit/integration paths). Human intent and machine checks both anchor here; update this file when coverage ownership changes.
- **`tools/validation_coverage_audit.py`** is the **canonical inspection layer** — reads the committed registry, runs `validate_entries`, prints summaries, per-feature views, surface filters, and declarative “likely commands”. It does **not** import `game/` or run evaluators.
- **Existing evaluators and harnesses** (for example `evaluate_playability`, `evaluate_behavioral_gauntlet`, transcript runners, manual rubrics) remain the **only scoring authorities**. The registry maps *what to run*; it does not rescore turns.
- **`optional_smoke_overlap`** is **secondary** to canonical ownership: use it for extra smoke pointers without pretending they own the feature’s defense.

**Repeatable loop:** validation-sensitive change → declare/update `tests/validation_coverage_registry.py` → `py -3 -m pytest tests/test_validation_coverage_registry.py -q` → `python tools/validation_coverage_audit.py --feature <feature_id>` → run the emitted tests/tools/scenarios → manual gauntlets when feel, prose, or player-facing behavior changed materially. Contract detail: [`docs/objective12_validation_contract.md`](../docs/objective12_validation_contract.md).

## Planner convergence — static audit (Block D)

Author-time only; **no runtime behavior**. Full maintainer notes: [`docs/planner_convergence.md`](../docs/planner_convergence.md).

**Audit:**

```bash
python tools/planner_convergence_audit.py
```

**Focused pytest** (contracts + manual-play convergence structure + plan-only prompt + static audit tests):

```bash
py -3 -m pytest tests/test_planner_convergence_contract.py tests/test_planner_convergence_live_pipeline.py tests/test_prompt_context_plan_only_convergence.py tests/test_planner_convergence_static_audit.py
```

**Optional Make** (same audit + same four tests): `make planner-convergence-check` from repo root.

CI runs the audit in `.github/workflows/content-lint.yml` (step **Planner convergence static audit**).

## Split-owner acceptance matrix contract (BU20/BU21)

Fast gate for split-owner matrix row counts, dashboard `{matrix_id}_split_owner` parity, checked-in audit report text, and lightweight classifier/dashboard builder surfaces. It does **not** run the opt-in failure dashboard probe suite.

**Discovery index:** [`docs/convergence_ci_inventory.md`](../docs/convergence_ci_inventory.md) → *Split-owner acceptance matrix governance* (CI entrypoint, local refresh, Make targets, contract tests, audit report).

**BU20/BU21 contract gate** (CI: `.github/workflows/convergence-checks.yml` step *Split-owner acceptance matrix contract (BU20/BU21)*; canonical command **`python scripts/check_split_owner_acceptance_matrix.py`**):

```bash
make split-owner-matrix-check
```

Equivalent: `python scripts/check_split_owner_acceptance_matrix.py` or `python -m pytest tests/test_split_owner_acceptance_matrix_contract.py -q -m split_owner_matrix_contract`.

The contract tests are **not** marked `transcript` or `slow`, so they also run under the default **fast lane** (`pytest -m "not transcript and not slow"`).

### Split-owner matrix change workflow (BU22/BU23/BU24)

When editing `SPLIT_OWNER_ACCEPTANCE_MATRIX` in `tests/helpers/failure_classification_sync.py`, follow this order (full detail: [`docs/audits/README.md`](../docs/audits/README.md)):

1. Update `SPLIT_OWNER_ACCEPTANCE_MATRIX` (matrix-only edits must not change production emission behavior).
2. Update dashboard evidence cells **only if** dashboard strings changed (`tests/test_failure_dashboard_controlled_failures.py`).
3. Regenerate and validate (Windows-native, no `make` required):

   ```bash
   python scripts/refresh_split_owner_acceptance_matrix.py
   ```

   Unix/mac/Git Bash equivalent: `make split-owner-matrix-refresh`. Partial modes: `--write-report-only`, `--check-only`, `--skip-pytest`.

4. Run focused affected tests only when projection/classifier/dashboard behavior changed (classifier, dashboard probes, FEM projection, golden replay — see audit README for commands).

**Refresh wrapper (BU24):** `scripts/refresh_split_owner_acceptance_matrix.py` performs report regeneration, the BU20/BU21 script gate, and the pytest contract slice (default). **Make targets (BU23):** delegate to the same wrapper where noted in `Makefile`.

**Copy/paste — registry pytest and audit CLI** (repo root; if `pytest` is not on `PATH`, use `py -3 -m pytest`):

```bash
py -3 -m pytest tests/test_validation_coverage_registry.py -q

python tools/validation_coverage_audit.py
python tools/validation_coverage_audit.py --strict

python tools/validation_coverage_audit.py --feature <feature_id>

python tools/validation_coverage_audit.py --missing transcript
python tools/validation_coverage_audit.py --missing behavioral_gauntlet

python tools/validation_coverage_audit.py --surface playability
```

`--surface` / `--missing` accept the same surface ids as the registry: `transcript`, `behavioral_gauntlet`, `manual_gauntlet`, `playability`, `unit_contract`, `integration_smoke` (the CLI also accepts hyphenated forms, e.g. `behavioral-gauntlet`). **`--strict`:** exit code **2** if `validate_entries` finds issues. For **`--feature`**, **`--surface`**, and **`--missing`**, when `--strict` is set and there are errors, the tool writes errors to **stderr** and exits **2** before printing the requested feature/surface list; the default **summary** (no mode flags) prints the full summary first, then reports validation OK/FAIL.

**Full lane** runs the whole suite. **Fast lane** excludes items marked `transcript` or `slow`. **Stricter fast** also excludes `brittle`. Marker definitions live in `pytest.ini`; scope and ownership notes are in `tests/TEST_AUDIT.md`. Routing and **repair/retry regression** ownership are settled (see `tests/TEST_CONSOLIDATION_PLAN.md` → *Block 3 — Routing* and *Repair / retry cluster — Block 3*).

**Post-AER Block C1:** Behavioral Gauntlet, Playability Validation, and AER are **complete** as validation tracks. Consolidation PRs target **orchestration** clarity, **telemetry/meta** normalization, and **test ownership** (**canonical owner** per module, **smoke overlap** only where layers differ)—see `docs/current_focus.md` and `docs/narrative_integrity_architecture.md` (**Post-AER Consolidation Rules**).

**Windows / Codex temp-root note:** `pytest.ini` supplies `--basetemp=codex_pytest_tmp`, so normal pytest runs use a repo-local temporary directory instead of the shared user temp root. This avoids Windows/Codex permission failures like `PermissionError` under `AppData\Local\Temp\pytest-of-...` without changing test behavior. If `pytest` is not on your `PATH`, use `py -3 -m pytest` instead of `pytest` for every command below (for example `py -3 -m pytest -m "not transcript and not slow"`). If neither launcher is on `PATH` in Codex, invoke the available Codex Python with `-m pytest` from the repo root and keep `PYTHONPATH` pointed at `.\.venv\Lib\site-packages`; the repo-local basetemp still comes from `pytest.ini`.

## Manual gauntlets (outside pytest)

Manual gauntlets are **not** part of pytest selection. Use them after changes that can **feel wrong in play** (lead follow-up, narration voice, speaker grounding, scene transitions) even when automated tests pass. Named scenarios, exact player prompt sequences, and pass/fail criteria live in [`docs/manual_gauntlets.md`](../docs/manual_gauntlets.md); the CLI surface is [`tools/run_manual_gauntlet.py`](../tools/run_manual_gauntlet.py).

## Behavioral gauntlet coverage (complete)

This repo has a **deterministic**, **contract-driven behavioral gauntlet stack** for compact narration-behavior diagnostics. Semantic calibration defines how semantic expectations are interpreted; this gauntlet detects enumerated patterns and is not an independent semantic authority. The main pieces are:

- Evaluator helper: `tests/helpers/behavioral_gauntlet_eval.py`
- Behavioral smoke tests: `tests/test_behavioral_gauntlet_smoke.py`
- Manual gauntlet source of truth: `docs/manual_gauntlets.md`
- Manual gauntlet runner: `tools/run_manual_gauntlet.py`

The evaluator covers four explicit axes:

- `neutrality`
- `escalation_correctness`
- `reengagement_quality`
- `dialogue_coherence`

### Automated smoke lane

`tests/test_behavioral_gauntlet_smoke.py` is marked `integration` and `regression`.

- **Layer A** uses direct simplified transcript rows.
- **Layer B** uses gauntlet-style payload compatibility slices.
- The lane is deterministic.
- It makes **no GPT calls**.
- It has **no transcript-runner dependency**.

The helper contract lives in `evaluate_behavioral_gauntlet(turns, *, expected_axis=None) -> dict` and is locked directly by `tests/test_behavioral_gauntlet_eval.py`.

### Manual gauntlet integration

Behavioral gauntlets `G9` through `G12` are available in the manual gauntlet registry.

`summary.json` may include:

- `axis_tags`
- advisory `behavioral_eval`
- `behavioral_eval_warning`

Behavioral evaluation in manual reports is **advisory only**. It helps reviewers spot narration-behavior seams, but it does **not** determine manual pass/fail by itself.

- For `G9` through `G12`, `behavioral_eval` is filtered to the gauntlet's tagged axis or axes.
- For gauntlets without `axis_tags`, `behavioral_eval` includes the full axis set.

### Transcript shaping behavior

Manual report attachment prefers simplified behavioral rows derived from snapshot-shaped records. If that shaping path fails for a row, the fallback path preserves the raw dict row instead. Evaluator failures are turned into compact warnings in `behavioral_eval_warning` and do **not** fail the gauntlet run.

### What this is / is not

**What this is:**

- deterministic behavior-in-motion smoke coverage
- advisory behavioral scoring for manual gauntlet reports
- compact transcript-slice evaluation
- regression support for narration-behavior seams

**What this is not:**

- not a live-model evaluation lane
- not a full transcript-runner lane
- not a replacement for human feel checks
- not a full playability certification
- not a new runtime architecture layer

### Recommended validation order

After narration / behavior changes:

1. Run the behavioral evaluator and smoke tests.
2. Run gauntlet regressions and manual report tests.
3. Run manual gauntlet spot-checks if prose feel materially changed.

Copy/paste commands:

```bash
py -3 -m pytest tests/test_behavioral_gauntlet_eval.py tests/test_behavioral_gauntlet_smoke.py -q
py -3 -m pytest tests/test_manual_gauntlet_report.py tests/test_manual_gauntlet_aggregation.py -q
py -3 tools/run_manual_gauntlet.py --list
```

## Playability tests (complete)

### Playability Tests

**Location:** `tests/test_playability_smoke.py`

**Status:** Complete as a supporting-evidence layer. The suite remains the canonical executor of turn-scoped playability scoring, but PASS is not independent proof of player-facing acceptability.

**Characteristics:**

- integration-level
- evaluator-driven
- non-brittle assertions

These tests:

- score bounded behavioral-quality signals under controlled inputs
- do **not** enforce exact phrasing
- rely entirely on `evaluate_playability(...)`

### Important Notes

- The escalation test includes a **scoped** emission-gate bypass (`apply_final_emission_gate`), required to observe meaningful variation across pressured turns
- Other tests use the full pipeline unmodified

### Commands

```bash
pytest tests/test_playability_smoke.py -q
```

## Golden replay

**Canonical governance inventory:** [`docs/convergence_ci_inventory.md`](../docs/convergence_ci_inventory.md) (protected replay CI step, local parity; [split-owner matrix governance](../docs/convergence_ci_inventory.md#split-owner-acceptance-matrix-governance) for cross-family owner literals).

Protected replay is a controlled structural acceptance lane. It protects canonical turn-routing and final-emission invariants across repair cycles: speaker/target selection, route kind, FEM/fallback metadata, scaffold leakage, action/answer survival, compact scenario-spine branch structure, and the protected 20-turn Frontier Gate long-session stability lane. Its GM text is deterministic/stubbed in ordinary CI, so PASS does not establish production-model semantic quality, narrative quality, human playability, or live AI-GM behavior. It does **not** lock exact final prose by default; exact text comparison is opt-in, while structural drift is the primary signal.

Metadata ownership is intentionally split. Golden replay uses `scenario_id`; scenario-spine fixtures use `spine_id`, `branch_id`, and per-turn `turn_id`; the N1 synthetic lane uses `scenario_spine_id` and remains advisory rather than protected golden replay. Text projections are also layer-specific: `player_facing_text` is runtime response output, `gm_text` is snapshot/transcript output, and `final_text` is the golden replay assertion surface.

The Frontier Gate 20-turn social-inquiry replay is protected golden replay backed by `data/validation/scenario_spines/frontier_gate_long_session.json`. Protected replay failure reports may include `source_path`, `branch_id`, and `turn_id` when fixture identity is available.

Protected scenario ownership is declared in [`docs/testing/protected_replay_manifest.md`](../docs/testing/protected_replay_manifest.md). Controlled structural replay remains a required hard-fail CI check in `.github/workflows/convergence-checks.yml`: failure means an acceptance-protected structural replay invariant or its currently co-located contract coverage failed, so the change must not be accepted until resolved.

From repo root:

```bash
python -m pytest tests/test_golden_replay.py -q
```

The suite is marked `golden_replay`, so this equivalent marker filter also works:

```bash
python -m pytest -m golden_replay -q
```

### Replay validation

Use these lanes after protected replay helper, report, or metadata-doc changes:

| Goal | Command |
|------|---------|
| Focused golden replay file | `python -m pytest tests/test_golden_replay.py -q --tb=short` |
| Protected marker lane | `python -m pytest -m golden_replay -q --tb=short` |
| Replay diagnostics | `python -m pytest tests/test_failure_dashboard_controlled_failures.py tests/test_failure_classifier.py tests/test_failure_classification_contract.py -q --tb=short` |
| Scenario-spine replay-adjacent slice | `python -m pytest tests/test_scenario_spine_contracts.py tests/test_scenario_spine_eval.py tests/test_run_scenario_spine_validation.py tests/test_scenario_spine_opening_convergence.py tests/test_scenario_spine_continuation_convergence.py -q --tb=short` |
| Broader replay-adjacent safety slice | `python -m pytest tests/test_transcript_regression.py tests/test_transcript_gauntlet_actor_addressing.py tests/test_transcript_gauntlet_campaign_cleanliness.py tests/test_narration_transcript_regressions.py tests/test_n1_scenario_spine_validation.py tests/test_n1_scenario_spine_cli.py -q --tb=short` |

CI uses the marker-selected command above so future protected replay modules can join the required lane without changing the workflow command. Use the same command locally to reproduce a protected replay CI failure.

When the protected replay CI step fails, the `convergence-checks` workflow preserves K3A diagnostics as the `protected-replay-failure-report` Actions artifact, sourced from `artifacts/golden_replay/replay_failure_report.md`. The artifact appears only for a failed protected replay step; it is not published on success, and an absent report cannot replace the underlying hard-fail result.

Historical replay baseline archived; current protected replay authority is [`docs/testing/protected_replay_manifest.md`](../docs/testing/protected_replay_manifest.md). Archived baseline: [`docs/archive/dead_governance/2026-05-31/golden_replay_baseline_2026-05-11.md`](../docs/archive/dead_governance/2026-05-31/golden_replay_baseline_2026-05-11.md).

## Failure Classification Dashboard

**Canonical governance inventory:** [`docs/convergence_ci_inventory.md`](../docs/convergence_ci_inventory.md) → [Split-owner acceptance matrix governance](../docs/convergence_ci_inventory.md#split-owner-acceptance-matrix-governance) (split-owner dashboard parity and classifier alignment).

The failure classification dashboard is a replay-side diagnostic layer for golden replay drift.  It turns existing golden replay drift rows plus replay-visible observation fields into deterministic rows with category, severity, owner, and first investigation target.

It is additive to golden replay: replay assertions still decide pass/fail, while the classifier explains classified failures when drift rows exist.  The dashboard consumes existing signals such as route/speaker fields, FEM metadata, fallback metadata, unavailable fields, and replay tags.  It does not call runtime systems or mutate game behavior.

Run the classifier-focused tests from repo root:

```bash
python -m pytest tests/test_failure_classifier.py -q
```

Generate the latest dashboard artifact intentionally:

```bash
python -m pytest -m golden_replay -q --write-failure-dashboard
```

or with the environment variable:

```bash
ASHEN_WRITE_FAILURE_DASHBOARD=1 python -m pytest -m golden_replay -q
```

Both opt-in paths write [`audits/failure_dashboard_latest.md`](../audits/failure_dashboard_latest.md). Normal test runs do not write this artifact. If no replay failures are classified, the artifact says `No replay failures classified.`

Owner meanings are deterministic diagnostic ownership labels. The primary owner is the earliest legitimate fault location visible from replay signals; the secondary owner is optional boundary context. Examples include `route`, `speaker`, `fallback`, `emission`, `sanitizer`, `validator`, `projection`, `continuity`, and `replay`.

What the dashboard does **not** do:

- It is not a live runtime telemetry system.
- It is not an evaluator, scoring layer, or AI judge.
- It does not repair output, change routing, change speaker behavior, or alter final emission.
- It does not infer hidden runtime state beyond existing replay predicates and projected metadata.

### Controlled Failure Dashboard Probes

Controlled failure probes are known-bad replay-shaped rows used to validate the dashboard itself. They do **not** modify production fixtures, golden replay baseline scenarios, runtime generation, routing, speaker behavior, sanitizer behavior, or final emission.

They are opt-in because they intentionally model failures. A normal full test run collects them as skipped unless you explicitly ask for the probe suite.

Run the probe file directly:

```bash
python -m pytest tests/test_failure_dashboard_controlled_failures.py -q
```

or by marker:

```bash
python -m pytest -m failure_dashboard_probe -q
```

Generate a latest dashboard from the probe rows:

```bash
python -m pytest -m failure_dashboard_probe -q --write-failure-dashboard
```

The committed sample artifact is [`audits/failure_dashboard_probe_sample.md`](../audits/failure_dashboard_probe_sample.md). It demonstrates category, severity, owners, investigation targets, replay tags, evidence, and unavailable-field handling for deterministic known-bad cases.

### Failure Classification Contract

The dashboard taxonomy is contract-locked in [`tests/failure_classification_contract.py`](failure_classification_contract.py). That file defines the allowed categories, owners, severities, replay tags, source-family tags, required row fields, and optional evidence fields.

New classifier rules that introduce a category, owner, severity, replay tag, source family, or evidence field must update the contract and the contract tests in [`tests/test_failure_classification_contract.py`](test_failure_classification_contract.py). The validation helper `validate_failure_classification_row(...)` checks emitted rows before dashboard rendering, so invalid taxonomy or missing required fields fail near the report boundary.

The controlled failure probes verify behavior on known-bad rows; the contract tests prevent silent drift in row shape, taxonomy, owners, severities, replay tags, and key dashboard columns.

## Full lane

**When:** Pre-merge, milestones, or whenever you need the full regression surface (transcript harnesses, gauntlets, expensive flows).

From repo root:

```bash
pytest
```

Same thing with an explicit path:

```bash
pytest tests/
```

Both commands inherit `--basetemp=codex_pytest_tmp` from `pytest.ini`; do not add a shared user-temp override for local/Codex runs.

**Collect only:**

```bash
pytest --collect-only -q
```

Exact suite counts change over time; use `pytest --collect-only`, `py -3 tools/test_audit.py --check` (prints derived counts), or committed `tests/test_inventory_governance.json` for registry-owned file rows (regenerate via `py -3 tools/test_audit.py`) after large suite changes. See `tests/TEST_AUDIT.md` → *Block 3 — Fast/full workflow verification*.

## Fast lane

**When:** Day-to-day feedback without transcript-harness modules and modules marked `slow`.

**Selection:** Everything except tests on classes/functions/modules marked `transcript` or `slow`.

```bash
pytest -m "not transcript and not slow"
```

**Collect only:**

```bash
pytest --collect-only -m "not transcript and not slow" -q
```

Exact counts drift as modules are added; prefer the live collect-only output over hard-coded numbers.

## Optional stricter fast lane (`brittle`)

When prompt- or prose-sensitive tests are too noisy locally:

```bash
pytest -m "not transcript and not slow and not brittle"
```

## Synthetic-player harness (`synthetic`)

The synthetic-player helpers under `tests/helpers/` are **test/tooling infrastructure only** (no `game/` coupling in the scaffold). They are meant to drive or evaluate automated “synthetic players” alongside `tests/helpers/transcript_runner.py`, not to add gameplay modes.

- **`py -m pytest -q` includes synthetic-player tests:** `pytest.ini` only adds `-q` (no marker filter). You get `tests/test_synthetic_sessions.py`, `tests/test_synthetic_policy.py`, and `tests/test_synthetic_smoke.py` (the last is `slow`). The fast lane `-m "not transcript and not slow"` skips `test_synthetic_smoke.py` but still runs the two lighter synthetic modules.
- The primary harness runner surface is `run_synthetic_session(...)`; `run_placeholder_session(...)` remains compatibility-only.
- Synthetic pytest smoke coverage is deterministic and fake-GM-backed by default.
- For manual exploratory runs, use `tools/run_synthetic_session.py` (defaults to fake-GM mode; real-GM mode is explicit opt-in via `--real-gm`).

### Manual CLI examples

```bash
# Default deterministic fake-GM run
python tools/run_synthetic_session.py

# Explicit real-GM exploratory run
python tools/run_synthetic_session.py --real-gm

# Use a non-default synthetic profile
python tools/run_synthetic_session.py --profile risk_taker

# Pin deterministic run parameters
python tools/run_synthetic_session.py --seed 1337 --max-turns 12
```

Fake-GM mode is for deterministic harness validation; real-GM mode is exploratory and may be less stable run-to-run.

### Recommended synthetic lanes

Use these marker slices to keep the synthetic workflow explicit without changing fast/full lane boundaries.

- **Fake-GM synthetic lane** (`synthetic and not transcript and not slow`)  
  Deterministic regression signal for day-to-day harness confidence.
- **Transcript-backed synthetic lane** (`synthetic and transcript`)  
  Lightweight real-path health checks (materially slower than fake-GM).
- **Full synthetic lane** (`synthetic`)  
  Everything tagged synthetic, across fake-GM and transcript-backed tests.
- **Manual CLI lane** (`tools/run_synthetic_session.py`)  
  Exploratory work outside pytest selection.

Quick run guidance:
- Run the **fake-GM synthetic lane** for routine local feedback and deterministic harness confidence.
- Run the **transcript-backed synthetic lane** when validating real-path wiring or bug/risk-sensitive social routing signals.
- Run the **full synthetic lane** before merge when harness, scenario presets, or policy behavior changes span both lanes.

Copy/paste commands:

```bash
# Deterministic synthetic non-transcript runs (recommended fake-GM lane)
pytest -m "synthetic and not transcript and not slow"

# Transcript-backed synthetic runs
pytest -m "synthetic and transcript"

# All synthetic runs
pytest -m "synthetic"

# One-file focused synthetic run
pytest tests/test_synthetic_smoke.py

# Runner / preset regression (fast synthetic; not transcript-backed)
pytest tests/test_synthetic_sessions.py
```

- **End-to-end** synthetic sessions (multi-turn, real `chat` / transcript loops) should usually be marked **`synthetic`** and **`slow`** so they stay out of the default fast lane (`not transcript and not slow`).
- **Unit tests** for the harness itself (imports, shapes, pure policy stubs) can stay **fast**: mark them `synthetic` and `unit` without `slow` if they do not run multi-turn sessions.

Optional stricter selection: add `and not synthetic` to a local fast-lane command if you want to skip all harness-tagged tests.

## What “trustworthy” means for fast vs full

**Lane trustworthiness is about composition and selection** — which tests the marker expression includes or excludes — **not** about the whole fast lane being green. A red test in the fast lane is still a real failure; it is **orthogonal** to whether the fast/full split matches intent (exclude transcript + slow from fast; run everything on full).

## Where to add new tests

When recording **which scenarios defend which feature** (Objective #12), update `tests/validation_coverage_registry.py` per [`docs/objective12_validation_contract.md`](../docs/objective12_validation_contract.md).

See `tests/TEST_AUDIT.md` → *Consolidation Block 1 — Canonical ownership map & overlap hotspots* for **canonical owner** themes and **smoke overlap** guidance. **Test ownership & audit (Blocks A–D)** are **complete** for the consolidation pass: **inventory schema v2** (`summary.inventory_schema_version`, `declared_pytest_markers`, per-file `likely_architecture_layer`, `marker_set`, `ownership_registry_positions`, top-level `ownership_registry_index`, `block_b_overlap_clusters`, `import_hub_modules`) plus governance pytest and doc pointers; see *Test ownership rules* above and `tests/TEST_CONSOLIDATION_PLAN.md` → *Test Ownership & Coverage Consolidation*. **Next consolidation order (Block C1):** emit-path **orchestration** / metadata + **telemetry** alignment (doc-driven) → prompt/sanitizer → social/emission → transcript duplicate assertion thinning → **lead/clue `deferred`** last (repair/retry cluster documented and closed enough — see `tests/TEST_CONSOLIDATION_PLAN.md` → *Next consolidation order* and *Repair / retry cluster — Block 3*).

## Command cheat sheet

| Goal | Command |
|------|---------|
| **Test audit (regenerate inventory)** | `py -3 tools/test_audit.py` |
| **Ownership registry governance** | `py -3 -m pytest tests/test_ownership_registry.py tests/test_inventory_governance.py tests/test_gate_boundary_governance.py tests/test_replay_boundary_governance.py tests/test_ownership_write_path_governance.py -q` |
| **Split-owner matrix refresh (BU24, Windows-native)** | `python scripts/refresh_split_owner_acceptance_matrix.py` |
| **Split-owner matrix report only** | `python scripts/refresh_split_owner_acceptance_matrix.py --write-report-only` |
| **Split-owner matrix refresh (Make)** | `make split-owner-matrix-refresh` |
| **Split-owner matrix contract** | `python scripts/check_split_owner_acceptance_matrix.py` or `make split-owner-matrix-check` |
| **Split-owner matrix contract (pytest)** | `python -m pytest tests/test_split_owner_acceptance_matrix_contract.py -q -m split_owner_matrix_contract` |
| **Full lane** | `pytest` or `pytest tests/` (uses repo-local `codex_pytest_tmp` from `pytest.ini`) |
| **Full lane, collect only** | `pytest --collect-only -q` |
| **Fast lane** | `pytest -m "not transcript and not slow"` |
| **Fast lane, collect only** | `pytest --collect-only -m "not transcript and not slow" -q` |
| **Stricter fast** (optional) | `pytest -m "not transcript and not slow and not brittle"` |
| **Transcript / slow slice** | `pytest -m "transcript or slow"` (complement of fast selection) |
| **Transcript only** | `pytest -m "transcript"` |
| **Slow only** | `pytest -m "slow"` |
| **Exclude transcript only** | `pytest -m "not transcript"` |
| **Synthetic fake-GM lane** | `pytest -m "synthetic and not transcript and not slow"` |
| **Synthetic transcript lane** | `pytest -m "synthetic and transcript"` |
| **All synthetic** | `pytest -m "synthetic"` |
| **Synthetic one-file focus** | `pytest tests/test_synthetic_smoke.py` |
| **All tagged unit + regression** | `pytest -m "unit or regression"` |
| **Narrow legacy filter** (not equivalent to fast lane) | `pytest -m "(unit or regression) and not transcript"` — omits many integration-only modules; see `tests/TEST_AUDIT.md` |

## Marker meanings (lane-relevant)

- **unit** / **integration** / **regression** — Scope and signal density; **not** the fast-lane gate. Use for inventory, filters like `pytest -m regression`, and documentation.
- **transcript** — Transcript harness / gauntlet-style modules (**fast lane excludes**).
- **synthetic** — Synthetic-player harness and automation-owned checks (tag for ownership; fast lane does **not** exclude unless you add `not synthetic`).
- **slow** — Longer or expensive runs (**fast lane excludes**).
- **brittle** — Prompt/prose-sensitive (**optional** extra exclusion for stricter fast).
- **split_owner_matrix_contract** — Fast BU20 split-owner matrix/report/dashboard parity gate (**included in fast lane**; refresh via `python scripts/refresh_split_owner_acceptance_matrix.py` or `make split-owner-matrix-refresh`).

Ownership markers (`routing`, `retry`, `fallback`, …) are for inventory and feature tagging only — **not** for choosing fast vs full. See `pytest.ini` for the full list.

The expression `(unit or regression) and not transcript` is **narrower** than the fast lane: many fast-eligible modules are integration-only and would be skipped.
