# Current Failure Classification

Observed command: `python -m pytest -q --tb=short`

Observed result: **49 failures** from **6433 collected cases**.

## By likely cause

| Classification | Count |
|---|---:|
| CURRENT_ARCHITECTURE_REGRESSION | 9 |
| CURRENT_PRODUCT_REGRESSION | 7 |
| DOCUMENTATION_DRIFT | 13 |
| REGISTRY_GOVERNANCE_DRIFT | 9 |
| STALE_EXPECTATION | 9 |
| STALE_FIXTURE | 1 |
| UNCERTAIN | 1 |

## By confidence

| Confidence | Count |
|---|---:|
| HIGH | 26 |
| LOW | 2 |
| MEDIUM | 21 |

## By validation family

| Family | Count |
|---|---:|
| `ARCHITECTURE_GOVERNANCE` | 4 |
| `FINAL_EMISSION_CONTRACTS` | 6 |
| `GENERATED_CLOSEOUT_ASSERTIONS` | 13 |
| `GOLDEN_PROTECTED_REPLAY` | 2 |
| `OWNERSHIP_IMPORT_GOVERNANCE` | 6 |
| `PLAYABILITY_RUNTIME` | 1 |
| `PYTEST_COMPONENT_CONTRACT` | 4 |
| `REPLAY_PROJECTION_DIAGNOSTICS` | 13 |

## Interpretation

The baseline is heterogeneous: 13 failures are legacy closeout-document drift, while the remainder mixes current product defects, current architecture violations, stale snapshots/expectations, registry drift, and unresolved cases. The audit identifies 7 likely current product regressions and 9 likely current architecture regressions, but only 9 of those 16 are high-confidence; the rest require owner confirmation or reproduction before repair. The count must not be read as either 49 product defects or 49 harmless stale tests.

This is an audit classification, not a waiver. No failing test was disabled, repaired, or silently downgraded.
