"""Bounded incidental interlocutors under PR-BN authority.

A player reference is a proposed interaction target. This module decides
whether that target is already canonical, may exist as a minimal incidental
person, or must be refused. It does not invent biographies, and it does not
let player language establish consequential world truth.
"""
from __future__ import annotations

import hashlib
import re
from typing import Any, Mapping, Sequence

from game.bounded_improvisation import (
    CONSEQUENTIAL_TERMS,
    HIDDEN_INFO_TERMS,
    ensure_bounded_improvisation_ledger,
    validate_bounded_improvisation_proposal,
)

BIND_CANONICAL = "bound_canonical"
BIND_INCIDENTAL = "bound_incidental"
BIND_UNRESOLVED = "unresolved"
BIND_AMBIGUOUS = "ambiguous"
BIND_REJECTED = "rejected_consequential"

CLASS_CANONICAL = "canonical_established"
CLASS_INCIDENTAL = "permitted_bounded_incidental"
CLASS_CONSEQUENTIAL = "unsupported_consequential"
CLASS_AMBIGUOUS = "ambiguous_unresolved"

_POPULATED_RE = re.compile(
    r"\b(?:crowd|crowds|traffic|refugees|travelers|travellers|wagons|market|"
    r"square|street|tavern|dock|patrons|residents|people|gathering|bustle|"
    r"throng|queue|clamor|shoppers|vendors)\b",
    re.IGNORECASE,
)
_ISOLATED_RE = re.compile(
    r"\b(?:sealed|abandoned|deserted|uninhabited|nobody|no one)\b"
    r"|\bempty\b"
    r"|\blocked\b.{0,32}\b(?:crypt|tomb|chamber)\b"
    r"|\b(?:isolated|private|royal)\b.{0,32}\b(?:shrine|chamber|crypt|ruin)\b"
    r"|\b(?:crypt|ruin|ruins)\b.{0,48}\b(?:empty|sealed|abandoned|deserted)\b",
    re.IGNORECASE,
)
_PLOT_ASSERTION_RE = re.compile(
    r"\bwho\s+(?:killed|murdered|slew|ordered|betrayed|poisoned|assassinated)\b"
    r"|\b(?:killed|murdered|ordered)\s+the\b"
    r"|\b(?:working|works|worked)\s+for\b"
    r"|\bknows?\s+the\s+(?:secret|hidden)\b",
    re.IGNORECASE,
)
_AUTHORITY_OFFICE_RE = re.compile(
    r"\b(?:king|queen|duke|baron)(?:'s|s)?\s+(?:secret\s+)?(?:adviser|advisor|commander|minister)\b"
    r"|\b(?:secret|hidden)\s+(?:adviser|advisor|commander)\b"
    r"|\bcommander\s+of\s+the\b"
    r"|\bmagistrate\b"
    r"|\bofficer\s+who\b"
    r"|\brebel\s+cell\b",
    re.IGNORECASE,
)
_HUMAN_RE = re.compile(
    r"\b(?:man|woman|person|people|figure|someone|somebody|child|boy|girl|lad|fellow|one)\b",
    re.IGNORECASE,
)
_INANIMATE_RE = re.compile(
    r"\b(?:road|gate|board|notice|door|crate|barrel|wall|banner|rain|wagon|crowd|"
    r"queue|steps|stone|sign|paper|track|mud|sky|ground|street|square|bridge|"
    r"window|lantern|roster|floor|ceiling)\b",
    re.IGNORECASE,
)
_LEADING = frozenset(
    {"the", "a", "an", "that", "this", "one", "of", "passing", "nearby", "nearest", "some"}
)


def _clean(value: Any, *, limit: int = 120) -> str:
    return " ".join(str(value or "").split())[:limit]


def _tokens(text: str) -> list[str]:
    return re.findall(r"[a-z0-9']+", str(text or "").lower())


def _scene_body(scene: Mapping[str, Any] | None) -> Mapping[str, Any]:
    if not isinstance(scene, Mapping):
        return {}
    inner = scene.get("scene")
    if isinstance(inner, Mapping):
        return inner
    return scene


def public_scene_text(scene: Mapping[str, Any] | None) -> str:
    """Population evidence from public scene text. Hidden facts are ignored."""
    body = _scene_body(scene)
    parts: list[str] = []
    for key in ("summary", "location", "mode"):
        text = _clean(body.get(key), limit=400)
        if text:
            parts.append(text)
    for key in ("visible_facts", "opening_seed_facts", "journal_seed_facts"):
        values = body.get(key)
        if isinstance(values, list):
            parts.extend(_clean(item, limit=400) for item in values if _clean(item, limit=400))
    return " ".join(parts)


def scene_population(scene: Mapping[str, Any] | None) -> str:
    text = public_scene_text(scene)
    populated = bool(_POPULATED_RE.search(text))
    isolated = bool(_ISOLATED_RE.search(text))
    if isolated and not populated:
        return "isolated"
    if populated and not isolated:
        return "populated"
    if populated and isolated:
        return "mixed"
    return "unknown"


def consequential_reference(span: str) -> bool:
    """A reference that asserts plot, office, or hidden truth."""
    raw = str(span or "")
    if not raw:
        return False
    if _PLOT_ASSERTION_RE.search(raw) or _AUTHORITY_OFFICE_RE.search(raw):
        return True
    if CONSEQUENTIAL_TERMS.search(raw) or HIDDEN_INFO_TERMS.search(raw):
        return True
    return False


def _content_words(text: str) -> list[str]:
    return [word for word in _tokens(text) if word not in _LEADING and len(word) > 2]


def _stem(word: str) -> str:
    if len(word) > 4 and word.endswith("s") and not word.endswith("ss"):
        return word[:-1]
    return word


def _raw_head(text: str) -> str:
    words = _content_words(text)
    return words[-1] if words else ""


def _head(text: str) -> str:
    return _stem(_raw_head(text))


def person_shaped(nominal: str, catalog: Sequence[Mapping[str, Any]] | None = None) -> bool:
    """An addressed individual, not a place, object, or crowd."""
    label = _clean(nominal, limit=80)
    words = _content_words(label)
    if not words:
        return False
    head = _raw_head(label)
    if _INANIMATE_RE.search(head) and not _HUMAN_RE.search(label):
        return False
    if not _HUMAN_RE.search(label) and _INANIMATE_RE.search(head):
        return False
    for row in catalog or ():
        if not isinstance(row, Mapping) or str(row.get("type") or "") != "object":
            continue
        object_words = _content_words(str(row.get("label") or row.get("id") or ""))
        if object_words and object_words == words:
            return False
    if _INANIMATE_RE.fullmatch(head) and not _HUMAN_RE.search(label):
        return False
    if _HUMAN_RE.search(label):
        return True
    return not _INANIMATE_RE.search(head)


def _entity_id(scene_id: str, label: str) -> str:
    key = " ".join(_content_words(label))
    digest = hashlib.sha1(f"{scene_id}|{key}".encode("utf-8")).hexdigest()[:10]
    return f"inc_{digest}"


def _records(session: Mapping[str, Any] | None, scene_id: str) -> list[dict[str, Any]]:
    ledger = session.get("bounded_improvisation") if isinstance(session, Mapping) else None
    rows = ledger.get("incidental_entities") if isinstance(ledger, Mapping) else None
    if not isinstance(rows, list):
        return []
    current = str(scene_id or "").strip()
    found: list[dict[str, Any]] = []
    for row in rows:
        if not isinstance(row, Mapping):
            continue
        if current and str(row.get("scene_id") or "") not in {"", current}:
            continue
        found.append(dict(row))
    return found


def incidental_catalog_rows(
    session: Mapping[str, Any] | None,
    scene_id: str | None = None,
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for record in _records(session, str(scene_id or "")):
        label = _clean(record.get("label") or record.get("role"), limit=80)
        ident = _clean(record.get("entity_id"), limit=80)
        if not ident or not label:
            continue
        rows.append(
            {
                "type": "interlocutor",
                "id": ident,
                "label": label,
                "aliases": [label],
                "source": "bounded_incidental",
            }
        )
    return rows


def _match_existing(nominal: str, records: Sequence[Mapping[str, Any]]) -> tuple[str, dict[str, Any] | None]:
    head = _head(nominal)
    if not head:
        return "none", None
    hits: list[dict[str, Any]] = []
    for record in records:
        label = str(record.get("label") or "")
        if _head(label) == head or " ".join(_content_words(label)) == " ".join(_content_words(nominal)):
            hits.append(dict(record))
    unique: list[dict[str, Any]] = []
    seen: set[str] = set()
    for record in hits:
        ident = str(record.get("entity_id") or "")
        if ident in seen:
            continue
        seen.add(ident)
        unique.append(record)
    if len(unique) > 1:
        return "ambiguous", None
    if len(unique) == 1:
        return "one", unique[0]
    return "none", None


def _empty_binding(nominal: str, span: str) -> dict[str, Any]:
    return {
        "status": BIND_UNRESOLVED,
        "entity_class": CLASS_AMBIGUOUS,
        "proposed_interlocutor": nominal or None,
        "proposed_span": span or None,
        "bound_interlocutor_id": None,
        "entity_id": None,
        "label": None,
        "explicit_new_interlocutor": bool(nominal),
        "authority_reasons": [],
        "catalog_row": None,
    }


def resolve_proposed_interlocutor(
    nominal: str,
    span: str,
    *,
    scene: Mapping[str, Any] | None,
    session: Mapping[str, Any] | None,
    scene_id: str,
    catalog: Sequence[Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    """PR-BN decision for a player-proposed person who is not already canonical."""
    label = _clean(nominal, limit=80)
    full = _clean(span or nominal, limit=180)
    binding = _empty_binding(label, full)
    if not label:
        binding["authority_reasons"] = ["proposal:empty"]
        return binding
    if consequential_reference(full):
        binding["status"] = BIND_REJECTED
        binding["entity_class"] = CLASS_CONSEQUENTIAL
        binding["authority_reasons"] = ["proposal:consequential"]
        return binding
    kind, existing = _match_existing(label, _records(session, scene_id))
    if kind == "ambiguous":
        binding["status"] = BIND_AMBIGUOUS
        binding["entity_class"] = CLASS_AMBIGUOUS
        binding["authority_reasons"] = ["proposal:ambiguous_existing"]
        return binding
    if kind == "one" and existing:
        binding.update(
            {
                "status": BIND_INCIDENTAL,
                "entity_class": CLASS_INCIDENTAL,
                "bound_interlocutor_id": existing.get("entity_id"),
                "entity_id": existing.get("entity_id"),
                "label": existing.get("label") or label,
                "authority_reasons": ["identity:existing_incidental"],
                "catalog_row": {
                    "type": "interlocutor",
                    "id": existing.get("entity_id"),
                    "label": existing.get("label") or label,
                    "aliases": [existing.get("label") or label],
                    "source": "bounded_incidental",
                },
            }
        )
        return binding
    if not person_shaped(label, catalog):
        binding["authority_reasons"] = ["proposal:not_a_person"]
        return binding
    population = scene_population(scene)
    if population != "populated":
        binding["authority_reasons"] = [f"scene:{population}"]
        return binding
    decision = validate_bounded_improvisation_proposal(
        {
            "kind": "incidental_fact",
            "category": "background_npc_detail",
            "content": label,
            "scope": "scene",
            "consequence_level": "incidental",
            "source": "player_proposed_interlocutor",
        },
        session=session,
        scene=scene,
        world=None,
    )
    if not decision.accepted:
        reasons = list(decision.reason_codes)
        if any(code.startswith("content:consequential") or code.startswith("content:hidden") for code in reasons):
            binding["status"] = BIND_REJECTED
            binding["entity_class"] = CLASS_CONSEQUENTIAL
        binding["authority_reasons"] = reasons or ["pr_bn:rejected"]
        return binding
    ident = _entity_id(scene_id, label)
    binding.update(
        {
            "status": BIND_INCIDENTAL,
            "entity_class": CLASS_INCIDENTAL,
            "bound_interlocutor_id": ident,
            "entity_id": ident,
            "label": label,
            "authority_reasons": ["scene:populated", "pr_bn:accepted"],
            "catalog_row": {
                "type": "interlocutor",
                "id": ident,
                "label": label,
                "aliases": [label],
                "source": "bounded_incidental",
            },
        }
    )
    return binding


def persist_incidental_binding(
    session: dict[str, Any] | None,
    binding: Mapping[str, Any] | None,
    scene_id: str | None,
) -> dict[str, Any] | None:
    """Store the minimal continuity record. Rejected proposals are not stored."""
    if not isinstance(session, dict) or not isinstance(binding, Mapping):
        return None
    if str(binding.get("status") or "") != BIND_INCIDENTAL:
        return None
    ident = _clean(binding.get("entity_id") or binding.get("bound_interlocutor_id"), limit=80)
    label = _clean(binding.get("label"), limit=80)
    if not ident or not label:
        return None
    current = _clean(scene_id, limit=80)
    ledger = ensure_bounded_improvisation_ledger(session)
    entities = ledger.setdefault("incidental_entities", [])
    for row in entities:
        if isinstance(row, Mapping) and str(row.get("entity_id") or "") == ident:
            return dict(row)
    record = {
        "entity_id": ident,
        "label": label,
        "role": label,
        "scene_id": current,
        "provenance": "bounded_incidental",
        "authority": "bounded_improvisation",
        "kind": "incidental_fact",
        "category": "background_npc_detail",
        "truth_status": "runtime_incidental",
        "consequence_level": "incidental",
    }
    entities.append(record)
    entries = ledger.setdefault("entries", [])
    if not any(isinstance(row, Mapping) and str(row.get("id") or "") == ident for row in entries):
        entries.append(
            {
                "id": ident,
                "kind": "incidental_fact",
                "category": "background_npc_detail",
                "content": label,
                "scope": "scene",
                "scene_id": current or None,
                "consequence_level": "incidental",
                "source": "player_proposed_interlocutor",
                "status": "promoted",
                "authority": "bounded_improvisation",
                "truth_status": "runtime_incidental",
            }
        )
    return dict(record)


def apply_entity_binding(
    resolution: dict[str, Any] | None,
    session: dict[str, Any] | None,
    *,
    scene_id: str | None = None,
) -> None:
    """Make a validated incidental interlocutor the speaker for this turn.

    An explicit address that did not bind clears the previous speaker instead
    of leaving that speaker in place.
    """
    if not isinstance(resolution, dict):
        return
    metadata = resolution.get("metadata") if isinstance(resolution.get("metadata"), Mapping) else {}
    contract = metadata.get("resolution_contract") if isinstance(metadata, Mapping) else None
    if not isinstance(contract, Mapping):
        return
    construction = contract.get("construction") if isinstance(contract.get("construction"), Mapping) else {}
    binding = construction.get("entity_binding") if isinstance(construction.get("entity_binding"), Mapping) else {}
    status = str(binding.get("status") or "")
    explicit = bool(binding.get("explicit_new_interlocutor"))
    if status == BIND_INCIDENTAL:
        persist_incidental_binding(session if isinstance(session, dict) else None, binding, scene_id)
        social = resolution.get("social")
        if not isinstance(social, dict):
            social = {}
            resolution["social"] = social
        social["npc_id"] = binding.get("bound_interlocutor_id")
        social["npc_name"] = binding.get("label")
        if isinstance(session, dict):
            from game.interaction_context import set_social_target

            set_social_target(session, str(binding.get("bound_interlocutor_id") or ""))
        return
    if status == BIND_CANONICAL and explicit:
        social = resolution.get("social")
        if not isinstance(social, dict):
            social = {}
            resolution["social"] = social
        social["npc_id"] = binding.get("bound_interlocutor_id")
        if binding.get("label"):
            social["npc_name"] = binding.get("label")
        if isinstance(session, dict):
            from game.interaction_context import set_social_target

            set_social_target(session, str(binding.get("bound_interlocutor_id") or ""))
        return
    if explicit and status in {BIND_UNRESOLVED, BIND_AMBIGUOUS, BIND_REJECTED}:
        social = resolution.get("social")
        if isinstance(social, dict):
            social.pop("npc_id", None)
            social.pop("npc_name", None)
        if isinstance(session, dict):
            from game.interaction_context import set_social_target

            set_social_target(session, None)
