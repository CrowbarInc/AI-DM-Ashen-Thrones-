# PR-BR Continuation 17 — Post-Generation Transformation Necessity and Hard-Validation Boundary

Discovery only. No gameplay behavior change. No parser, contract, prompt, validator, fallback, evaluator, or state change. No live gameplay call. No interpretation call. No synthetic-player call. No evaluator-model call. No independent smoke. No full synthetic gate. No human playtest. PR-BR remains open. PR-BS was not started.

HEAD at discovery: `d31beb7d73dd4fda0f22184a6a69b947b5f470ff`. Continuation 16 and the failed smoke are uncommitted work on that commit. This document is the Continuation 17 record. The campaign history in `docs/audits/PR-BR_typed_resolution_contract_and_discourse_state.md` points here.

Sources: `game/api.py`, `game/api_turn_support.py`, `game/gm_retry.py`, `game/resolution_contract.py`, `game/interaction_completion.py`, `game/live_resolution.py`, `game/social.py`, `game/perception_grounding.py`, `game/referenced_surface.py`, `game/social_exchange_fallback_catalog.py`, `game/final_emission_gate.py`, recorded sessions `artifacts/pr_br_continuation16/20261001T113214Z` and `artifacts/pr_br_independent_smoke/20261001T104551Z`, and the Continuation 13–16 manual reviews.

Offline scorecard: `artifacts/pr_br_continuation17/counterfactual_scorecard.json`.

## 1. Executive conclusion

The recent product failures are dominated by post-generation rewriting, not by failed generation.

On the sixteen recorded turns (Continuation 16's six live turns plus the failed independent smoke's ten):

| | Count |
| --- | --- |
| Initial manual PASS | 12 / 16 |
| Final manual PASS | 5 / 16 |
| Preserve-if-hard-valid counterfactual manual PASS | 12 / 16 |
| Initial candidates that are hard-invalid | 4 / 16 |
| Downstream-created failures (initial PASS, hard-valid, final FAIL) | 7 |
| Downstream-prevented failures (initial would FAIL, final PASS) | 0 |

Generation already satisfied the player on twelve turns. Deterministic machinery then destroyed seven of those twelve. It repaired none of the four turns whose initial text was actually illegal.

**Recommendation: Option C.** Replace most post-generation transformation with preserve-if-valid, one bounded regeneration when the candidate is hard-invalid, and a short deterministic nonresolution only after that retry fails. Deterministic authority over state, mechanics, permissions, and PR-BN classes stays. It stops authoring a "better" natural-language answer after a legal model answer already exists.

Option A (keep the current transformation pipeline) is not supported. The failures are the same families across Continuation 13, 14, 16, and the smoke, and they are produced by the replacement stages themselves.

Option B (a smaller rewrite set) still leaves semantic authorship after generation. The recorded damage is that authorship.

## 2. Why C17 was opened

Continuation 16's deterministic band was 350 / 350 PASS, and the ten recorded smoke replays passed their after-repair invariants. Fresh focused live validation was different: initial manual PASS 6 / 6, final manual PASS 2 / 6, manual semantic degradations 4, telemetry degradations 1.

The model had already produced a legitimate inability, a passage answer, a watcher answer, and a successful notice reading. Downstream stages replaced them with a quoted manner line, an unrelated Thoran sentence, a generic guard fallback, and "Nothing here matches that" prefixed onto the facts just read.

That split is the architectural question: validation versus rewriting.

## 3. C13–C16 quality progression

Manual reviews, not telemetry:

| Cycle | Initial manual | Final manual | What moved between them |
| --- | --- | --- | --- |
| C13 (`20261001T003832Z`) | 5 / 6 | 2 / 6 | Clue-frame replaced a clearance answer, a use answer, and a certainty answer with a stored Thoran or patrol fact. |
| C14 (`20261001T013504Z`) | 6 / 6 | 4 / 6 | A clarification and a traveler report were replaced by an inability template and the Thoran sentence. `best_safe` stored the worse line. |
| C15 focused (`20261001T094739Z`) | 4 / 4 | 4 / 4 | Identity emission on a narrow set. |
| Independent smoke (`20261001T104551Z`), C15 tree | 6 / 10 | 3 / 10 | Shells, a player-text splice, wrong-speaker collapse, a grounding closer, a scene-line substitution. Evaluator 8 / 10. |
| C16 focused (`20261001T113214Z`) | 6 / 6 | 2 / 6 | Manner quote, false "find them" rejection, wrong speaker, "Nothing here matches that." Telemetry 1 / 4. |

Continuation 15's focused identity result did not survive contact with ordinary play. Each later cycle added another selector or structural check. The live failure mode stayed: a useful generated line is replaced by a deterministic sentence that satisfaction then scores as an answer.

Recorded retries in both C16 and the smoke: 0. `MAX_TARGETED_RETRY_ATTEMPTS` in `game/gm_retry.py` is 2. The live path preferred substitution over regeneration.

## 4. Current response-pipeline diagram

Live `POST /api/chat` (`game/api.py` `api_chat` → `chat`). Stage names match `AUTHORITATIVE_TURN_STAGE_ORDER` in `game/api_turn_support.py` where that list exists. The post-model tail is longer than that list.

```text
PLAYER TEXT
    |
    v
segment_mixed_player_turn
resolve_directed_social_entry / declared actor switch
implied interaction prep
choose_interaction_route
deterministic intent parse
    |
    +-- off-scene or pending check --> engine GM text --------+
    +-- adjudication --------------> engine GM text --------+
    |                                                         |
    v                                                         |
attach_interaction_obligation                                 |
construct Resolution Contract                                 |
(optional interpret_for_contract)                             |
    |                                                         |
    v                                                         |
AUTHORITATIVE STATE MUTATION                                 |
(world, scene, clues, scene runtime)                         |
    |                                                         |
    v                                                         |
prompt context + call_gpt                                     |
    |                                                         |
    v                                                         |
guard_gm_output                                               |
bounded-improvisation attach                                  |
RETRY LOOP (detect, strategy, regenerate or                  |
            apply_deterministic_retry_fallback)              |
    |                                                         |
    v                                                         |
response-policy enforcement                                   |
authored-knowledge realization                                |
stay/leave agreement                                          |
destination-arrival realization                               |
perception non-invention                                      |
    |                                                         |
    v                                                         |
_finalize_player_facing_for_turn  <--------------------------+
    repeated-description guard
    serialized-payload strip
    sanitize (non-strict social)
    apply_final_emission_gate
        strict social: rebuild the line, else catalog fallback
        non-strict: layer stack, else sealed replace
    reconcile text with structured state
    obligation / contract preserve fallbacks
    select_preserved_answer
    commit_discourse_focus + note_emitted_npc_claim
    |
    v
SECOND PASS of authored-knowledge, stay/leave,
destination, and perception grounding
    |
    v
enforce_emitted_contract_monotonicity
    |
    v
_apply_post_gm_updates
    promote accepted bounded improvisation
    second NPC-claim note
    spoken-state refinement append
    |
    v
save session / world / log
    |
    v
PLAYER-VISIBLE TEXT
```

`game/interaction_completion.py` is not a stage of its own. `structural_assessment` and `generic_ask_completion` are called from the contract, the retry detector, and monotonicity.

## 5. Pipeline-stage table

| Stage | Source | Input | Output | Text can change | Candidate replaced | Candidate rejected | New prose | Authority / state | Semantic resolution | Necessity now | Failure risk |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Segmentation and route | `intent_parser.segment_mixed_player_turn`, `interaction_routing.choose_interaction_route` | Raw player text | Segments, route | No | No | No | No | Lane only | Coarse | Required | Wrong lane skips the contract |
| Deterministic intent | parse chain in `api.py` `chat` | Classification text | Normalized action or none | No | No | No | No | None yet | Intent label | Required | Missed social target |
| Contract construction | `live_resolution.attach_interaction_obligation` | Resolution, player text, scene | `resolution_contract` | No | No | Skips if a contract exists | No | Metadata | Operation, target, interlocutor, dimension | Required | Stale discourse inheritance (smoke turns 4, 6, 10) |
| Structured interpretation | `interpret_for_contract` when the fast path abstains | Player text, discourse | Proposal | No | No | Abstain | No | None | Referent | Required for ambiguous follow-ups | Smoke turn 7 accepted an ambiguous referent without clarification |
| Authoritative mutation | `_apply_authoritative_resolution_state_mutation` | Resolution | Scene, session, clues | No | No | No | No | World truth before narration | None | Required | Narration can later disagree with a mutation that already committed |
| Model generation | `gm.call_gpt` inside `_build_gpt_narration_from_authoritative_state` | Messages, contract | `player_facing_text` | Yes | No | Exception to schema fallback | Model | None | Realization | Required | Hallucinated consequential fact |
| Leak guard | `response_policy_enforcement.guard_gm_output` | Model text | Sanitized text | Yes | On leak | No | Bounded uncertainty | Hidden information | None | Required | Over-stripping is rare in these sessions |
| Retry loop | `gm_retry.detect_retry_failures`, `apply_deterministic_retry_fallback` | Candidate | Same, new model text, or fallback | Yes | Yes | Yes | Yes | Contract retention | Treats quality misses as retry causes | The loop exists; these sessions took 0 retries | Falls through to substitution |
| Policy handoff | `apply_response_policy_enforcement` | Candidate | Rewritten or appended text | Yes | Yes | No | Yes | Topic pressure, momentum | "Must answer" shaping | Historical quality pressure | Appends a beat the player did not ask for |
| Authored-knowledge realization | `social.apply_authored_knowledge_realization_to_gm` | Candidate, stored topics | Candidate or catalog line | Yes | Yes | Rank-0 lines lose | Yes | Authored clues | Swaps in a stored fact | Needed only when the model concealed a fact the question asked | C13 and C16: injected Thoran into a different question |
| Perception grounding | `perception_grounding.apply_perception_non_invention_to_gm`, `referenced_surface.render_referenced_surface_inspection_line` | Inspect prose | Grounded stock line | Yes | Yes | Via grounding lock | Yes | Visible facts | Replaces observation | The check is required; the stock sentence is not | "Nothing here matches" on a true reading |
| Final emission gate | `final_emission_gate.apply_final_emission_gate` | Candidate | Accepted or replaced text | Yes | Yes | Yes | Yes | Visibility, speaker, route | Strict-social rebuild | Packaging and leak control | Rebuilds a manner sentence into the utterance |
| Contract preserve | `select_preserved_answer`, `enforce_emitted_contract_monotonicity` | Current line, `best_safe_candidate` | Higher-ranked line | Yes | Yes | Downgrade | `generic_ask_completion` | None | Rank tournament | Intended to protect a good line | Stores the already-damaged line and emits it |
| Discourse and claims | `discourse_state.commit_discourse_focus`, `note_emitted_npc_claim` | Emitted text | Session slots | No | No | No | No | Discourse, NPC claims | None | Required, after the text is final | Today it runs before a second grounding pass |
| Bounded promotion | `bounded_improvisation.promote_accepted_bounded_improvisation` | Accepted proposals | Persisted details | Can restore text | Yes | No | No | PR-BN promotion | None | Required for accepted narration only | Must not promote a rejected candidate |
| Refinement append | `upstream_response_repairs.apply_spoken_state_refinement_cash_out` | Final text | Text plus sentence | Yes | No | No | Yes | Lead/clue cash-out | Adds a claim | Unclear on the social path | Runs after the finalized flag |

Historical reasons, where the code or the campaign record states them: stay/leave is PR-AE; destination arrival is PR-AF; narration-versus-payload reconcile is PR-AJ / RC-21; the final-emission boundary comment describes Objective C2 as packaging rather than semantic repair; response-policy orchestration is Cycles AI3–AI12; the non-strict stack is Cycle AN4; the terminal pipeline is Cycle AN6. PR-BR Continuations 5, 7, 13, 14, and 15 added preservation, rank, and `best_safe` specifically because earlier stages were destroying answers. Those guards now protect the replacement.

## 6. Post-generation mutator inventory

Thirty-five prose-capable mechanisms are on the live `/api/chat` path after the model returns. Internal helpers that only render a line for one of these mechanisms are counted with their caller. Functions that never change player-facing text are listed under observability or excluded.

The class is what the mechanism does to text today.

### Hard-invariant enforcement (5)

| Mechanism | File | What it does to text | Can change speaker / target / claims |
| --- | --- | --- | --- |
| `guard_gm_output` | `game/response_policy_enforcement.py` | Strips secret-leak patterns. May substitute a bounded uncertainty line. | Claims, by deletion |
| `apply_stay_leave_narration_agreement_to_gm` | `game/narration_state_consistency.py` | Replaces travel prose that contradicts an already resolved stay or move. | Location claim |
| `apply_visibility_enforcement` | `game/final_emission_visibility_fallback.py` | Replaces text that states a non-visible fact. | Facts |
| `hard_reject_social_exchange_text` | `game/social_exchange_emission.py` | Rejects banned social text and forces a fallback selection. | Indirect, via the fallback |
| `apply_narrative_authority_layer` | `game/final_emission_narrative_authority.py` | Flags authority violations and can repair them inside the gate. | Claims |

### Semantic repair (9)

| Mechanism | File | What it does to text |
| --- | --- | --- |
| `enforce_emitted_speaker_with_contract` | `game/speaker_contract_enforcement.py` | Rewrites attribution toward the locked speaker. |
| `retain_resolved_contract_text` | `game/resolution_contract.py` | Puts back an earlier line when a retry would drop coverage. |
| Response-policy answer shaping | `game/response_policy_enforcement.py` | `enforce_question_resolution_rule`, `enforce_forbidden_generic_phrases`, `enforce_npc_response_contract` prepend, rewrite, or append so the line looks answered. |
| `sanitize_player_facing_output` / `final_validation_pass` | `game/output_sanitizer.py` | Sentence-level heuristic rewrite before the gate on non-strict turns. |
| `select_preserved_answer` | `game/resolution_contract.py` | Chooses among the current line and stored candidates, including speaker retarget. |
| `enforce_emitted_contract_monotonicity` | `game/resolution_contract.py` | Restores a higher-ranked stored line, or calls `generic_ask_completion`. |
| `apply_social_response_structure_repair` | `game/final_emission_repairs.py` | Rebuilds dialogue shape. Continuation 16 turn 4 lost clauses here or in the strict-social rebuild. |
| `apply_spoken_state_refinement_cash_out` | `game/upstream_response_repairs.py` | Appends a refinement sentence after the finalized flag. |
| `apply_answer_shape_primacy_layer` | `game/final_emission_answer_shape_primacy.py` | Aligns the line to an answer shape the gate expects. |

Counted semantic-repair mechanisms: **9**.

### Fallback / substitute response generation (13)

| Mechanism | File | Stock effect seen or coded |
| --- | --- | --- |
| `apply_deterministic_retry_fallback` | `game/gm_retry.py` | Deterministic line when retry validation fails. Unused in these 16 turns (0 retries). |
| `ensure_minimal_social_resolution` | `game/gm_retry.py` | Fills an empty social GM. |
| Scene-pressure appenders | `game/response_policy_enforcement.py` | `enforce_scene_momentum`, `escalate_passive_scene`, `enforce_topic_pressure_escalation`. Smoke tags include `scene_momentum:*` on almost every turn. |
| `apply_authored_knowledge_realization_to_gm` | `game/social.py` | Replaces a rank-0 line with a stored topic. C16 turn 3 source `npc_topic:gate_guard:watch_command`. |
| `apply_perception_non_invention_to_gm` + `render_referenced_surface_inspection_line` | `game/perception_grounding.py`, `game/referenced_surface.py` | "Nothing here matches that. What you can actually see is …" and "Closer looking yields nothing further." |
| Strict-social rebuild and emergency pool | `game/social_exchange_emission.py`, `game/social_exchange_fallback_catalog.py` | `build_final_strict_social_response`, `apply_strict_social_terminal_dialogue_fallback_if_needed`, `minimal_social_emergency_fallback_line`. Exact C16 turn 5 string: `{speaker} shakes their head. "I have heard talk, but I cannot verify it."` |
| `obligation_preserving_fallback_line` | `game/live_resolution.py` | `I couldn't tell you {subject}; you will need another source.` Smoke turn 3 put the player's sentence in `{subject}`. |
| `run_generic_replace_exit` | `game/final_emission_generic_exit.py` | Sealed replacement when the gate has any reason. |
| `apply_first_mention_enforcement` | `game/final_emission_visibility_fallback.py` | Smoke turn 7 tag `first_mention_enforcement_replaced`. The recorded strings still match. |
| `apply_referential_clarity_enforcement` | `game/final_emission_visibility_fallback.py` | Smoke turn 10 tag `referential_clarity_violation:ambiguous_entity_reference`. Watcher answer became a scene line. |
| `generic_ask_completion` | `game/interaction_completion.py` | `I cannot answer that from what is settled here.` No new topic, no player quote. |
| `apply_destination_arrival_realization_to_gm` | `game/narration_state_consistency.py` | Replaces a destination stub with an arrival line. |
| `apply_repeated_description_guard` | `game/storage.py` | Replaces a repeated hash with "You find nothing new…" |

### Presentation-only (3)

| Mechanism | File | Effect |
| --- | --- | --- |
| Serialized-payload extract and strip | `game/output_sanitizer.py` | Pulls prose out of a JSON-shaped leak. |
| `apply_context_separation_layer`, `apply_player_facing_narration_purity_layer` | `game/final_emission_context_separation.py`, `game/final_emission_player_facing_narration_purity.py` | Strip player/GM bleed and planner residue. |
| `finalize_emission_output` | `game/final_emission_finalize.py` | Whitespace, HTML, route-illegal sentence strip. Objective C2 describes this as packaging. |

### Observability only (2)

| Mechanism | File | Effect |
| --- | --- | --- |
| `remember_satisfied_candidate` | `game/resolution_contract.py` | Stores `best_safe_candidate`. Does not itself write the sentence. The tournament that reads the store does. |
| `detect_semantic_degradation` | `game/resolution_contract.py` | Records reasons. Continuation 16 documents that the detector does not choose the emitted line. The tone layer is validate-only at the boundary and belongs with this group. |

### Legacy / redundant / unclear (3)

| Mechanism | Why it is in this class |
| --- | --- |
| Second pass of authored-knowledge, stay/leave, destination, and perception grounding after `_finalize_player_facing_for_turn` | The same four functions already ran in the narration hub. The second pass can still change text after discourse commit. |
| `best_safe` tournament | Built to stop later degradation. On these sessions it stored the damaged line (`best_safe` emission mismatches 0) and then protected that damage. |
| Satisfaction rank as a replacement chooser | A shell or a stored fact at rank 4 beats a legitimate inability at rank 2, or a rank-0 false invalidity. |

**Tally:** 5 hard-invariant, 9 semantic-repair, 13 fallback/substitute, 3 presentation, 2 observability, 3 legacy. **35** prose-adjacent mechanisms. Semantic-repair plus fallback/substitute: **22**.

Not prose mutators, and not counted: `apply_social_narration_lead_supplements` (lead state), `update_scene_momentum_runtime` (counters), `apply_social_reply_speaker_grounding` (resolution social payload).

## 7. Mutator classification

The classes above are the classification. One consequence matters more than the labels: **22 of 35 mechanisms can author or swap natural-language meaning after generation.** Five are legitimate hard stops. Three only package text. Two only record. Three are redundant with a guard that already ran, or they rank candidates the model did not need ranked.

High-risk substitutions, matched to recorded lines:

| Recorded line | Mechanism |
| --- | --- |
| `Tavern Runner says, "The tavern runner shakes their head…"` | Strict-social rebuild. The manner sentence became the quoted payload. |
| `Guard Captain says, "Word is, captain Thoran commands the gate watch tonight."` | `apply_authored_knowledge_realization_to_gm`, stage `clue_frame`, reason `npc_topic:gate_guard:watch_command`. |
| `The guard shakes their head. "I have heard talk, but I cannot verify it."` | `minimal_social_emergency_fallback_line` / `lawful_strict_social_dialogue_emergency_fallback_line`. Speaker label resolved to "The guard". |
| `Nothing here matches that. What you can actually see is…` | `render_referenced_surface_inspection_line` when authority is `AUTHORITY_UNSUPPORTED`. |
| `Closer looking yields nothing further.` | Same renderer, authored visible-feature branch. |
| `I couldn't tell you` plus the player's own words | `obligation_preserving_fallback_line`. |

## 8. Hard-invalidity taxonomy

A generated response **cannot be emitted** when any of the following is true at high confidence. The test is against canonical state, the mechanical result, permissions, and the current contract when that contract agrees with the player's explicit address.

| Category | Emit? | Evidence |
| --- | --- | --- |
| Hidden-information or secret leak | No | `guard_gm_output` exists for this. Not observed in these 16 turns. |
| Narrator asserts a consequential fact that is not in authored state and not marked as an NPC claim | No | Smoke turn 9: a dusk curfew "less than three hours away" as a posted rule. |
| Mechanical outcome contradicts the resolved roll, HP, inventory, or movement | No | Not in these social/inspect turns. The engine already mutates that state before narration. |
| Dead NPC acts as alive, or an impossible inventory/location claim | No | Not in these 16 turns. Still a hard stop. |
| Explicit wrong speaker when the contract interlocutor and the player's address agree | No | Smoke turns 4 and 5: the runner answers a question put to a guard. The contract on turn 5 had already moved to `gate_guard`. |
| Line tells the player to go find the person they are addressing | No | Smoke turn 7: "you might need to find the guard captain" after the captain was the person just questioned. High confidence because the sentence names that person as someone to locate. |
| Player utterance embedded as NPC speech | No | Smoke turn 3 final line. The initial line did not do this. The fallback did. |
| Empty, truncated-token, or attribution shell with no proposition | No | Smoke turns 1, 4, and 5 finals. The initials were complete sentences. |
| Canonical-state contradiction (the text denies a fact the engine just established, or asserts an absent object is present) | No | Not the C16 notice reading. That reading matched taxes, curfew, and the missing patrol. |

These are **not** hard-invalid by themselves:

| Situation | Why it can be emitted |
| --- | --- |
| Legitimate inability or refusal | C16 turns 1 and 2, smoke turns 1, 2, 3, and 8. The contract's expected resolution includes a real nonresolution. |
| NPC dialogue that states a policy as that NPC's words | Smoke turns 6 and 8. PR-BN records this as a claim, not as world truth. The smoke ledger stored no claims; that is a recording gap, not a reason to rewrite the line. |
| Extra scene-compatible color (rain, a glance, a bundle) | C16 turns 4 and 6. |
| Awkward or slightly mechanical wording | C16 turn 2's refusal is stiff and still a completed ask. |
| A suggestion to look at a notice board or a serjeant while speaking to the captain | C16 turn 3. "Find the specifics" is not "find the captain." |

`recommends_locating_interlocutor` in `game/interaction_completion.py` is the false-positive mechanism. `_LOCATE_RE` matches `find`. The label test then requires every significant word of the interlocutor label to appear anywhere in the line. "The guard captain replies" supplies `guard` and `captain`. "You'll find the specifics" supplies `find`. The function returns true. Continuation 16 turn 3 was marked `discourse_state_contradiction`, satisfaction rank 0, and the Thoran topic replaced it.

## 9. Quality versus invalidity

| Example | Class | What should happen |
| --- | --- | --- |
| Bland, terse, awkward, or mechanical wording | Quality | Emit |
| Imperfect atmosphere, redundant phrase | Quality | Emit |
| Weak but valid explanation | Quality | Emit |
| Extra compatible information | Quality | Emit. Do not strip it to "improve" focus. |
| Legitimate uncertainty, inability, or refusal | Valid nonresolution | Emit |
| Quoted manner with the real answer still in the line | Valid | Emit the model line. Do not rebuild. |
| Attribution shell, player-text splice, wrong speaker, invented posted hour, "go find the person in front of you" | Hard-invalid | Do not emit. Retry once under the same contract. Then the safe nonresolution. |

A response can be stylistically imperfect and still be semantically valid, state-consistent, authority-safe, and interaction-complete. On these sixteen turns, every initial manual pass was that kind of response. Deterministic machinery should have left those twelve alone.

## 10. C16 six-turn counterfactual

Session `20261001T113214Z`. Manual column is the Continuation 16 review. Hard-valid is this cycle's judgment, not the live structural flag. Turn 3's live flag was `discourse_state_contradiction`; that flag is the false positive.

| Turn | Initial manual | Hard-valid | What changed | Why it fired | Final manual | Preserve-initial | Genuine invariant in the initial | Transformation necessary |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | PASS | YES | Inability about stew prices became `Tavern Runner says, "The tavern runner shakes their head slightly, voice lowered amid the bustle."` | Strict-social rebuild. Satisfaction then scored the quote `inquiry_answered` at rank 4. `best_safe` is the quote. | FAIL | PASS | None. Legitimate inability, correct speaker. | NO |
| 2 | PASS | YES | None. Clue-frame and final emission compared the refusal to itself. | `resolution_content_preserved` | PASS | PASS | None. Refusal completes the ask. | NO |
| 3 | PASS | YES | Passage inability became `Word is, captain Thoran commands the gate watch tonight.` | `find` plus the words `guard captain` in the attribution. Rank 0 to 4 via `npc_topic:gate_guard:watch_command`. | FAIL | PASS | None. The redirect is to the notice board and the serjeant, not to the captain being addressed. | NO |
| 4 | PASS | YES | Quotes and some clauses dropped. The watcher still answers. | Strict-social or structure repair. Both the runner's initial view and the manual review call the final a pass. Evaluator false FAIL. | PASS | PASS | None | NO. Redundant trim. |
| 5 | PASS | YES | Watcher explanation became `The guard shakes their head. "I have heard talk, but I cannot verify it."` | Exact emergency-pool line. The transition log never saw the model sentence; replacement happened before a safe candidate was stored. Speaker label is "The guard", not the contract's `threadbare_watcher`. | FAIL | PASS | None. The model used the contract interlocutor. | NO |
| 6 | PASS | YES | Useful reading gained `Nothing here matches that.` | Referenced-surface unsupported template. Clue-frame rejected a stronger "no further reliable detail" line as `grounding_contradiction`. Final emission still applied `grounding_correction_authoritative`, so the model line was not restored. | FAIL | PASS | None. Taxes, curfew, and the missing patrol are authored. | NO |

Recommended future behavior for all six: emit the initial line. Turn 4's trim is optional packaging and is not allowed to drop clauses.

## 11. Failed-smoke ten-turn counterfactual

Session `20261001T104551Z`. Manual initial/final labels are the smoke audit. Contract errors are noted because several initials fail the player while obeying a stale contract.

| Turn | Initial manual | Hard-valid | What changed | Why it fired | Final manual | Preserve-initial | Genuine invariant in the initial | Transformation necessary |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | PASS | YES | Price inability became `Tavern Runner says with a tight shrug, voice low and hurried,` | Strict-social rebuild. Initial satisfaction `valid_inability`. Final satisfaction `inquiry_answered`. | FAIL | PASS | None | NO |
| 2 | PASS | YES | Market Quarter archway sentence dropped. The price hedge remains. | Grounding or quote trim. Both lines answer. | PASS | PASS | None. An off-scene place inside NPC speech is a claim, not a state write. | NO. Neutral trim. |
| 3 | PASS | YES | Real refusal became `I couldn't tell you` plus the player's sentence, cut off. | `obligation_preserving_fallback_line`. Tag `interaction_obligation_terminal_preserved`. | FAIL | PASS | None | NO |
| 4 | FAIL | NO | Runner's passage answer became a runner glance shell. | Discourse inheritance kept `tavern_runner` after the player addressed a guard. Emission then stripped the payload. | FAIL | FAIL | Wrong interlocutor relative to the player's explicit address. The contract was already wrong. | Reject the initial. The glance shell is not the repair. |
| 5 | FAIL | NO | Runner's permit speech became a runner shell that stops at `adding,` | Contract interlocutor was `gate_guard`. The model still wrote the runner. The shell kept the runner. | FAIL | FAIL | Wrong speaker against both the contract and the player. | Reject the initial. Regenerating under the guard contract is the repair. The shell is not. |
| 6 | PASS | YES | None | Identity. Tag `resolution_contract_semantic_preserved`. | PASS | PASS | None. Toll policy is the captain's claim. | NO |
| 7 | FAIL | NO | None. Tags say the gate and first-mention ran; the recorded strings match. | The model already wrote "find the guard captain." Satisfaction scored it `covered:content`. | FAIL | FAIL | Tells the player to locate the captain who just answered. | Reject. No substitute was applied, so nothing was prevented. |
| 8 | PASS | YES | None | Identity. The refusal is the resolution. | PASS | PASS | None | NO |
| 9 | FAIL | NO | Invented dusk hour and the mud-track clue became the visible-fact sentence plus `Closer looking yields nothing further.` | `referenced_surface_realization`, `passive_scene_pressure_grounded_observe`. `best_safe` invalidated with `grounding_contradiction`. The closer was still emitted. | FAIL | FAIL | Narrator states an unauthored curfew hour as a posted fact. | Reject the hour. The closer is the wrong substitute: it also drops the authored mud-track clue. |
| 10 | PASS | YES | Watcher says they are looking for a face. Emitted: `As you watch the scene, threadbare watchers and refugees cluster along the muddy gate line.` | `referential_clarity_enforcement_replaced`. Initial scored `unrelated_fact` because the contract was still `guard_captain`. The scene line scored `inquiry_answered` at higher rank. | FAIL | PASS | None. The face is an NPC claim inside the answer the player asked for. The contract was stale. | NO |

## 12. Counterfactual scorecard

| | C16 (6) | Smoke (10) | All (16) |
| --- | --- | --- | --- |
| Initial manual PASS | 6 | 6 | 12 |
| Final manual PASS | 2 | 3 | 5 |
| Preserve-if-hard-valid manual PASS | 6 | 6 | 12 |
| Initial hard-invalid | 0 | 4 | 4 |
| Downstream-created failures | 4 | 3 | 7 |
| Downstream-prevented failures | 0 | 0 | 0 |
| Rejection of the initial was necessary | 0 | 4 | 4 |
| Rewrite was harmful | 4 | 6 | 10 |
| Rewrite was neutral or redundant | 2 | 4 | 6 |

Preserve-if-hard-valid counts a turn as a pass only when the initial was manual PASS and hard-valid. The four hard-invalid initials stay failures until a retry produces a legal line. That retry was not run. This scorecard does not assume the retry would succeed.

Smoke turn 10 is inside the 12 and outside the recorded contract. The watcher answer is hard-valid and manual PASS. The stored contract was still `guard_captain`. Requiring the recorded contract as well would reject that turn and leave 11/16, then retry under the stale captain. The recommended lifecycle corrects the contract from the current-turn addressee before validation, so the watcher line becomes the contract-satisfying line and the 12 stands.

Neutral/redundant: C16 turns 2 and 4; smoke turns 2, 6, 7, and 8. Smoke turn 7 is neutral as a diff (the text did not change) and still a failed turn.

## 13. Downstream-created failure analysis

Primary metric: initial manual PASS, hard-valid, and the downstream transformation caused the final FAIL.

**7 turns:** C16 1, 3, 5, 6 and smoke 1, 3, 10.

Shared pattern:

1. The model completes the interaction.
2. A lexical or ownership check marks the line invalid, or a rebuild extracts the wrong sentence.
3. A substitute (catalog topic, emergency pool, referenced-surface closer, obligation template, scene fact) replaces it.
4. Satisfaction scores the substitute as `inquiry_answered` or equal-rank content, so `best_safe` stores the substitute.
5. Monotonicity then protects the substitute. Emission mismatches stay 0.
6. The degradation detector compares the damaged store with the damaged final, and reports nothing. C16 turn 6 is the exception (`lower_rank`, `target_loss`) because the final satisfaction actually fell.

Telemetry caught 1 of these 7 (C16 turn 6). The smoke detector caught 0 of its 6 manual degradations, three of which are in this created-failure set.

## 14. Downstream-prevented failure analysis

**0** turns moved from an initial manual FAIL to a final manual PASS.

Smoke turn 9 is a partial block, not a prevented failure. The invented dusk hour did not reach the player. The replacement also deleted the authored mud-track clue and said closer looking yields nothing further. The player-visible result still fails. Blocking the hour is the behavior to keep. Authoring the closer is not.

No recorded turn shows a hard-invalid model line repaired into a manual pass by substitution.

## 15. Historical transformation-necessity table

| Mechanism | Introduced | Original failure | Hard-invalidity | Quality problem | Still necessary as a rewriter | Validation + one retry instead |
| --- | --- | --- | --- | --- | --- | --- |
| Perception non-invention / referenced surface | Pre-BR grounding, kept through PR-BR | Model invents inspectable detail | YES when the invention is narrator fact | The closer sentence is quality theater | The check YES. The stock sentence NO | YES. Reject the invention. Retry with the visible-fact list in the contract. |
| Authored-knowledge realization / clue frame | Social topic pressure; live damage from C13 onward | Model hides a stored fact behind fake ignorance | Sometimes, when the question asked that fact | Often. C13 turns 1, 4, 6 and C14 turn 5 and C16 turn 3 replace a different answer with Thoran or the patrol | NO as a swap | YES, and only if the stored fact is the contract's requested content. Do not swap topics. |
| Strict-social rebuild and emergency pool | Social ownership cycles | Wrong speaker, empty social, validator voice | YES for empty or wrong-speaker output | The pool invents a generic reply and can name the wrong NPC | NO | YES. Retry under the contract speaker. Last resort is `generic_ask_completion` in that speaker's mouth. |
| Obligation fallback `I couldn't tell you {subject}` | Interaction-obligation completion | Dead air on an ask | Empty output is invalid | The template manufactures an inability and has spliced player text | NO | YES. A real model inability should already have been emitted. |
| `best_safe` / monotonicity | PR-BR C5, C7, C13–C15 | Later stages destroyed a better line | NO | YES. It was a patch on the rewrite pipeline | NO once rewriters leave the critical path | The first hard-valid line does not need a tournament. |
| Satisfaction rank | C6–C16 | Could not tell an answer from a miss | NO | YES. Shells and stored facts outrank inabilities | NO as a chooser | Keep as a yes/no contract check that triggers retry, not replacement. |
| Scene-momentum and topic-pressure append | Response-policy cycles AI3–AI12 | Scenes felt static | NO | YES | NO | Put pressure in the prompt context if a future cycle wants it. Do not append it after a valid answer. |
| Stay/leave agreement | PR-AE | Narration contradicted a resolved move | YES | NO | YES, as a short factual correction when the mechanical result is already committed | A retry can do it. A one-sentence factual correction is an acceptable last resort because the fact is structured. |
| Leak guard | Response policy | Secret leak | YES | NO | YES | Retry is optional. Stripping the leak is required even if retry is skipped. |
| `generic_ask_completion` | C16 | Shells and player-text splices | The condition is invalidity | The line is deliberately non-semantic | YES as last resort only | It is the last resort after one retry, not the first repair. |

## 16. Satisfaction-system analysis

`assess_contract_satisfaction` and `resolution_rank` currently act as validator, ranker, replacement trigger, and fallback trigger.

Recorded effects:

- C16 turn 1 and smoke turn 1: a real inability (`legitimate_nonresolution` / `valid_inability`, rank-class nonresolution) loses to a manner shell scored `inquiry_answered`.
- C16 turn 3: a false structural invalidity forces rank 0, so any stored topic at rank 4 wins.
- Smoke turn 10: the useful watcher line is `unrelated_fact` because the contract is stale; the scene line is `satisfied`. Rank selects the scene line (`higher_rank`).
- C16 turn 6: the only time rank moved the right direction (`lower_rank`, `target_loss`), and the grounding lock still emitted the worse line.

Satisfaction should become one question: does this candidate sufficiently resolve the authoritative contract, including a legitimate inability or refusal when that is a legal resolution. It should not choose which reconstructed sentence replaces which other sentence.

Those responsibilities should not stay combined. Ranking reconstructed candidates is what lets a shell outrank an answer.

## 17. best_safe_candidate analysis

`remember_satisfied_candidate` stores a line at rank 2 or higher. `select_preserved_answer` and `enforce_emitted_contract_monotonicity` emit that store when the current line is not allowed to replace it.

Original use: stop a later stage from degrading a good answer. Continuation 13 turn 2 showed the opposite bug, a better line stuck in the store and not emitted. Continuations 14–16 fixed emission fidelity. `best_safe` emission mismatches are 0 in C14, C15, C16, and the smoke.

The remaining defect is the update rule. The store accepts the first line that scores as safe, and that line is often already the shell, the Thoran sentence, the emergency pool, or the closer. Fidelity to a bad best is not preservation.

Future architecture should not run a candidate tournament. The first model candidate that is hard-valid, authority-safe, state-consistent, contract-satisfying, and interaction-complete becomes the emitted text. Later candidates are not generated for rank.

## 18. Fallback inventory

| Fallback | Invoked when | Hard-invalid condition? | New semantic content | Can change target | Speaker | Operation | Claims | Contradict state | Caused recorded degradation | Class |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Leak substitution inside `guard_gm_output` | Secret pattern | YES | Minimal | No | No | No | Deletes | No | Not in these 16 | REQUIRED SAFE FALLBACK |
| Stay/leave stock line | Narration contradicts resolved move | YES | The structured fact only | Location | No | No | The move | It prevents a contradiction | Not in these 16 | REQUIRED SAFE FALLBACK |
| `generic_ask_completion` | Ask structurally invalid after other attempts | YES | A content-free inability | No | Uses the contract label | No | No | No | Not observed as the damaging line | REQUIRED SAFE FALLBACK, last resort |
| Mechanical one-liner from resolution fields | Narration contradicts HP, inventory, or movement, and retry failed | YES | Only fields already resolved | No | No | No | The mechanical result | It prevents one | Not in these 16 | REQUIRED SAFE FALLBACK |
| Perception / referenced-surface closer | Unsupported or mixed inspection | The invention is invalid. A true reading is not. | YES. "Nothing matches" / "nothing further" | Can drop the object detail | No | Can collapse to observe | Can deny a visible fact | YES, by denial | C16 turn 6, smoke turn 9 | REGENERATE-FIRST |
| Strict-social emergency pool | Social ownership or terminal miss | Sometimes | YES. Generic rumor line | No | YES. Uses `speaker_label`, which was "The guard" | No | "I have heard talk" | Can name the wrong NPC | C16 turn 5, smoke 1, 4, 5 | REGENERATE-FIRST. Current pool is HARMFUL as a first repair |
| `obligation_preserving_fallback_line` | Contract or obligation unsatisfied | Sometimes empty | YES | Can | YES | No | Can quote the player | Can | Smoke turn 3 | REGENERATE-FIRST. HARMFUL when it fills `{subject}` from player text |
| Authored-knowledge / clue-frame swap | Current line rank below the stored topic | Often a false rank | YES. A different fact | YES, topic | Can | No | States the topic as the answer | Can answer the wrong question | C13, C14, C16 turn 3 | REGENERATE-FIRST. HARMFUL as a topic swap |
| Referential-clarity replacement | Ambiguous entity | Often uncertain | YES. Scene fact | YES | YES | Can collapse ask to observe | Scene facts | Smoke turn 10 | HARMFUL / REDUNDANT on these turns |
| First-mention replacement | Missing grounding on a name | Uncertain | YES | Can | Can | No | Can | Smoke turn 7 tagged it; text unchanged | UNCLEAR on that turn. Do not let it author a stall |
| `run_generic_replace_exit` | Any gate reason | Mixed | YES | YES | YES | YES | YES | Can | Gate tags on smoke 7, 9, 10 | REGENERATE-FIRST |
| Scene-momentum / topic-pressure append | Momentum due | NO | YES | No | No | No | Atmosphere or a lead | Can | Tags on most smoke turns | LEGACY |
| Repeated-description guard | Same narration hash | NO | YES. "Nothing new" | No | No | No | Denies a repeat look | Can | Not the recorded failures | LEGACY |
| Destination-arrival template | Stub destination prose | Sometimes | YES | Scene | No | No | Arrival | Can | Not in these 16 | REGENERATE-FIRST |
| Deterministic retry fallback | Retry budget exhausted inside `gm_retry` | Mixed | YES | YES | YES | Can | YES | Can | 0 uses in these sessions | LEGACY relative to a single explicit retry plus `generic_ask_completion` |

Fifteen fallbacks were audited in the table above. Four are required safe last resorts: leak strip, the stay/leave fact, `generic_ask_completion`, and the mechanical one-liner (specified for a case these sessions did not hit). The other eleven should not run before a bounded regeneration.

## 19. Retry / regeneration analysis

`game/gm_retry.py` already has a retry loop and `MAX_TARGETED_RETRY_ATTEMPTS = 2`. Both recorded sessions show `retries: 0`. Substitution ran instead. The loop's failure classes include `unresolved_question`, `scene_stall`, `forbidden_generic_phrase`, and topic pressure. Several of those are quality triggers. A quality miss should not spend a retry, and it should not spend a fallback.

Proposed use, not implemented:

```text
model candidate
    -> hard validator
    -> valid: emit unchanged
    -> invalid: one regeneration
         same Resolution Contract
         same authoritative state
         the violation named in the retry instruction
    -> hard validator
    -> valid: emit
    -> invalid: generic_ask_completion or the mechanical one-liner
```

| Concern | Assessment |
| --- | --- |
| Architecture fit | The contract and the state snapshot already exist before generation. A second call does not need a new contract. |
| Token cost | These sessions used one generation per turn. A bound of one retry adds a call only on hard-invalid turns. On this sample that is 4 of 16, about one quarter more generation calls if every illegal line is retried once. The 12 legal lines add nothing. |
| Latency | One extra model round trip on the failure path only. |
| Determinism | The validator is deterministic. The retry text is not. The last resort is deterministic. |
| Retry-loop risk | Bound is 1. Not "until success." The existing constant of 2 should not be reused as an unbounded quality loop. |
| State integrity | No world mutation from either candidate until one candidate passes. See section 22. |
| Authority | The retry sees the same permissions and the same PR-BN classes. It does not get a wider invention budget. |

Bound: **1** regeneration. Then stop.

## 20. First-valid-response analysis

Rule under test: the first model candidate that is hard-valid, authority-safe, state-consistent, contract-satisfying, and interaction-complete is immutable player-visible content. Later machinery may record state, persist accepted facts, update discourse, and log telemetry. It may not rewrite that semantic content.

On this evidence the rule is **supported**.

Benefits: the seven downstream-created failures do not happen. Continuation 16 would have finished 6 / 6. The smoke would have finished 6 / 10, which is the initial-pass count, instead of 3 / 10. Token use on the success path stays one generation.

Risks:

- Four initials were hard-invalid. Emitting them would publish a wrong speaker (smoke 4 and 5), a "find the captain" stall (smoke 7), and a fake curfew hour (smoke 9). The rule does not emit those. That is why "first valid" is not "first model string."
- Stale contracts make "contract-satisfying" disagree with the player. Smoke turn 10's watcher answer failed the stale captain contract and was the right player answer. A hard interlocutor check must not reject a line that addresses the person the current player sentence just named, only because discourse inheritance kept the previous NPC. That fix is contract construction, and it is a precondition of the rule. Until it lands, a high-confidence speaker check should prefer the explicit current-turn addressee over an inherited slot.
- Quote stripping that drops clauses (C16 turn 4) would stop. The player keeps the fuller answer. That is the point.

## 21. Immutable-boundary analysis

Text becomes immutable when the hard validator accepts it.

Nothing after that acceptance needs to change semantic content. Legal post-acceptance work is bookkeeping: discourse slots, NPC-claim notes, bounded-detail promotion from that text, logs, and telemetry.

What currently changes text after a would-be acceptance, and why it should stop:

| Later writer | Why it exists | After immutability |
| --- | --- | --- |
| Strict-social rebuild | Force a dialogue shape | Off the critical path |
| Referenced-surface closer | Stop invented inspect detail | Becomes the validator's reject reason, not a new sentence |
| Authored-knowledge swap | Force a stored fact | Off, unless the retry itself is the model stating that fact |
| `select_preserved_answer` / monotonicity | Undo an earlier downgrade | Unnecessary if nothing later downgrades |
| Second grounding pass | Same checks again | Off |
| `apply_spoken_state_refinement_cash_out` | Append a lead | Off. If the lead is authoritative, it belongs in the contract before generation |
| Presentation whitespace and HTML strip | Packaging | Allowed, if it cannot drop words |

The boundary is **before** discourse commit, not after the current gate. The current gate is itself a rewriter.

## 22. State-commit ordering

Current order:

1. World tick at the start of `chat`.
2. On the resolved path, `_apply_authoritative_resolution_state_mutation` before generation.
3. Model and rewriters.
4. End of `_finalize_player_facing_for_turn`: `commit_discourse_focus` and `note_emitted_npc_claim`.
5. Second grounding pass and `enforce_emitted_contract_monotonicity`, which can still change `player_facing_text`.
6. `_apply_post_gm_updates`: bounded promotion, another claim note, refinement append.
7. Save and log.

A preserve-if-valid path has to use this order:

1. Interpret and build the contract. Do not commit discourse from a rejected reading.
2. Apply mechanical and movement mutations that the engine has already resolved. Those are not derived from narration.
3. Generate.
4. Hard-validate. If invalid, retry once against the same pre-narration state. Do not promote facts from the rejected text.
5. On acceptance, the text is immutable.
6. Then, from that text only: discourse commit, NPC-claim notes (claims, not world truth), bounded-detail promotion for proposals that were accepted on this text.
7. Emit and persist.

Rejected text must not commit discourse, must not record a claim, and must not promote a detail. Emitted text must be the text those commits describe. Today's steps 5 and 6 can break that pairing.

## 23. PR-BN persistence implications

The recommendation keeps PR-BN.

Bounded incidental invention in an accepted narration still promotes through `promote_accepted_bounded_improvisation`, and only after the line is the immutable accepted line. A rejected candidate does not promote.

An NPC sentence remains an attributable claim through `note_emitted_npc_claim`. It does not become world truth because it was spoken. Smoke turns 6 and 8 are the pattern to preserve: the captain's toll policy stays in the captain's mouth. The smoke left `active_claim` empty; the future path should record that claim from the emitted line and still not write it as a scene fact.

Consequential narrator inventions (a posted hour, a new toll amount stated as law, a route the engine did not resolve) stay hard-invalid. They are not promoted and they are not emitted.

## 24. Mechanical-action implications

Social and inspect turns are most of the recorded damage. Mechanical turns need a tighter version of the same split.

The engine owns the result: attack roll, damage, HP, inventory transfer, movement, spell expenditure. `_apply_authoritative_resolution_state_mutation` already runs before narration on the resolved path. That order stays.

The model owns the telling of that result. Preserve the telling when it does not contradict the structured result. Reject it when it does (wrong creature wounded, item gained that was not transferred, move narrated when the resolver stayed put). One retry receives the structured result in the instruction. If the retry still contradicts, emit a short line built from the structured fields. That line states the result. It does not reconstruct motive, dialogue, or a clue.

Stay/leave agreement is this pattern already, restricted to location. It remains as the last resort for location, not as a general prose rewriter.

## 25. Generation versus resolution ownership

| Question | Owner |
| --- | --- |
| What happened? | Deterministic engine: canonical state, mechanics, permissions, authoritative action result, Resolution Contract, PR-BN class of any new detail. |
| How is it narrated? | The model: dialogue, description, connective tissue, the wording of an inability. |

The current architecture crosses that split. After a legal narration exists, `apply_authored_knowledge_realization_to_gm`, the strict-social rebuild, the referenced-surface renderer, the obligation fallback, and the emergency pool decide the words, and sometimes the speaker and the topic. Those wording decisions are the seven downstream-created failures.

## 26. Deterministic versus semantic validation boundary

Deterministic enough to reject without guessing:

- Empty response, truncated JSON, unclosed payload scaffold.
- Secret or hidden-fact pattern.
- Impossible canonical id.
- Structured mechanical mismatch (HP, inventory, location, alive/dead) against the resolution record.
- Player-utterance window embedded in the NPC line (`player_utterance_embedded`).
- Attribution shell: an attribution verb and a manner tail, and no proposition (`attribution_shell`).
- Explicit locate sentence whose object is the current addressee, when the locate verb and the addressee are in the same clause. The current `_LOCATE_RE` plus "label words appear anywhere" test is not this check.

Semantic, and not safe as a lexical reject:

- Did this NPC really answer?
- Does "find the specifics" mean "find the captain"?
- Is the narration responsive enough?
- Is the prose too thin, too rich, or off in tone?
- Is an NPC's quoted policy "true"?

Deterministic code owns the first list. The model owns the wording that the second list worries about. If a semantic doubt remains, preserve a line that already passed the deterministic list, or regenerate once. Do not resolve the doubt by writing a new sentence in Python.

## 27. Validator-confidence policy

Reject only high-confidence hard violations.

| Confidence | Examples | Action |
| --- | --- | --- |
| High | Empty, leak, mechanical mismatch, dead/alive, player-text splice, shell with no proposition, same-clause "go find {current addressee}", narrator number or clock time that is not in authored state | Reject. One retry. Then safe nonresolution. |
| Low or lexical coincidence | `find` anywhere plus the speaker's name elsewhere in the paragraph; a name that does not use the "Name says" frame; a quoted claim whose truth is unknown | Do not reject. Do not replace. |
| Contract disagrees with the current sentence's explicit addressee | Smoke turns 4, 6, and 10 | Fix the contract from the current sentence before judging the model. Do not "repair" the prose into the stale NPC. |

Uncertain semantic judgments preserve the candidate when the deterministic checks passed. They do not clarify in the player's face unless the contract itself is `ambiguous` and no interlocutor was bound. They do not call a second model to judge the first in this design.

## 28. Model-assisted validation option

A structured judge model could score "did this answer the contract?" That option is **not** recommended.

| Issue | Assessment |
| --- | --- |
| Token cost | One extra call on every turn, including the 12 that were already valid. Larger than one retry on 4 of 16. |
| Latency | Always on the success path. |
| Reliability | The local evaluator already false-passed 3 of 6 C16 finals and 5 of 10 smoke finals. A model judge has the same kind of miss available to it. |
| Circularity | The generator judging itself will prefer its own wording. A different model reintroduces an evaluator. |
| Evaluator leakage | Runtime rejection by a judge becomes another rewrite trigger. |
| State authority | A judge must not be allowed to declare a new fact legal. State legality is already a deterministic question. |
| Better encoding | Put the contract, the visible facts, and the mechanical result in the generation prompt. Validate the result with the deterministic list. Do not add a judge. |

No live call was made to test this. The recommendation does not depend on one.

## 29. Telemetry role

Degradation telemetry should be observability and QA. It should not choose the player-visible line.

C16: telemetry degradations 1, manual degradations 4. The three misses are structural: a quoted manner sentence is not classified as a shell; a line already marked invalid is not a "loss" when replaced; a speaker change without a "Name says" frame is invisible.

Smoke: telemetry 0, manual 6. The detector compared a damaged initial store with a damaged final and saw equal rank.

A detector can be useful in QA at partial coverage. It is dangerous as a runtime switch. `detect_semantic_degradation` does not currently select the line. It must stay that way. Satisfaction rank, which does select the line, should lose that authority.

## 30. Evaluator role

`evaluate_playability` is local. Evaluator-model calls in both sessions: 0.

| Session | Evaluator | Manual final |
| --- | --- | --- |
| Smoke | 8 / 10 | 3 / 10 |
| C16 | 4 / 6 (turns 1, 2, 3, 5) | 2 / 6 (turns 2 and 4) |

C16 false PASS: turns 1, 3, 5. False FAIL: turn 4. Smoke false PASS: turns 3, 4, 7, 9, 10. False FAIL: 0.

The evaluator is not trustworthy for runtime selection. Keep it as offline test assistance. This cycle does not redesign it.

## 31. Token and cost comparison

Recorded calls, no new API calls. Route noted in the C16 audit: `gpt-4.1-mini`. No dollar ledger is stored on these artifacts. Comparison is call counts.

| Architecture | Generation calls on these 16 turns | Extra calls | When the extra call happens |
| --- | --- | --- | --- |
| A. Current pipeline | 16 gameplay generations (C16: 6, smoke: 10) plus 1 opening on the smoke. Retries 0. Interpretation 2 + 3. | 0 beyond today | Rewrites are CPU, and they caused 7 failed finals |
| B. Smaller rewrite set | Same 16, plus rewrites that remain | 0 | Still pays the quality cost of whatever rewrites remain |
| C. Preserve-first + one retry | 16 on the success path, plus up to 4 retries for the hard-invalid initials | ≤ 4 generation calls on this sample (~25% more generations if all four retry) | Only after a high-confidence reject |
| D. Model-assisted judge | 16 + 16 judge calls | +16 | Every turn, including legal ones |

Option C is the cheap failure path. Option D taxes the success path. Option A is the same generation cost as today's success path and the worst final-pass rate.

## 32. Failure-containment strategy

If generation is hard-invalid and the single retry is hard-invalid, the player receives one of these, chosen from the contract operation, with no new topic and no player-text splice:

| Situation | Last resort |
| --- | --- |
| Ask or social | `generic_ask_completion`: `{Contract label} says, "I cannot answer that from what is settled here."` If no label: `No one here can answer that from what is settled here.` |
| Inspect | The authored visible-fact sentence for that object, without "Nothing here matches" and without "Closer looking yields nothing further." If there is no authored fact: `The inspection establishes no further reliable detail from the current scene.` |
| Mechanical contradiction | One sentence from the structured result (the HP, the item, the location). |
| Ambiguous referent, no bound interlocutor | One clarification question. Do not pick an NPC and answer as them. |
| Secret leak that both attempts repeat | The leak-stripped text, or the ask nonresolution if stripping leaves a shell. |

These lines do not name a different authored topic, do not quote the player, and do not change speaker away from the contract label. That is the difference between `generic_ask_completion` and the emergency pool that produced "The guard shakes their head."

## 33. Minimum trusted post-generation core

Only these mechanisms need authority over generated output:

1. Schema and non-emptiness. Reject shells and player-text splices.
2. Secret and hidden-information strip.
3. Canonical-state check against structured records (entity exists, alive/dead, location, inventory).
4. Mechanical-result check against the resolution record.
5. High-confidence interlocutor contradiction, using the current-turn addressee when the player named one.
6. High-confidence same-clause "go find the person you are talking to."
7. Narrator-voice consequential invention (a new clock time, price, or law stated as scene fact rather than as an NPC claim).
8. Contract-satisfaction check as a yes/no, including legitimate inability.
9. One bounded regeneration on failure, under the same contract.
10. The last-resort lines in section 32.
11. Emission of the accepted line unchanged.
12. Discourse, claim, and PR-BN promotion from that line only.

## 34. Mechanisms proposed for removal from the critical path

| Mechanism | Future role |
| --- | --- |
| `best_safe` tournament and `select_preserved_answer` | Delete from the emission path. A debug log of rejected candidates is enough. |
| Satisfaction rank as a chooser | Yes/no contract check, QA log |
| `detect_semantic_degradation` | QA log |
| `evaluate_playability` | Offline tests |
| Strict-social sentence rebuild and the emergency pool | Prompt constraint on speaker. Not a rewriter. |
| Authored-knowledge topic swap | Contract context before generation, when the question asked that topic |
| Referenced-surface stock closers | Reject reason, not a new paragraph |
| `obligation_preserving_fallback_line` | Replaced by `generic_ask_completion` as last resort |
| Scene-momentum, passive escalation, topic-pressure append | Prompt context if wanted later. Not an append. |
| `final_validation_pass` semantic rewrites and `_simple_diegetic_fallback` | Off the path. Packaging strip may stay. |
| Second post-finalize grounding pass | Off |
| `apply_spoken_state_refinement_cash_out` | Off. Leads belong in the contract or the log. |
| Answer-shape, tone, authenticity, and anti-railroading repairs | Offline or prompt. Not runtime replacement. |
| Repeated-description full-text replacement | Log, or a duplicate-hash note. Do not substitute "nothing new" for a legal repeat look. |

## 35. Architecture Option A — current candidate-transformation pipeline

**Description.** Generate once. Run policy repair, authored-knowledge realization, perception grounding, the final-emission gate, strict-social rebuild, obligation fallbacks, satisfaction ranking, and `best_safe`. Emit the winner.

**Strengths.** Rich regression suite (350 tests on the C16 band). Many historical hallucinations are blocked in fixtures. Preservation guards exist.

**Weaknesses.** On the 16 real turns, final manual pass is 5 / 16 against an initial 12 / 16. Zero downstream-prevented failures. Seven created failures. The guards preserve the substitute. Telemetry and the evaluator miss the damage. Retries are implemented and unused.

**Historical evidence.** C13 5→2, C14 6→4, smoke 6→3, C16 6→2. C15 focused 4→4 did not generalize.

**Complexity.** The highest. Thirty-five post-generation mechanisms, two grounding passes, rank, and a tournament.

**Token cost.** One generation per turn in these sessions, plus interpretation on abstention. The quality cost is the rewrites.

## 36. Architecture Option B — reduced transformation set

**Description.** Keep a shorter list of rewriters: grounding closers, a smaller social fallback pool, and authored-fact insertion. Remove scene-momentum append and the tournament.

**Strengths.** Less machinery. Familiar to the current tests.

**Weaknesses.** The damaging mechanisms are the ones this option is tempted to keep. C16 turns 1, 3, 5, and 6 and smoke turns 1, 3, 9, and 10 are exactly grounding, social fallback, and authored-fact insertion. A smaller rewrite set that still writes sentences will keep the failure mode. The false-positive locate check still feeds them.

**Historical evidence.** Each continuation that added a narrower repair (C14 preservation, C15 coverage, C16 structural completion) left the same live families in place.

**Complexity.** Still a rewrite pipeline, with a shorter registry.

**Token cost.** Same as A. No retry.

## 37. Architecture Option C — preserve-first, hard validation, one retry

**Description.**

```text
PLAYER INPUT
    |
    v
SEMANTIC INTERPRETATION
    |
    v
AUTHORITATIVE RESOLUTION CONTRACT
(current-turn addressee overrides a stale inherited interlocutor)
    |
    v
STATE / AUTHORITY / MECHANICAL CONTEXT
    |
    v
MODEL GENERATION
    |
    v
HARD VALIDATION
    |
    +---- VALID ----------------------+
    |                                 |
    |                                 v
    |                         IMMUTABLE RESPONSE
    |                                 |
    |                                 v
    |                    DISCOURSE / CLAIM / PR-BN COMMIT
    |                                 |
    |                                 v
    |                              EMISSION
    |
    +---- INVALID (high confidence only)
                  |
                  v
             ONE RETRY, SAME CONTRACT,
             VIOLATION NAMED
                  |
                  v
             HARD VALIDATION
                  |
          +-------+-------+
          |               |
        VALID           INVALID
          |               |
          v               v
       EMIT        SAFE NONRESOLUTION
                  (section 32)
                  then commit and emit
```

**Strengths.** Matches the scorecard: 12 / 16 preserved, 4 / 16 rejected instead of published, 0 reliance on a rewriter to invent the repair. PR-BN promotion and NPC claims attach to the accepted line only. Mechanical results stay engine-owned. Token cost rises only on the failure path.

**Weaknesses.** The four hard-invalid turns do not become passes unless the retry succeeds. That is unknown without a future live run, and this cycle does not run one. Stale discourse must be fixed in contract construction or the validator will judge the model against the wrong NPC. Existing tests encode stock sentences ("Closer looking yields nothing further", Thoran realization, emergency pool lines). Those tests will need to expect rejection-or-retry rather than the stock sentence. That is an implementation-cycle cost, not a reason to keep the stock sentence on the success path.

**Historical evidence.** The seven created failures are cases the model had already solved. The four hard-invalid initials are the cases a validator must still catch, and the current substitutes did not turn them into passes. Smoke turn 9 shows the one real save (the fake hour was not shown) and shows that the save can be a reject without a closer.

**Complexity.** Lower on the success path: generate, validate, commit, emit. The retry and the four last-resort templates are the whole failure path.

**Token cost.** 16 generations plus at most 4 retries on this sample. No judge model.

## 38. Evidence-backed recommendation

**Option C.**

| Piece | Choice |
| --- | --- |
| Response lifecycle | Interpret → contract → state context → generate → hard-validate → emit if valid, else one retry, else section-32 nonresolution. |
| Hard validators | Section 33 items 1–7. |
| Soft validators | Tone, richness, atmosphere, "could be more specific," equal-rank topic preference. Log only. Never replace. |
| Retry | One. Same contract. Violation named. Not until success. |
| Fallback | Section 32 only, after the retry fails. No topic swap, no emergency rumor pool, no player-text subject. |
| Immutable boundary | The moment hard validation accepts the text. Before discourse commit. |
| State-commit ordering | Section 22. |
| Telemetry | QA only. |
| Evaluator | Offline only. |

This is not "trust the LLM." The engine still owns entities, world state, HP, inventory, location, death, discovered facts, hidden information, permissions, PR-BN classes, consequential inventions, the claim/truth split, persistence, promotion, mechanics, action legality, and state mutation. It stops owning the wording of a response that already respects those constraints.

## 39. Proposed next implementation cycle

PR-BR Continuation 18, still inside open PR-BR. Do not open PR-BS.

Implement the immutability boundary:

- Hard-valid model text is emitted unchanged.
- The locate check requires the locate verb and the addressee in the same clause.
- Current-turn explicit addressee overrides inherited discourse before the model is judged.
- Authored-knowledge swap, strict-social rebuild, referenced-surface closers, obligation-subject fallback, scene-pressure append, and `best_safe` selection leave the emission path.
- One retry, then `generic_ask_completion` or the mechanical one-liner.
- Discourse, claims, and PR-BN promotion run on the accepted line only.
- Update the deterministic tests that currently require the stock closer or the emergency pool as the emitted line. Assert rejection or the last-resort line instead.

Do not run an independent smoke, the six live turns, or the 4×10 gate in that cycle until the deterministic band shows a hard-valid fixture emitted byte-for-byte. Human playtest stays unauthorized until a later validation cycle says otherwise.

## 40. PR-BR status

PR-BR: **STILL OPEN.**

No completion commit. No push. No PR-BS. No gameplay behavior change. Gameplay-generation calls: 0. Interpretation calls: 0. Synthetic-player calls: 0. Evaluator-model calls: 0. Independent smoke: not run. Full synthetic gate: not run. Human playtest: **NOT AUTHORIZED.**

READY FOR IMPLEMENTATION OF OPTION C: YES, as Continuation 18. This document does not implement it.

# PR-BR Continuation 18 — Immutable Valid Response Boundary & Bounded Regeneration

HEAD remains `d31beb7d73dd4fda0f22184a6a69b947b5f470ff`. Continuation 18 is uncommitted work on that commit. Live session `artifacts/pr_br_continuation18/20261001T225126Z`.

## 1. C17 implementation basis

C17 measured 16 recorded turns. Initial manual PASS was 12/16. Final manual PASS was 5/16. Preserve-if-hard-valid would have kept 12/16. Four initials were genuinely hard-invalid. Seven failures were created downstream. Zero failures were prevented downstream. Continuation 18 implements that recommendation: hard-validate, preserve a valid response, regenerate once if it is hard-invalid, otherwise emit a minimal safe nonresolution.

## 2. Previous vs new response lifecycle

Previously, generation was followed by a candidate tournament. Satisfaction rank, `best_safe_candidate`, closers, and scene-pressure lines could replace a valid answer.

The contract-bearing narration path is now:

generate → hard-validate → if valid, seal the text → commit effects from that text → emit it.

If hard-invalid: one regeneration under the same contract → hard-validate → seal and emit, or emit the safe line. Scene openings and turns with no contract operation stay on the legacy path. A zero retry budget (`MAX_TARGETED_RETRY_ATTEMPTS == 0`) skips regeneration and goes to the safe line.

## 3. Hard-validation implementation

`game/immutable_valid_response.py` `validate_generated_response` rejects, with high confidence only: malformed or truncated output, secret leaks, the player-splice template, an ASK attribution shell, a passive observation standing in for an ASK, a smell/wear/sound/taste question that neither names the sense nor states an inability, meta validator voice (`based on what's established`, `we can determine`, model identity), a confidently wrong speaker, same-clause locate of the current addressee, an unauthored clock outside quotes, a mechanical success/failure contradiction, a dead actor speaking, and scene-backed unsupported perception invention.

## 4. Hard vs soft validation

Soft flags do not replace text. Bland or awkward prose, a partial echo of the player, a valid inability, and the old anywhere-match locate cue (`low_confidence_locate`, including C16 turn 3) stay soft. "I do not know" is a valid inability, not meta voice.

## 5. Accepted-response representation

A sealed turn stores `gm.metadata.accepted_response`: contract id, player input, text, speaker, addressee, target, operation, hard-validation result, interaction completion, attempt number, and provenance (`initial_generation`, `regeneration`, or `safe_nonresolution`). `immutable` is true.

## 6. Immutable boundary

After the seal, policy enforcement, authored-knowledge realization, stay/leave and destination realization, perception non-invention, the repeated-description substitute, the final emission gate, contract monotonicity, and spoken-state refinement return the accepted text. `restore_accepted_text` runs again before discourse and claim commit and records an equality report.

## 7. Post-acceptance allowed transformations

`normalize_presentation` collapses whitespace and strips simple `b/i/em/strong/br/p` tags. JSON transport escaping is unchanged. Any other difference is written back to the accepted sentence and marked `mutation_blocked`.

## 8. best_safe migration

`enforce_emitted_contract_monotonicity` may still compute `legacy_would_emit` for diagnostics. It does not assign that text when the response is immutable.

## 9. Satisfaction migration

Satisfaction is not a search for a better sentence. Hard validation answers whether the line may be emitted. `assess_contract_satisfaction` is not a reject: on the 16 recorded initials it marks preserve-cases unsatisfied (smoke 2, 6, and 10). Using it as a hard gate would have destroyed valid lines.

## 10. Old mutator migration

Forty mechanisms are classified. None are ambiguous.

| Status | Count |
| --- | --- |
| REMOVED FROM CRITICAL PATH | 20 |
| RETAINED AS OBSERVABILITY | 7 |
| RETAINED AS PRESENTATION-ONLY | 4 |
| STILL REQUIRED FOR STATE/MECHANICS | 4 |
| RETAINED AS HARD VALIDATOR | 3 |
| RETAINED AS LAST-RESORT SAFE NONRESOLUTION | 2 |

`guard_gm_output` still runs before the seal. That is containment, not a post-acceptance rewrite.

## 11. Initial-valid path

Attempt 1 hard-valid → seal `initial_generation` → skip the quality retry loop → emit the same string. Stub case C asserts one generation call.

## 12. One-retry path

`MAX_GENERATION_ATTEMPTS` is 2. A hard-invalid attempt 1 is marked rejected and is not the commit source. Attempt 2 uses the same contract, state, mechanic, operation, and interlocutor. Stub case A emits attempt 2 unchanged.

## 13. Retry feedback

The retry user message names reason codes only. It does not include the rejected sentence or a replacement sentence. Live feedback on turns 4 and 6 was `consequential_invention`.

## 14. Double-invalid path

If attempt 2 is also hard-invalid, provenance is `safe_nonresolution`, `retry_exhausted` is set, and there is no third gameplay generation. Stub case B covers this.

## 15. Safe nonresolution design

The line is one of: a dimension-specific inspection limit, the mechanical failure sentence, an authored visible fact, an action-incomplete sentence, one clarification question, or `generic_ask_completion`. If that line would repeat the player's utterance, it falls back to "No one here can answer that from what is settled here." It does not invent a posted fact, a clue, or a new speaker.

## 16. State-commit ordering

Engine mechanics still resolve before narration. Rejected candidates do not promote bounded proposals. `effects_allowed` is false for provenance `rejected` and for a text mismatch. Safe provenance strips improvisation proposals before the seal.

## 17. Discourse-commit ordering

`commit_discourse_focus` and `note_emitted_npc_claim` use `commit_text`, which is the accepted sentence.

## 18. Bounded invention persistence

Stub: attempt 1's incidental detail is rejected and does not persist. Attempt 2's different detail does.

## 19. NPC-claim persistence

Stub: a rejected attempt-1 rumor does not become an active claim. Only the accepted attempt is recorded.

## 20. Mechanical authority

Narration that says success when the mechanic says failure is hard-invalid and regenerates. The mechanic is not edited to match the prose. The matching failure narration is accepted unchanged.

## 21. Validator-confidence handling

Low-confidence locate is a soft flag. C16 turn 3 stays hard-valid. An unexpectedly phrased but valid line is not replaced.

## 22. 16-turn replay

`test_sixteen_turn_counterfactual_classifies_c17_boundary` loads the six C16 turns and the ten failed-smoke turns.

| Result | Count |
| --- | --- |
| Recorded turns | 16 |
| Initial hard-valid, preserved unchanged | 12 / 12 eligible |
| Hard-invalid, sent to regeneration | 4 / 4 |
| Downstream-created failures remaining | 0 |
| Accepted-response mutations | 0 |
| Regeneration of a hard-valid line | 0 |

## 23. Seven downstream-created failures

C16 turns 1, 3, 5, and 6, and smoke turns 1, 3, and 10, are hard-valid. Their recorded finals differ from the initials. The new path seals the initial and keeps it through monotonicity, authored-knowledge realization, perception non-invention, and the final emission gate. 7 / 7 eliminated.

## 24. Four hard-invalid initial responses

Smoke 4, 5, 7, and 9 stay blocked. Smoke 7 uses same-clause locate, not the old anywhere-match. Smoke 9's unauthored clock stays `consequential_invention`. 4 / 4 blocked.

## 25. Historical hard-invalid regressions

Authority leak, a dead actor speaking, malformed truncation, mechanical contradiction, and unauthored clock phrasing stay blocked.

## 26. Stub integration

Cases A, B, and C pass. The raw `/api/chat` stub preserves a valid runner price line and does not emit a wrong-speaker guard answer, the closer, or the emergency pool.

## 27. Focused deterministic results

Continuation 18's own file passed. A later combined run of Continuations 14–16 and 18, the resolution-contract suite, bounded improvisation, perception audible non-invention, transcript regression, and empty-social retry passed: 183 passed, 0 failed.

## 28. Broader regression result

Continuations 12–16, outcome precedence, bounded improvisation, the resolution contract, transcript regression, and empty-social retry passed together: 189 passed, 0 failed. The full repository suite was not run. Two product-path tests that required a hard-valid atmosphere line to be rewritten into "the tattered man" now expect that line to be preserved. Direct gate calls without an observe contract also no longer invent that approach. `question_resolution_rule_check` no longer treats a cinematic interruption as satisfied just because a loose contract assessment returned partial.

## 29. Focused live transcript

One isolated session, six completed turns, stamp `20261001T225126Z`. Natural wording, not the Continuation 16 strings. No repair and no rerun.

| Turn | Player | Provenance | Exact |
| --- | --- | --- | --- |
| 1 | Ask the tavern runner whether east-lane carts are still coming through. | initial | yes |
| 2 | Who told him that? | initial | yes |
| 3 | Leave the runner and ask the nearest guard about passage. | initial | yes |
| 4 | Read the newest notice-board posting. | regeneration | yes |
| 5 | Return to the runner with a coin and ask about the patrol. | initial | yes |
| 6 | Stay and watch the road. | regeneration | yes |

Turn 4 attempt 1 posted an unauthored "indoors by the third bell" and was rejected for `consequential_invention`. Attempt 2 states taxes, curfew rules, and the missing patrol, and was sealed. Turn 6 attempt 1 invented scent and footprints and was rejected for the same reason. Attempt 2 was sealed. Neither rejection was emitted.

## 30. Accepted-vs-emitted equality

6 / 6 exact matches. Presentation-only differences: 0. Accepted-response semantic mutations: 0. Generation attempts above two: 0.

## 31. Retry observations

Regenerations invoked: 2. Both succeeded on attempt 2. Double-invalid safe nonresolutions: 0. No third generation.

## 32. Initial vs final manual quality

Manual reading of the six finals:

| Turn | Initial manual | Final manual | Note |
| --- | --- | --- | --- |
| 1 | PASS | PASS | Inability plus an NPC-attributed rumor. |
| 2 | PASS | PASS | Inability to name a source. |
| 3 | FAIL | FAIL | Guard states an unauthored "third bell" closing as fact. Hard validation did not catch a clock inside dialogue. |
| 4 | FAIL | PASS | Posted "third bell" was rejected; the retry stays on the authored board. |
| 5 | PASS | PASS | Hedged NPC rumor about the muddy northwest track. |
| 6 | FAIL | PASS | Invented scent was rejected; the retry is a watch with no new patrol sign. |

Initial manual PASS 3 / 6. Final manual PASS 5 / 6. Correct contracts 4 / 6: turns 2 and 3 are the misses. Turn 2's canonical target is a slice of the previous answer. Turn 3's operation is `act` for a question, though the interlocutor correctly became the gate guard.

## 33. Evaluator vs manual

`evaluate_playability` is local. Evaluator model calls: 0. Evaluator PASS 2 / 6 (turns 2 and 4). False PASS: 0. False FAIL: 3 (turns 1, 5, and 6), against the manual reading above. Turn 3 is a true FAIL.

## 34. Legacy diagnostic comparison

Where recorded, `legacy_would_emit` matches the accepted line. No legacy mutator replaced an accepted response. Skipped mutators on every live turn include policy enforcement, authored-knowledge realization, perception non-invention, the final emission gate, and contract monotonicity.

## 35. Model and API cost

Gameplay-generation calls: 8 (six initials plus two regenerations). Interpretation calls: 2. Evaluator model calls: 0. Retry calls: 2. Aborted turns: 0. Independent smoke: not run. Full synthetic gate: not run.

## 36. Residual failure families

- A clock inside NPC dialogue ("third bell") is not the narrator-outside-quotes check, so turn 3 reached the player.
- Follow-up contract targets can become the previous sentence instead of the interlocutor.
- An accepted NPC rumor can name an unauthored institution ("ash compact census") or role ("gate serjeant") without becoming hard-invalid.
- The local evaluator still fails hedged but usable answers.

## 37. State-integrity findings

Rejected attempt text did not become the emitted line. Turn 4's "third bell" does not appear after the retry. Turn 6's invented scent does not appear in the sealed line. No rejected-response world or discourse commit was observed on the emitted path. No state-integrity failure stopped the session.

## 38. Readiness recommendation

READY FOR ANOTHER INDEPENDENT 10-TURN SMOKE: **YES.** The 16-turn replay preserves the 12 hard-valid lines, the seven downstream failures stay eliminated, the four hard-invalid initials stay blocked, immutability held on all six live turns, commit ordering held in the stubs, the retry cap held, and no accepted line was rewritten. The smoke should watch the residual families in section 36. It was not run in this cycle.

READY FOR FULL SYNTHETIC GATE: **NO.**

## 39. PR-BR status

PR-BR: **STILL OPEN.**

No completion commit. No push. PR-BS was not started. Human playtest: **NOT AUTHORIZED.** Semantic repair/rerun: no.
