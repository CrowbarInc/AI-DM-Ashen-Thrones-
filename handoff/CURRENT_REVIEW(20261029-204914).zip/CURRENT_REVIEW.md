# Campaign

Campaign: PR-PLAY-07 — Opening Semantic Acceptance and Safe-Nonresolution Investigation
Identifier: `pr_play_07`
Date: 2026-10-29
Generated: 2026-10-30T00:48:22.916185+00:00
Purpose: Offline investigation and bounded diagnostics/UI repair; stop after review ZIP.

# Executive Summary

Historical cause unresolved; no speculative semantic/prompt change. Repaired missing diagnostics/capture and erased UI failure feedback. S1–S12 pass; 405 checks pass / one entry-reproduced preexisting failure; 9 UI boundary checks pass. HTTP coverage bounded timeout. No live provider calls; no provider connectivity diagnostics; no model changes; no output-budget increases; no automatic retries; no additional provider operations; no unauthorized gameplay-state mutations; no new persistent gameplay structures; no experimental PR-EG integration; frozen ATGB baseline unchanged; no secrets included; no commit or push performed.

Objective status: `B — Conditionally ready`.

# Changes Made

## Production changes

- Opening diagnostics/capture and localized player failure feedback.

## Validation changes

- S1–S12, bounded capture/ledger controls and actual JS handler tests.

## Tooling changes

- Accounting observational stages; bounded driver/report generator.

## Documentation changes

- Nine reports, PowerShell manual, canonical session handoff.

## Generated artifacts

- Explicit diff/matrices/source/decision maps, status/integrity and review.

# What Was Tested

- **Focused tests:** 86 passed.
- **Broader relevant tests:** 405 total current checks pass / one preexisting failure; report 07 gives disjoint counts.
- **Full suite:** Not run; bounded relevant slices.
- **Runtime validation:** Synthetic SDK through actual endpoint/semantic/persistence owners; 9 Node boundary cases; HTTP suites timed out.
- **Model/runtime boundary:** No live provider or connectivity calls.
- **New regressions:** None in completed scope. Development diagnostic-consumer mismatch fixed.
- **Pre-existing failures:** Stale source attestation reproduced with saved dirty entry production sources.
- **Self-contained bundle review:** Verify nine reports, exact manual path, diff/matrices/status and ZIP manifest hashes.

# Behavioral Evidence

No standardized behavioral evidence packet was supplied.

# Decisions Requiring Human Review

- Accept/redirect conditional readiness before any future one-Start operator test.

# Known Problems / Unresolved Findings

## Campaign-specific

- Historical response/reasons absent; unresolved-answer guidance conflict; HTTP coverage timed out.

## Pre-existing baseline

- Frozen attestation stale; historical rich-emission/conversation failures not newly reproduced.

# Missing Concepts / Future Capabilities

- None recorded.

# What This Campaign Does NOT Prove

- Exact historical semantic cause, live/rendered success, reliability, independent generalization or ATGB performance.

# Recommended Next Step

External review; stop without further implementation or live opening.

# Review Bundle Contents

Bundle file count: `132`
Bundle ZIP size: `000000602244` bytes
Size warning threshold: `20971520` bytes
Size status: `WITHIN_THRESHOLD`

- `CURRENT_REVIEW.md`: generated orientation and decision surface.
- `REVIEW_MANIFEST.json`: generated provenance, inclusion, omission, and size record.
- `support/development/campaigns/product_realization/pr_play_07/09_final_verdict_and_handoff.md`: Primary campaign standard/report used to orient the review. Canonical source: `development/campaigns/product_realization/pr_play_07/09_final_verdict_and_handoff.md`.
- `support/game/gm.py`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `game/gm.py`.
- `support/game/provider_budget.py`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `game/provider_budget.py`.
- `support/game/immutable_valid_response.py`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `game/immutable_valid_response.py`.
- `support/static/app.js`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `static/app.js`.
- `support/tools/atgb/accounting.py`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `tools/atgb/accounting.py`.
- `support/tests/test_pr_play_07_semantic_acceptance.py`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `tests/test_pr_play_07_semantic_acceptance.py`.
- `support/tests/helpers/pr_play_07_ui.cjs`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `tests/helpers/pr_play_07_ui.cjs`.
- `support/tests/helpers/pr_play_07_entry_source.py`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `tests/helpers/pr_play_07_entry_source.py`.
- `support/tools/validate_pr_play_07.py`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `tools/validate_pr_play_07.py`.
- `support/tools/report_pr_play_07.py`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `tools/report_pr_play_07.py`.
- `support/docs/NEXT_SESSION.md`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `docs/NEXT_SESSION.md`.
- `support/development/campaigns/product_realization/pr_play_07/01_historical_evidence_and_baseline.md`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `development/campaigns/product_realization/pr_play_07/01_historical_evidence_and_baseline.md`.
- `support/development/campaigns/product_realization/pr_play_07/02_opening_execution_and_classification_map.md`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `development/campaigns/product_realization/pr_play_07/02_opening_execution_and_classification_map.md`.
- `support/development/campaigns/product_realization/pr_play_07/03_semantic_contract_analysis.md`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `development/campaigns/product_realization/pr_play_07/03_semantic_contract_analysis.md`.
- `support/development/campaigns/product_realization/pr_play_07/04_root_cause_and_implementation.md`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `development/campaigns/product_realization/pr_play_07/04_root_cause_and_implementation.md`.
- `support/development/campaigns/product_realization/pr_play_07/05_diagnostic_improvements.md`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `development/campaigns/product_realization/pr_play_07/05_diagnostic_improvements.md`.
- `support/development/campaigns/product_realization/pr_play_07/06_ui_failure_feedback.md`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `development/campaigns/product_realization/pr_play_07/06_ui_failure_feedback.md`.
- `support/development/campaigns/product_realization/pr_play_07/07_deterministic_validation.md`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `development/campaigns/product_realization/pr_play_07/07_deterministic_validation.md`.
- `support/development/campaigns/product_realization/pr_play_07/08_live_test_readiness.md`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `development/campaigns/product_realization/pr_play_07/08_live_test_readiness.md`.
- `support/development/campaigns/product_realization/pr_play_07/PR_PLAY_07_LIVE_OPENING_TEST.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `development/campaigns/product_realization/pr_play_07/PR_PLAY_07_LIVE_OPENING_TEST.txt`.
- `support/artifacts/pr_play_07/classification_decision_table.md`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/classification_decision_table.md`.
- `support/artifacts/pr_play_07/classification_inventory.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/classification_inventory.txt`.
- `support/artifacts/pr_play_07/diagnostic_examples.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/diagnostic_examples.json`.
- `support/artifacts/pr_play_07/entry_accounting.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/entry_accounting.txt`.
- `support/artifacts/pr_play_07/entry_accounting.xml`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/entry_accounting.xml`.
- `support/artifacts/pr_play_07/entry_accounting_run.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/entry_accounting_run.json`.
- `support/artifacts/pr_play_07/entry_head.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/entry_head.txt`.
- `support/artifacts/pr_play_07/entry_status.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/entry_status.txt`.
- `support/artifacts/pr_play_07/export.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/export.txt`.
- `support/artifacts/pr_play_07/export.xml`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/export.xml`.
- `support/artifacts/pr_play_07/export_run.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/export_run.json`.
- `support/artifacts/pr_play_07/final_status.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/final_status.txt`.
- `support/artifacts/pr_play_07/focused.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/focused.txt`.
- `support/artifacts/pr_play_07/focused.xml`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/focused.xml`.
- `support/artifacts/pr_play_07/focused_direct.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/focused_direct.txt`.
- `support/artifacts/pr_play_07/focused_direct.xml`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/focused_direct.xml`.
- `support/artifacts/pr_play_07/focused_direct_run.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/focused_direct_run.json`.
- `support/artifacts/pr_play_07/focused_final.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/focused_final.txt`.
- `support/artifacts/pr_play_07/focused_final.xml`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/focused_final.xml`.
- `support/artifacts/pr_play_07/focused_final_run.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/focused_final_run.json`.
- `support/artifacts/pr_play_07/focused_run.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/focused_run.json`.
- `support/artifacts/pr_play_07/historical_inventory.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/historical_inventory.json`.
- `support/artifacts/pr_play_07/historical_ledger.jsonl`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/historical_ledger.jsonl`.
- `support/artifacts/pr_play_07/historical_state.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/historical_state.json`.
- `support/artifacts/pr_play_07/integrity.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/integrity.json`.
- `support/artifacts/pr_play_07/opening.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/opening.txt`.
- `support/artifacts/pr_play_07/opening_direct.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/opening_direct.txt`.
- `support/artifacts/pr_play_07/opening_direct_run.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/opening_direct_run.json`.
- `support/artifacts/pr_play_07/opening_run.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/opening_run.json`.
- `support/artifacts/pr_play_07/opening_source_map.md`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/opening_source_map.md`.
- `support/artifacts/pr_play_07/ordinary.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/ordinary.txt`.
- `support/artifacts/pr_play_07/ordinary.xml`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/ordinary.xml`.
- `support/artifacts/pr_play_07/ordinary_direct.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/ordinary_direct.txt`.
- `support/artifacts/pr_play_07/ordinary_direct.xml`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/ordinary_direct.xml`.
- `support/artifacts/pr_play_07/ordinary_direct_run.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/ordinary_direct_run.json`.
- `support/artifacts/pr_play_07/ordinary_run.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/ordinary_run.json`.
- `support/artifacts/pr_play_07/protected.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/protected.json`.
- `support/artifacts/pr_play_07/provider.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/provider.txt`.
- `support/artifacts/pr_play_07/provider.xml`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/provider.xml`.
- `support/artifacts/pr_play_07/provider_final.xml`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/provider_final.xml`.
- `support/artifacts/pr_play_07/provider_final_run.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/provider_final_run.json`.
- `support/artifacts/pr_play_07/provider_run.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/provider_run.json`.
- `support/artifacts/pr_play_07/semantic.xml`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/semantic.xml`.
- `support/artifacts/pr_play_07/semantic_acceptance_matrix.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/semantic_acceptance_matrix.json`.
- `support/artifacts/pr_play_07/semantic_acceptance_matrix.md`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/semantic_acceptance_matrix.md`.
- `support/artifacts/pr_play_07/source_diff.patch`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/source_diff.patch`.
- `support/artifacts/pr_play_07/state_integrity_results.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/state_integrity_results.json`.
- `support/artifacts/pr_play_07/structured.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/structured.txt`.
- `support/artifacts/pr_play_07/structured.xml`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/structured.xml`.
- `support/artifacts/pr_play_07/structured_direct.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/structured_direct.txt`.
- `support/artifacts/pr_play_07/structured_direct.xml`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/structured_direct.xml`.
- `support/artifacts/pr_play_07/structured_direct_run.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/structured_direct_run.json`.
- `support/artifacts/pr_play_07/structured_run.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/structured_run.json`.
- `support/artifacts/pr_play_07/test_summary.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/test_summary.json`.
- `support/artifacts/pr_play_07/ui_results.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/ui_results.json`.
- `support/artifacts/pr_play_07/world.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/world.txt`.
- `support/artifacts/pr_play_07/world.xml`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/world.xml`.
- `support/artifacts/pr_play_07/world_run.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/world_run.json`.
- `support/artifacts/pr_play_07/diagnostics/budget.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/diagnostics/budget.json`.
- `support/artifacts/pr_play_07/diagnostics/concurrent.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/diagnostics/concurrent.json`.
- `support/artifacts/pr_play_07/diagnostics/D1.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/diagnostics/D1.json`.
- `support/artifacts/pr_play_07/diagnostics/D10.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/diagnostics/D10.json`.
- `support/artifacts/pr_play_07/diagnostics/D2.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/diagnostics/D2.json`.
- `support/artifacts/pr_play_07/diagnostics/D3.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/diagnostics/D3.json`.
- `support/artifacts/pr_play_07/diagnostics/D4.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/diagnostics/D4.json`.
- `support/artifacts/pr_play_07/diagnostics/D5.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/diagnostics/D5.json`.
- `support/artifacts/pr_play_07/diagnostics/D6.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/diagnostics/D6.json`.
- `support/artifacts/pr_play_07/diagnostics/D7.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/diagnostics/D7.json`.
- `support/artifacts/pr_play_07/diagnostics/D8.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/diagnostics/D8.json`.
- `support/artifacts/pr_play_07/diagnostics/D9.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/diagnostics/D9.json`.
- `support/artifacts/pr_play_07/diagnostics/extraction.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/diagnostics/extraction.json`.
- `support/artifacts/pr_play_07/diagnostics/placeholder.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/diagnostics/placeholder.json`.
- `support/artifacts/pr_play_07/diagnostics/repeat.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/diagnostics/repeat.json`.
- `support/artifacts/pr_play_07/diagnostics/retry.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/diagnostics/retry.json`.
- `support/artifacts/pr_play_07/diagnostics/validation.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/diagnostics/validation.json`.
- `support/artifacts/pr_play_07/initial_run/export.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/initial_run/export.txt`.
- `support/artifacts/pr_play_07/initial_run/export.xml`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/initial_run/export.xml`.
- `support/artifacts/pr_play_07/initial_run/export_run.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/initial_run/export_run.json`.
- `support/artifacts/pr_play_07/initial_run/focused.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/initial_run/focused.txt`.
- `support/artifacts/pr_play_07/initial_run/focused_run.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/initial_run/focused_run.json`.
- `support/artifacts/pr_play_07/initial_run/opening.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/initial_run/opening.txt`.
- `support/artifacts/pr_play_07/initial_run/ordinary.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/initial_run/ordinary.txt`.
- `support/artifacts/pr_play_07/initial_run/ordinary_run.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/initial_run/ordinary_run.json`.
- `support/artifacts/pr_play_07/initial_run/provider.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/initial_run/provider.txt`.
- `support/artifacts/pr_play_07/initial_run/provider.xml`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/initial_run/provider.xml`.
- `support/artifacts/pr_play_07/initial_run/provider_run.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/initial_run/provider_run.json`.
- `support/artifacts/pr_play_07/initial_run/structured.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/initial_run/structured.txt`.
- `support/artifacts/pr_play_07/initial_run/structured_run.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/initial_run/structured_run.json`.
- `support/artifacts/pr_play_07/initial_run/world.txt`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/initial_run/world.txt`.
- `support/artifacts/pr_play_07/initial_run/world.xml`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/initial_run/world.xml`.
- `support/artifacts/pr_play_07/initial_run/world_run.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/initial_run/world_run.json`.
- `support/artifacts/pr_play_07/matrix/S1.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/matrix/S1.json`.
- `support/artifacts/pr_play_07/matrix/S10.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/matrix/S10.json`.
- `support/artifacts/pr_play_07/matrix/S11.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/matrix/S11.json`.
- `support/artifacts/pr_play_07/matrix/S12.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/matrix/S12.json`.
- `support/artifacts/pr_play_07/matrix/S2.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/matrix/S2.json`.
- `support/artifacts/pr_play_07/matrix/S3.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/matrix/S3.json`.
- `support/artifacts/pr_play_07/matrix/S4.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/matrix/S4.json`.
- `support/artifacts/pr_play_07/matrix/S5.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/matrix/S5.json`.
- `support/artifacts/pr_play_07/matrix/S6.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/matrix/S6.json`.
- `support/artifacts/pr_play_07/matrix/S7.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/matrix/S7.json`.
- `support/artifacts/pr_play_07/matrix/S8.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/matrix/S8.json`.
- `support/artifacts/pr_play_07/matrix/S9.json`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/matrix/S9.json`.
- `support/artifacts/pr_play_07/entry/docs/NEXT_SESSION.md`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/entry/docs/NEXT_SESSION.md`.
- `support/artifacts/pr_play_07/entry/game/api.py`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/entry/game/api.py`.
- `support/artifacts/pr_play_07/entry/game/gm.py`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/entry/game/gm.py`.
- `support/artifacts/pr_play_07/entry/game/immutable_valid_response.py`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/entry/game/immutable_valid_response.py`.
- `support/artifacts/pr_play_07/entry/game/provider_budget.py`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/entry/game/provider_budget.py`.
- `support/artifacts/pr_play_07/entry/tools/atgb/accounting.py`: Scoped PR-PLAY-07 source, reports, manual and deterministic validation. Canonical source: `artifacts/pr_play_07/entry/tools/atgb/accounting.py`.

## Explicit omissions

- `development/campaigns/product_realization/pr_play_07/09_final_verdict_and_handoff.md`: duplicate content of development/campaigns/product_realization/pr_play_07/09_final_verdict_and_handoff.md; canonical reference retained
- `artifacts/pr_play_07/provider_final.txt`: duplicate content of artifacts/pr_play_07/provider.txt; canonical reference retained
- `artifacts/pr_play_07/initial_run/focused.xml`: duplicate content of artifacts/pr_play_07/focused.xml; canonical reference retained
- `artifacts/pr_play_07/initial_run/ordinary.xml`: duplicate content of artifacts/pr_play_07/ordinary.xml; canonical reference retained
- `artifacts/pr_play_07/initial_run/structured.xml`: duplicate content of artifacts/pr_play_07/structured.xml; canonical reference retained

The bundle intentionally excludes repository copies, dependency/cache directories, previous handoffs, unrelated artifacts, and sensitive configuration.
Canonical repository files remain authoritative; packaged copies are review conveniences with hashes and source paths.
