# Campaign

Campaign: ATGB-R1-06 Conversational Disposition and Evidence Selection
Identifier: `atgb_r1_06_conversational_disposition_and_evidence_selection`
Date: 2026-10-19
Generated: 2026-10-19T09:58:33.671534+00:00
Purpose: Offline causal investigation only; no implementation or provider authority.

# Executive Summary

Three preserved interpretations recognize the corrected people subject but select CLARIFICATION and no public evidence. Relevant public descriptions were in the requests. The host faithfully emits redundant questions. Narrow correction/clarification definitions are a plausible contract cause, not experimentally proven. Propose a bounded existing-owner contract/evidence repair and acknowledgment after external review. Raw L3 reached the revision guard, contrary to its earlier summary.

Objective status: `B — CONDITIONAL; STOP FOR EXTERNAL REVIEW`.

# Changes Made

## Production changes

- None; production, prompts/schema, experiments and frozen baseline unchanged.

## Validation changes

- Offline reconstruction of three historical traces; no tests or live trials executed.

## Tooling changes

- No new diagnostic or production instrumentation. Existing packet/export utilities used offline.

## Documentation changes

- Eight reports and index; canonical NEXT_SESSION orientation.

## Generated artifacts

- Trace/source/PR-EG excerpts, evidence packet, hash/status evidence and review ZIP.

# What Was Tested

- **Focused tests:** Static JSON consistency and hash checks; existing evidence-packet validator; no gameplay tests.
- **Broader relevant tests:** Not run; historical results remain historical.
- **Full suite:** Not run.
- **Runtime validation:** No new execution. Three historical direct chat trials examined (R1-05 L1/L2, R1-03 L3).
- **Model/runtime boundary:** Historical OpenAI Responses gpt-4.1-mini / returned gpt-4.1-mini-2025-04-14. Zero new admissions.
- **New regressions:** No runtime change; protected SHA-256 comparison supplied.
- **Pre-existing failures:** Redundant clarification; historical invalid R1-03 L4; extensive pre-existing dirty state; human adjudication pending.
- **Self-contained bundle review:** All eight reports; exact prior/player/GM text; complete selected raw traces and source references; compared PR-EG rows; candidate and validation proposal; protected hashes, status and limitations. Verify CRC, hashes and secrets offline.

# Behavioral Evidence

## Evidence Packet: ATGB-R1-06

Runs / turns: `3` / `3`
Runtime/model boundary: Historical production interpretation, orchestration and final emission

### Representative success

No example observed in this campaign.

### Representative failure

Example: `L3`
Player classification: `representative_player_behavior, boundary_case`
Player: No, I was asking about the people, not the weather.
GM: Do you want a description of the people present at the gate district instead of the weather?
Automated result: `FAIL`
Human review: `UNREVIEWED` - External review pending; AI-assisted assessment only.
Source: `artifacts/atgb/atgb_r1_03/L3/response.json`

### Evaluator disagreement

No example observed in this campaign.

### Ambiguous/unexpected

No example observed in this campaign.

### Stress probe

No example observed in this campaign.

### All evaluator disagreements

No example observed in this campaign.


# Decisions Requiring Human Review

- Review B verdict and proposed ATGB-R1-07 scope. No implementation, live calls or PR-EG integration begins automatically.

# Known Problems / Unresolved Findings

## Campaign-specific

- Instruction-level causality unmeasured; no demonstrated repair effect.
- Raw L3 reaches revision guard despite historical summary saying otherwise.
- No reliable generic clarification-necessity discriminator in this legacy record.

## Pre-existing baseline

- Frozen benchmark response weakness, pending authenticated human review and accounting/HTTP limitations remain.

# Missing Concepts / Future Capabilities

- Explicit distinction between supplied conversational correction and GM need for clarification within the existing contract.

# What This Campaign Does NOT Prove

- A successful repair, instruction-level causation, general conversational competence, new benchmark score, independent generalization or full-suite green.

# Recommended Next Step

Stop for external review. If separately authorized, implement only report 07 bounded interpretation/evidence and existing-answer acknowledgment proposal, validate deterministically, and obtain separate live-call authority.

# Review Bundle Contents

Bundle file count: `82`
Bundle ZIP size: `000000567962` bytes
Size warning threshold: `20971520` bytes
Size status: `WITHIN_THRESHOLD`

- `CURRENT_REVIEW.md`: generated orientation and decision surface.
- `REVIEW_MANIFEST.json`: generated provenance, inclusion, omission, and size record.
- `support/development/reports/atgb_r1_06_conversational_disposition_and_evidence_selection.md`: Primary campaign standard/report used to orient the review. Canonical source: `development/reports/atgb_r1_06_conversational_disposition_and_evidence_selection.md`.
- `support/artifacts/validation_evidence/atgb_r1_06/evidence_summary.md`: Standardized behavioral evidence packet consumed by the handoff. Canonical source: `artifacts/validation_evidence/atgb_r1_06/evidence_summary.md`.
- `support/artifacts/validation_evidence/atgb_r1_06/evidence_manifest.json`: Standardized behavioral evidence packet consumed by the handoff. Canonical source: `artifacts/validation_evidence/atgb_r1_06/evidence_manifest.json`.
- `support/artifacts/atgb/atgb_r1_03/L3/accounting.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_03/L3/accounting.json`.
- `support/artifacts/atgb/atgb_r1_03/L3/after.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_03/L3/after.json`.
- `support/artifacts/atgb/atgb_r1_03/L3/before.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_03/L3/before.json`.
- `support/artifacts/atgb/atgb_r1_03/L3/response.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_03/L3/response.json`.
- `support/artifacts/atgb/atgb_r1_03/L3/trace.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_03/L3/trace.json`.
- `support/artifacts/atgb/atgb_r1_03/entry_hashes.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_03/entry_hashes.json`.
- `support/artifacts/atgb/atgb_r1_03/transcripts.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_03/transcripts.md`.
- `support/artifacts/atgb/atgb_r1_05/L1/accounting.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_05/L1/accounting.json`.
- `support/artifacts/atgb/atgb_r1_05/L1/after.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_05/L1/after.json`.
- `support/artifacts/atgb/atgb_r1_05/L1/before.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_05/L1/before.json`.
- `support/artifacts/atgb/atgb_r1_05/L1/response.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_05/L1/response.json`.
- `support/artifacts/atgb/atgb_r1_05/L1/traces.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_05/L1/traces.json`.
- `support/artifacts/atgb/atgb_r1_05/L2/accounting.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_05/L2/accounting.json`.
- `support/artifacts/atgb/atgb_r1_05/L2/after.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_05/L2/after.json`.
- `support/artifacts/atgb/atgb_r1_05/L2/before.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_05/L2/before.json`.
- `support/artifacts/atgb/atgb_r1_05/L2/response.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_05/L2/response.json`.
- `support/artifacts/atgb/atgb_r1_05/L2/traces.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_05/L2/traces.json`.
- `support/artifacts/atgb/atgb_r1_05/entry_hashes.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_05/entry_hashes.json`.
- `support/artifacts/atgb/atgb_r1_05/provider_accounting.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_05/provider_accounting.json`.
- `support/artifacts/atgb/atgb_r1_06/NEXT_SESSION_before.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_06/NEXT_SESSION_before.md`.
- `support/artifacts/atgb/atgb_r1_06/entry_hashes.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_06/entry_hashes.json`.
- `support/artifacts/atgb/atgb_r1_06/integrity_verification.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_06/integrity_verification.json`.
- `support/artifacts/atgb/atgb_r1_06/pr_eg_comparison_rows.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_06/pr_eg_comparison_rows.json`.
- `support/artifacts/atgb/atgb_r1_06/predecessor_hash_comparison.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_06/predecessor_hash_comparison.json`.
- `support/artifacts/atgb/atgb_r1_06/repository_identity.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_06/repository_identity.json`.
- `support/artifacts/atgb/atgb_r1_06/repository_status_after.txt`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_06/repository_status_after.txt`.
- `support/artifacts/atgb/atgb_r1_06/repository_status_before.txt`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_06/repository_status_before.txt`.
- `support/artifacts/atgb/atgb_r1_06/source_excerpts.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_06/source_excerpts.md`.
- `support/artifacts/atgb/atgb_r1_06/trace_reconstruction.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/atgb/atgb_r1_06/trace_reconstruction.json`.
- `support/artifacts/pr_eg_r6_r5/03_PRODUCTION_PIPELINE_MAP.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/pr_eg_r6_r5/03_PRODUCTION_PIPELINE_MAP.md`.
- `support/artifacts/pr_eg_r6_r5/07_CONVERSATIONAL_CONTEXT.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/pr_eg_r6_r5/07_CONVERSATIONAL_CONTEXT.md`.
- `support/artifacts/pr_eg_r6_r5/11_PRODUCTION_BASELINE.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/pr_eg_r6_r5/11_PRODUCTION_BASELINE.md`.
- `support/artifacts/pr_eg_r6_r5/16_SOURCE_RETRIEVAL_INTERVENTION.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/pr_eg_r6_r5/16_SOURCE_RETRIEVAL_INTERVENTION.md`.
- `support/artifacts/pr_eg_r6_r5/25_FIRST_FAILURE_ATTRIBUTION.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/pr_eg_r6_r5/25_FIRST_FAILURE_ATTRIBUTION.md`.
- `support/artifacts/pr_eg_r6_r5/27_PLAYER_FACING_QUALITY.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/pr_eg_r6_r5/27_PLAYER_FACING_QUALITY.md`.
- `support/artifacts/pr_eg_r6_r5/32_REPAIR_PRIORITIZATION.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/pr_eg_r6_r5/32_REPAIR_PRIORITIZATION.md`.
- `support/artifacts/pr_eg_r6_r5/36_FINAL_VERDICT.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `artifacts/pr_eg_r6_r5/36_FINAL_VERDICT.md`.
- `support/development/reports/atgb_r1_01_s08_2_causal_trace.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `development/reports/atgb_r1_01_s08_2_causal_trace.md`.
- `support/development/reports/atgb_r1_02/02_routing_contract.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `development/reports/atgb_r1_02/02_routing_contract.md`.
- `support/development/reports/atgb_r1_02/08_final_verdict.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `development/reports/atgb_r1_02/08_final_verdict.md`.
- `support/development/reports/atgb_r1_02_mechanical_revision_boundary.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `development/reports/atgb_r1_02_mechanical_revision_boundary.md`.
- `support/development/reports/atgb_r1_03/05_failure_localization.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `development/reports/atgb_r1_03/05_failure_localization.md`.
- `support/development/reports/atgb_r1_04/08_final_verdict.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `development/reports/atgb_r1_04/08_final_verdict.md`.
- `support/development/reports/atgb_r1_05/05_failure_localization.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `development/reports/atgb_r1_05/05_failure_localization.md`.
- `support/development/reports/atgb_r1_05/08_final_verdict.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `development/reports/atgb_r1_05/08_final_verdict.md`.
- `support/development/reports/atgb_r1_06/01_baseline_reconciliation.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `development/reports/atgb_r1_06/01_baseline_reconciliation.md`.
- `support/development/reports/atgb_r1_06/02_conversational_contract_reconstruction.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `development/reports/atgb_r1_06/02_conversational_contract_reconstruction.md`.
- `support/development/reports/atgb_r1_06/03_interpretation_schema_analysis.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `development/reports/atgb_r1_06/03_interpretation_schema_analysis.md`.
- `support/development/reports/atgb_r1_06/04_evidence_selection_analysis.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `development/reports/atgb_r1_06/04_evidence_selection_analysis.md`.
- `support/development/reports/atgb_r1_06/05_host_clarification_analysis.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `development/reports/atgb_r1_06/05_host_clarification_analysis.md`.
- `support/development/reports/atgb_r1_06/06_pr_eg_comparison_and_causal_verdict.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `development/reports/atgb_r1_06/06_pr_eg_comparison_and_causal_verdict.md`.
- `support/development/reports/atgb_r1_06/07_minimal_repair_and_validation_proposal.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `development/reports/atgb_r1_06/07_minimal_repair_and_validation_proposal.md`.
- `support/development/reports/atgb_r1_06/08_final_verdict.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `development/reports/atgb_r1_06/08_final_verdict.md`.
- `support/docs/DEVELOPMENT_CONSTITUTION.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `docs/DEVELOPMENT_CONSTITUTION.md`.
- `support/docs/NEXT_SESSION.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `docs/NEXT_SESSION.md`.
- `support/docs/product_realization_validation.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `docs/product_realization_validation.md`.
- `support/docs/review_handoff_standard.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `docs/review_handoff_standard.md`.
- `support/docs/validation_evidence_standard.md`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `docs/validation_evidence_standard.md`.
- `support/experiments/pr_do/adapter.py`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `experiments/pr_do/adapter.py`.
- `support/experiments/pr_do/eligibility.py`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `experiments/pr_do/eligibility.py`.
- `support/experiments/pr_do/fixtures.py`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `experiments/pr_do/fixtures.py`.
- `support/experiments/pr_do/schema.py`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `experiments/pr_do/schema.py`.
- `support/experiments/pr_dp/prompt.py`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `experiments/pr_dp/prompt.py`.
- `support/experiments/pr_dr/prompt.py`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `experiments/pr_dr/prompt.py`.
- `support/game/api.py`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `game/api.py`.
- `support/game/conversational_orchestration.py`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `game/conversational_orchestration.py`.
- `support/game/dialogue_authority.py`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `game/dialogue_authority.py`.
- `support/game/immutable_valid_response.py`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `game/immutable_valid_response.py`.
- `support/game/live_chat_interpretation.py`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `game/live_chat_interpretation.py`.
- `support/game/semantic_interpreter.py`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `game/semantic_interpreter.py`.
- `support/tests/fixtures/pr_ef_r4_holdouts.json`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `tests/fixtures/pr_ef_r4_holdouts.json`.
- `support/tests/test_atgb_r1_02_revision_boundary.py`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `tests/test_atgb_r1_02_revision_boundary.py`.
- `support/tests/test_pr_ea_conversational_orchestration.py`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `tests/test_pr_ea_conversational_orchestration.py`.
- `support/tests/test_pr_eb_conversational_continuity.py`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `tests/test_pr_eb_conversational_continuity.py`.
- `support/tests/test_pr_ef_r4_authorization.py`: Explicit support for the eight-report causal investigation; static or historical, not a new execution. Canonical source: `tests/test_pr_ef_r4_authorization.py`.
- `support/artifacts/atgb/atgb_r1_06/review_config.json`: Explicit export configuration or offline verification results. Canonical source: `artifacts/atgb/atgb_r1_06/review_config.json`.
- `support/artifacts/atgb/atgb_r1_06/review_verification.json`: Explicit export configuration or offline verification results. Canonical source: `artifacts/atgb/atgb_r1_06/review_verification.json`.

## Explicit omissions

No explicitly requested file was omitted.

The bundle intentionally excludes repository copies, dependency/cache directories, previous handoffs, unrelated artifacts, and sensitive configuration.
Canonical repository files remain authoritative; packaged copies are review conveniences with hashes and source paths.
