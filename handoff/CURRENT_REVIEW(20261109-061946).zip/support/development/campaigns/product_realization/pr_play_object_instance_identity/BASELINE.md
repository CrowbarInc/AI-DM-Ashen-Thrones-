# Baseline

Milestone: `pr_play_object_instance_identity`. Date: 2026-11-09.

Branch `feature/product-realization`; HEAD `d40f1ed198236c604085f1c842ead267a8104ce2`. Entry dirty status: 827 lines; exact status/hashes retained. before_manifest.json captures 1581 source/test/data/static/prompt/tool/script hashes before production edits.

Fresh pre-edit preservation 143/143; fresh combined baseline 405 passed / 20 failed / 0 errors / 0 skipped (425 tests). Its process loaded the source before implementation edits; run was completed during development. The first redirected combined attempt was interrupted before completion and is excluded; retry is the authoritative baseline. Extra preservation diagnostic run also passed 143. No completed attempt is relabeled.

Existing load_character/save_character preserve arbitrary JSON rows. snapshot creation bundles character/session/world/combat/log; restore validates then writes with exception rollback. Inventory consumers/defaults/PF importer retain id/name/quantity/usable. Identity is absent before explicit assignment.

Known failure identities:

- tests/test_referenced_surface_grounding_inspection_resolution.py::test_general_unknown_player_named_object_is_not_instantiated
- tests/test_referenced_surface_grounding_inspection_resolution.py::test_general_narration_only_object_does_not_gain_authority
- tests/test_referenced_surface_grounding_inspection_resolution.py::test_general_readable_surface_communicates_contents
- tests/test_referenced_surface_grounding_inspection_resolution.py::test_general_failed_inspection_then_observe_uses_current_scene
- tests/test_referenced_surface_grounding_inspection_resolution.py::test_general_authored_alias_binds
- tests/test_referenced_surface_grounding_inspection_resolution.py::test_frontier_gate_roster_http_does_not_use_observe_stock
- tests/test_referenced_surface_grounding_inspection_resolution.py::test_observe_stock_replacement_keeps_notice_board_working
- tests/test_pr_play_39_action_admission.py::test_sequence_patrol_travel_reaches_the_movement_resolver
- tests/test_pr_play_39_action_admission.py::test_sequence_unsupported_actions_invent_nothing
- tests/test_pr_br_continuation18_immutable_boundary.py::test_raw_chat_stub_preserves_valid_and_contains_invalid
- tests/test_perception_narration_authority_audible_non_invention.py::test_player_seeks_whisper_does_not_create_one
- tests/test_perception_narration_authority_audible_non_invention.py::test_http_empty_listen_complete_and_grounded
- tests/test_perception_narration_authority_audible_non_invention.py::test_http_authorized_speech_can_survive
- tests/test_pr_play_79df3_classification.py::test_duplicate_refusal_does_not_publish
- tests/test_pr_play_79df3_classification.py::test_two_refusals_then_gameplay_advances
- tests/test_pr_play_79df3_classification.py::test_save_reload_keeps_the_preceding_publication
- tests/test_pr_play_79df3_classification.py::test_http_fallback_is_not_an_operational_refusal
- tests/test_pr_de_exact_contract_deduplication.py::test_s1_s2_s3_drop_exact_mirrors_and_keep_reduced_context
- tests/test_pr_de_exact_contract_deduplication.py::test_full_context_classes_stay_unprojected_while_mirrors_drop
- tests/test_manual_play_latency.py::test_manual_play_compact_prompt_keeps_continuity_and_shrinks_payload
