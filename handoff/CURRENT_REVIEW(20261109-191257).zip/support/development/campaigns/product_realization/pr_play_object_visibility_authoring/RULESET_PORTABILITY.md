# Ruleset Portability

Milestone: `pr_play_object_visibility_authoring`. Date: 2026-11-09.

PF1e perception_dc/ac, rules_light tags and science-fiction sensor/encryption/battery extensions persist unchanged at character, object and marking levels through classification/save/reload. All three produce identical permitted inscription DTOs. Core never interprets Perception/DCs, spells, proficiency, rarity or technology. No mechanics means explicit upstream not_applicable evidence for this internal classification, not a general gameplay exemption. Evidence: portability_pf1e@1.json, portability_rules_light@1.json, portability_scifi@1.json. Boundary portability only; no alternate-ruleset runtime implemented.
