import copy, json, os, sys
from pathlib import Path
from unittest.mock import patch
ROOT=Path.cwd(); sys.path.insert(0,str(ROOT))
os.environ['ASHEN_DISABLE_PROVIDER_CALLS']='1'
os.environ['ASHEN_DISABLE_LIVE_INTERPRETATION']='1'
from game import live_chat_interpretation as live
OUT=ROOT/'artifacts/atgb/atgb_r2_04'
contexts=json.loads((ROOT/'artifacts/atgb/atgb_r2_03/context_and_original_logs.json').read_text(encoding='utf-8'))
inputs={r['turn_id']:r['player_input'] for r in json.loads((ROOT/'artifacts/atgb/atgb_r2_03/historical_trace_excerpts.json').read_text(encoding='utf-8'))}
scene=json.loads((ROOT/'data/validation/atgb/baselines/frontier-gate-v1/scenes/frontier_gate.json').read_text())
world=json.loads((ROOT/'data/validation/atgb/baselines/frontier-gate-v1/world.json').read_text())
requests=[]
with patch('socket.socket',side_effect=AssertionError('network forbidden')):
    for row in contexts:
        def wire(messages, **kwargs):
            requests.append({'turn_id':row['turn_id'],'messages':copy.deepcopy(messages),'schema':live.production_interpretation_schema(),**kwargs})
            return {'ok':False,'sent':False,'reason':'offline_capture'}
        with patch.object(live,'production_live_interpretation_enabled',return_value=True),patch.object(live,'request_interpretation',side_effect=wire):
            live.interpret_production_turn(player_text=inputs[row['turn_id']],mode='AUTO',scene=scene,world=world,log=row['preceding_log'],session={'active_scene_id':'frontier_gate','interaction_context':{'active_interaction_target_id':'tavern_runner'} } if row['turn_id']=='S05.3' else {'active_scene_id':'frontier_gate'})
(OUT/('effective_'+sys.argv[1]+'.json')).write_text(json.dumps(requests,indent=2,ensure_ascii=False),encoding='utf-8')
print(f'Captured {len(requests)} requests; no dispatch')
