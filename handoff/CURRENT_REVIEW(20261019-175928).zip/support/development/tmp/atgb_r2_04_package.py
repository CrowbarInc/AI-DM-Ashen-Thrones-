"""Create the bounded R2-04 review export from explicit local evidence."""
import ast, difflib, hashlib, json, re, shutil, subprocess, sys, zipfile
from datetime import datetime, timezone, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo
import xml.etree.ElementTree as ET
ROOT=Path.cwd(); sys.path.insert(0,str(ROOT))
OUT=ROOT/'artifacts/atgb/atgb_r2_04'
REPORT=ROOT/'development/reports/atgb_r2_04'; REPORT.mkdir(parents=True,exist_ok=True)
def read(name): return json.loads((OUT/name).read_text(encoding='utf-8'))
def write(path,value):
    path=ROOT/path; path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(value if isinstance(value,str) else json.dumps(value,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def rel(path): return path.relative_to(ROOT).as_posix()
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
sizes=read('prompt_sizes.json'); integrity=read('integrity.json'); baseline=read('baseline.json')
assert integrity['all_other_production_unchanged']
def junit(name):
    tree=ET.parse(OUT/name)
    cases=tree.findall('.//testcase')
    return {'tests':len(cases),'passed':sum(not list(c) or not any(c.find(t) is not None for t in ['failure','error','skipped']) for c in cases),
            'failures':[c.attrib for c in cases if c.find('failure') is not None], 'errors':[c.attrib for c in cases if c.find('error') is not None], 'skipped':[c.attrib for c in cases if c.find('skipped') is not None]}
tests={k:junit(v) for k,v in [('baseline_nonhttp','baseline_nonhttp.xml'),('after_nonhttp','after_nonhttp.xml'),('focused','focused_verified.xml')]}
assert tests['baseline_nonhttp']['passed']==314 and tests['after_nonhttp']['passed']==332 and tests['focused']['passed']==198
assert all(not r['errors'] and not r['failures'] for r in tests.values())
http_before=read('http_baseline_inventory.json'); http_after=read('http_after_inventory.json')
assert http_before['deselected']==http_after['deselected'] and len(http_after['deselected'])==39
write(OUT/'regression_summary.json',{'evidence_scope':'structural_only','semantic_behavioral_evidence':False,**tests,'environment_blocked_HTTP':http_after['deselected'],
    'new_product_regressions_observed':[],'preexisting_product_failures_reproduced_in_completed_slice':[],
    'historically_reported_not_reproduced_here':['test_pr_br_continuation22_commitment.py::test_raw_chat_stub_covers_commitment_and_addressee','test_directed_social_routing.py::test_chat_hailing_runner_with_can_you_question_routes_social'],
    'incomplete_attempts':[{'log':'baseline_regression.txt','classification':'indeterminate','detail':'Interrupted before traceback/summary; default temp-root run showed setup errors and failures. No failure-node/root-cause classification possible from partial log.'},
        {'log':'baseline_regression_retry.txt','classification':'environment-blocked','detail':'Local-temp .venv 3.12.0 execution stalled after collection before first TestClient case completed; interrupted.'},
        {'log':'baseline_bundled.txt','classification':'environment-blocked','detail':'Bundled 3.12.14 reproduced the same pre-change stall with local temp; interrupted.'}],
    'harness_corrections':[{'logs':['focused.txt','focused_final.txt'],'classification':'implementation: new test fixture errors, corrected','detail':'S05 minimal session omitted active_interaction_kind; adding it to S02 as well caused unintended NPC routing. Final fixture matches R2-03 per scenario; no production change or weakened expected output.'}],
    'limitations':['No full-suite result','No completed HTTP transport result','No live model selection or authority result']})
schema=read('effective_before.json')[0]['schema']
write(OUT/'schema_before.json',schema); write(OUT/'schema_after.json',read('effective_after.json')[0]['schema'])
enums={}
def walk(obj,path=''):
    if isinstance(obj,dict):
        if 'enum' in obj: enums[path]=obj['enum']
        for key,v in obj.items(): walk(v,path+'/'+key)
    elif isinstance(obj,list):
        for i,v in enumerate(obj): walk(v,path+'/'+str(i))
walk(schema)
write(OUT/'schema_inventory.json',{'properties':list(schema['properties']),'required':schema['required'],'optional':[p for p in schema['properties'] if p not in schema['required']],'enums':enums})
old=(OUT/'instruction_before.txt').read_text(encoding='utf-8'); new=(OUT/'instruction_after.txt').read_text(encoding='utf-8')
def excerpt(s): return s[s.index('Recover the underlying question'):s.index('Acknowledgments asserting')].strip()
history=json.loads((ROOT/'artifacts/atgb/atgb_r2_03/historical_trace_excerpts.json').read_text(encoding='utf-8'))
provenance=[]
for row in history:
    for p,h in [(row['source'],row['source_sha256']),(row['log_source'],row['log_sha256'])]:
        assert sha(ROOT/p)==h
        if not any(v['path']==p for v in provenance): provenance.append({'path':p,'sha256':h,'matches_original_trace_provenance':True})
write(OUT/'historical_provenance_verification.json',provenance)
ch=sizes['instruction']['characters']; tok=sizes['instruction']['estimated_tokens_chars_div_4']
history_lines='\n'.join(f"| {r['turn_id']} | {r['player_input']} | {r['model_interpretation']['communication']['subject']} / {', '.join(r['model_interpretation']['communication']['evidence_refs'])} | {r['final_player_facing_response']} |" for r in history)
compat=read('historical_compatibility.json')
compat_lines='\n'.join(f"| {r['turn_id']} | {r['exact_substituted_raw']['communication']['subject']} | {r['host_decision']['category']} | {r['host_decision']['player_facing_text']} |" for r in compat)
reports={
'01_baseline_and_contract_inventory.md':f'''# 01 — Baseline and Contract Inventory

ATGB-R2-04; bounded instruction repair; implementation authority limited, live provider authority none. Entry HEAD `{baseline['head']}`, branch `{baseline['branch']}`. Extensive preexisting modifications include the target production file, other production, governance, data and generated artifacts. Full status: `artifacts/atgb/atgb_r2_04/repository_status_before.txt`. Entry source and canonical orientation were copied before editing; this pass is compared with working-tree entry bytes, not HEAD. No unrelated entry modifications were overwritten.

Read the four required authorities: DEVELOPMENT_CONSTITUTION, canonical docs/NEXT_SESSION.md, validation_evidence_standard and product_realization_validation; also review_handoff_standard. Requested support/docs/NEXT_SESSION.md is absent. The Constitution identifies docs/NEXT_SESSION.md as canonical, so that file supplied orientation. Reviewed R2-01 original trace extraction/PR-EG rows, R2-02 production replay and tests, R2-03 original-log contexts, controls and reports, R1-07 request construction/correction tests and PR-EG R6-R5 / R6-R4-R1 verdicts. Prior repair decisions remain settled.

## Existing production contract

`interpret_production_turn` obtains a catalog and two recent player-visible turns from the established contract builder, specializes legacy communication-mode text in the user message, appends communication/evidence/correction guidance to the system message, then appends the public evidence projection and ownership context to the user message. The sole changed surface is the existing system-message instruction literal. Effective pre-change requests for the four cases are in effective_before.json; full appended guidance is in instruction_before.txt. These are current-source reconstructions, not recovered original provider requests.

Existing instructions already distinguish conversational correction from eligible pending mechanical revision, permit zero-operation interpreted GM communication, prohibit hidden/unsupported evidence, ask targeted clarification for meaningful ambiguity, and require unique demonstrative referents. Evidence wording referred broadly to supporting a corrected question without spelling out requested detail versus topic. Missing-answer guidance did not clearly separate unavailable facts from unresolved player intent. R1-07's correction path is retained.

Schema required top-level fields: `{schema['required']}`. Optional top-level fields: `{[p for p in schema['properties'] if p not in schema['required']]}`. `communication` requires recipient, purpose, subject (string), evidence_refs (array of supplied string IDs). Full nested structure, required/optional fields and enums are recorded in schema_before.json and schema_inventory.json. Recipient/purpose descriptions, all fields/enums, parser, validation, unresolved references and mode representation remain unchanged.

## Historical causal baseline

| Turn | Exact player input | Model subject / selected evidence | Historical final output |
|---|---|---|---|
{history_lines}

Original result/log hashes were verified against the R2-03 extraction provenance in historical_provenance_verification.json. Original logs and selected trace payloads are packaged. S02.4's actual input includes “All right.” R2-03 established that curfew hours are unauthored and the posted last-seen clue remains gated. R2-02 already repaired recipient grounding; S05.3 still has competing runner/board accounts after an intervening failed reply. PR-EG's request/source and referent-binding failures support the discrimination hypothesis but authorize no experimental integration. The earliest wrong historical decision is semantic interpretation selection; wording causality is unproven.

Existing deterministic coverage: R1-07 effective request/correction/evidence tests, R1-02 pending revision tests and R2-02 speech-participant tests passed before editing (180 cases). Broader completed entry slice: 314 passed / 39 HTTP tests explicitly deselected after documented transport stalls. Prompt baseline: appended instruction {ch['before']:,} characters, approximate chars/4 {tok['before']:,} tokens. Scope excludes schema, parser, host, state, providers, gameplay, frozen inputs and experiments.
''',
'02_instruction_change_analysis.md':f'''# 02 — Instruction Change Analysis

One contiguous paragraph replacement inside the existing production system instruction; no standalone prompt section or new instruction surface. Exact old and replacement text follow. Full reviewable source/test diff is source.diff.

## Before

```text
{excerpt(old)}
```

## After

```text
{excerpt(new)}
```

Requested-detail wording links the existing subject and evidence_refs to the actual information request. This targets S02.2 timing and S02.4 last-seen location without hardcoding either scenario. Related-topic evidence is insufficient, while useful background may still support a partial answer; descriptive/explanatory requests remain valid.

Preceding-context, unique-subject and rejected-alternative wording targets S02.3: its rejected patrol interpretation must not displace the established curfew question. It covers elliptical follow-ups without forcing every demonstrative to resolve. S05.3's competing accounts remain genuine ambiguity; clarification concerns subject independently of established recipient.

Understood/no-answer wording permits empty evidence_refs plus the existing honest limitation. It does not manufacture an answer, require a player clarification for a missing fact, or categorically ban clarification. Genuine competing subjects/interlocutors/action parameters and conflicting intentions still require targeted clarification.

R1-07 conversational correction, GM/CORRECTION + legacy OTHER, correction.subject REFERENT, empty action components and eligible pending-action restrictions are unchanged. R2-02 grounding is unchanged. PUBLIC-only selection and no unsupported inference remain explicit. Schema semantics still carry meaning and control disposition through existing fields. No source/category-specific classifier, state store or provider stage was added.

The deterministic checks establish presence and host compatibility only. They cannot show that a future completion will obey the replacement or that wording caused the original model failure.
''',
'03_implementation_diff.md':'''# 03 — Implementation Diff

Production modified by this pass: game/live_chat_interpretation.py, one existing system-instruction literal in interpret_production_turn. New test: tests/test_atgb_r2_04_question_evidence_contract.py (18 collected cases). No existing tests changed. Entry working-tree source is live_chat_interpretation.py.before; full modified source and test are included at their canonical paths in the ZIP. source.diff includes only this pass's production/test delta, excluding prior dirty changes.

contract_preservation.json proves exact effective schema equality across all four before/after requests, including descriptions, required and optional fields, enums and evidence/mode/unresolved-reference representation. AST comparison replacing only the changed instruction literal yields equality for the complete production module. Thus parser, validation, provider dispatch/configuration, call count and all other executable logic are unchanged.

integrity.json hashes all protected entry files and finds only the intended production instruction file changed. No other game production path, canonical data, frozen ATGB data, experimental PR-EG file, prior test or prior R2 evidence changed. No new persistent structure or gameplay authority. New test fixture errors were corrected within the new test; no host repair followed them.

Documentation: eight reports under development/reports/atgb_r2_04 and a concise docs/NEXT_SESSION.md orientation entry. Evidence and review artifacts use established artifact/handoff directories; development/tmp contains disposable offline capture, qualification and packaging scripts, copied into the review ZIP for reproducibility. Generated stable review exports supersede the prior review export; its preexisting bytes are retained in a local backup. No commit or push.
''',
'04_deterministic_contract_validation.md':'''# 04 — Deterministic Contract Validation

Evidence scope: structural_only; semantic_behavioral_evidence: false. Focused final result: 198 passed, zero failed, one existing Starlette deprecation warning (focused_verified.txt / .xml). This is 180 existing correction/revision/participant cases plus 18 new cases; no HTTP transport is used in this focused lane. No live-model judge, inference or provider admission.

The new tests call interpret_production_turn through the existing R1-07 helper and capture messages at request_interpretation, replacing dispatch with controlled JSON. Twelve parametrized contract checks inspect bounded adjacent clauses in the effective system message, using small groups of concepts rather than equality to an entire paragraph. They cover requested detail, answer support, useful partial evidence, elliptical continuity, rejected alternatives, understood/no-answer, missing-evidence clarification avoidance, competing subjects, independent subject/addressee slots, disclosure authority, mechanical revision and correction semantics. Another case checks effective user-message modes and required communication fields.

Four historical cases pass original R2-03 raw substitutions through current request construction/adaptation and the unchanged host's record reconsideration boundary. One case verifies an unavailable clue ref is still rejected as malformed_communication. Existing R1 tests separately cover supported factual corrections, honest limitations, restricted facts, no-fact acknowledgments, genuine ambiguity, pending-intent protections and direct API delivery with state checks. R2-02 preserves participant grounding and off-scene/mismatched recipient restrictions.

effective_before.json and effective_after.json contain four complete reconstructed requests each and schemas. schema_before.json == schema_after.json exactly. contract_preservation.json records the independent AST comparison proving no other production logic changed. Tests do not assert that a phrase exists somewhere in source and do not score model behavior. Concept checks still necessarily depend on authored wording; they are a deterministic instruction-presence contract, not machine proof of semantic equivalence between arbitrary rewrites.

Limitations: original complete provider requests/preturn state are unavailable; captures use documented reconstructed sessions. No claim of improved live interpretation, original live reproduction repair, benchmark improvement or independent generalization.
''',
'05_historical_compatibility.md':f'''# 05 — Historical Compatibility

Four synthetic_positive_control cases reuse the exact controlled raw substitutions from R2-03 adapter_controls.json. They are not newly sampled interpretations. They pass through current interpret_production_turn, then the existing decision_from_interpretation_record reconsideration used by API ownership. Complete records, preceding exchanges, exact inputs and decisions are in historical_compatibility.json. Original historical failures remain in the prior R2-03 behavioral packet and original traces, unchanged.

| Turn | Controlled subject | Host disposition | Exact host output |
|---|---|---|---|
{compat_lines}

S02 controls set QUESTION / OTHER, no operations, no answer evidence, no clarification text. S02.3 explicitly restores curfew timing; the original stale requested_outcomes/premise strings remain recorded for transparency and are not promoted to authoritative facts. The unchanged adapter may report SAFE_ABSTENTION / clarification_required for zero-operation OTHER; it still preserves a valid record, and host reconsideration returns the honest limitation. This is not described as accepted action execution. No curfew or patrol hour is invented and the generic notice-board category is not emitted as an answer.

S02.4 uses the undiscovered baseline scene; the gated last-seen clue never enters the effective public request. Invalid clue selection is rejected. No automatic investigation is created. The runner's public rumor remains distinct from the posted warning.

S05.3 uses the same minimal active-social runner session as R2-03, with GM/CLARIFICATION, no operations and a runner-versus-board account question. The active NPC remains tavern_runner. An independent existing grounding call resolves tavern_runner contextually with executable addressee eligibility, while the subject remains unresolved; no NPC operation is executed. This tests independent slots, not a schema field for subject ambiguity or newly inferred topic certainty. R2-02's unchanged captured ASK-route tests continue to pass separately.

All four scene/world/session/raw inputs equal deep copies after decision; all decisions require no authoritative execution and have no context_update. No file-backed gameplay store is written by these controls. Original historical complete preturn snapshots are absent: these are controlled minimal-state compatibility experiments, not exact full-session historical replays. They establish host compatibility with appropriate interpretations; they do not establish that the live model will generate those interpretations or preserve authority on future completions. Human review remains pending; no new evaluator judgment or benchmark score.
''',
'06_authority_and_regression.md':f'''# 06 — Authority and Regression

## Completed checks

- Focused production request, evidence, correction, mechanical revision and participant lane: **198 passed** (focused_verified.xml).
- Broader relevant slice: **332 passed, 39 HTTP cases explicitly deselected** (after_nonhttp.xml and http_after_inventory.json).
- The same broader entry slice before editing: **314 passed, the identical 39 cases deselected** (baseline_nonhttp.xml). The added 18 are the new R2-04 tests. No completed-slice failure was excluded to obtain these counts.

Broader source modules: PR-EF-R4 authorization, PR-EB conversational continuity, PR-BR-C16 interaction completion, PR-EA orchestration, PR-BR-C22 commitment, R1-02 revision boundary, R1-07 correction contract, PR-CK ordinary resolver selection, PR-EF-R2 social authority, directed social routing, vocative direct address recovery, PR-BR-C25 semantic ownership and R2-02 participant grounding; after-run also includes R2-04. Exact node inventories and JUnit results are packaged. Existing Starlette TestClient deprecation warning remains.

## Failure / incomplete-execution classification

New product regression: none demonstrated in completed scope. Preexisting product failure reproduced in completed scope: none. Two R2-02 historical failures (C22 raw_chat_stub and directed_social hailing_runner) are recorded as historical known failures, not newly reproduced: both belong to the currently blocked HTTP inventory.

Environment-blocked: pre-change explicit-local-temp attempts with .venv Python 3.12.0 and bundled Python 3.12.14 stalled after 353-item collection before the first TestClient test completed; both were interrupted. The HTTP transport family was explicitly inventoried/deselected by a temporary AST/call-reference and fixture scanner. All 39 omitted node IDs and the selector source are included. This is a limitation, not a passing HTTP result; OS/network/event-loop root cause is undiagnosed. No provider connectivity diagnostic ran.

Indeterminate: the first default-temp interrupted run printed setup errors/failures but never emitted tracebacks, node names or a final summary. Its partial log is retained as baseline_regression.txt and is not counted as a completed result. No unsupported root-cause classification of those individual events is made.

Harness implementation errors: early new-test logs focused.txt and focused_final.txt show incomplete/misapplied synthetic social session fixtures. Corrected to R2-03's per-scenario sessions; intended assertions remained exact. Also the first capture script used the wrong original-log input key and failed before dispatch; corrected to the trace's player_input. Neither required production changes. Raw early logs remain packaged.

No full-suite execution or complete broader HTTP result. Verdict remains conditional for this coverage gap. TestClient is not repaired and unrelated prior product failures are not repaired. regression_summary.json records all categories and limitations.

## Authority

Evidence membership rejects unavailable clue IDs. Public request captures exclude the undiscovered posted route; controlled output selects no hidden passages. Existing authorization/social/participant/correction/revision tests protect NPC knowledge, off-scene recipients, pending/committed intent and unsupported claims within selected cases. Canonical protected data (including world, session, combat, scene, logs and frozen ATGB) is byte-identical to entry; no unauthorized world, combat, simulation time, event or faction mutation occurred. Test fixtures use isolated temp stores or in-memory copies.

{integrity['protected_entry_file_count']:,} protected entry hashes were checked; only the authorized production instruction changed. AST equality outside that literal and exact schema equality prove host, parser, provider, combat/event/faction/time owners and safeguard implementation unchanged. This is instruction compatibility plus deterministic authority evidence under tested inputs; it is not live authority preservation or proof that future model selections will be valid.
''',
'07_prompt_size_and_performance.md':f'''# 07 — Prompt Size and Performance

| Surface | Before characters | After characters | Absolute delta | Percentage delta |
|---|---:|---:|---:|---:|
| Existing appended production instruction | {ch['before']} | {ch['after']} | +{ch['difference']} | +{ch['percentage']:.3f}% |
| Effective system message | 4726 | 5168 | +442 | +9.353% |
{chr(10).join(f"| Full compact request + schema {r['turn_id']} | {r['characters']['before']} | {r['characters']['after']} | +{r['characters']['difference']} | +{r['characters']['percentage']:.3f}% |" for r in sizes['full_requests'])}

Appended instruction chars/4 estimate: **{tok['before']} → {tok['after']} tokens**, +{tok['difference']} (+{tok['percentage']:.3f}%). Full effective request estimates and deltas are in prompt_sizes.json. These are explicitly rough character-based estimates, not measured model tokens or reliable language-specific tokenizer output. tiktoken is unavailable in the local test environment (ModuleNotFoundError); no encoding download, package install or provider call was used. Production's existing conservative UTF-8-bytes/3 + 64 preflight estimate also remains unchanged and is captured per effective request, not mislabeled as measured tokens.

The replacement adds 442 characters / roughly 111 tokens, about 4% of the reconstructed full requests, while replacing existing guidance rather than appending another section. This modest absolute increase preserves the required distinctions and does not add a provider call, response stage, context store or payload field. The existing single interpretation request and host response architecture remain unchanged. No further wording optimization was undertaken after the bounded checks passed.

Actual provider admissions/calls, live inference, retries and connectivity diagnostics in this pass: **zero**. Local request stubs are not provider calls. Expected performance impact is limited to the modest additional input length within the same request; latency/cost/quality impacts are unmeasured and no numerical latency improvement is claimed. No future live-call authority is implied.
''',
'08_final_verdict_and_handoff.md':'''# 08 — Final Verdict and Handoff

**B — Conditional.** Retain the bounded instruction implementation for external review. Effective-request contract distinctions, exact schema preservation, four controlled historical host outcomes, 198 focused tests and the 332-case executable broader slice pass. No new relevant product regression is demonstrated in completed coverage. The broader slice remains incomplete because 39 explicitly listed HTTP TestClient cases could not complete on entry source; this prevents verdict A under the requested regression requirements.

The wording addresses answer-bearing versus related evidence, requested detail, unique conversational continuity, rejected alternatives, unavailable answers and genuine ambiguity. It preserves R1 conversational/mechanical correction handling and R2-02 grounding. One instruction literal and one new test file comprise the production/test delta. Original failures are semantic interpretation failures; wording causality and repair effectiveness remain hypotheses until observed live.

Implementation completion and deterministic host compatibility are supported. Original live reproduction repair, authored-variation model performance, independent held-out generalization, gameplay-benchmark improvement, live authority preservation and broad conversational competence are unproven. A future live validation pass is required before claiming behavioral improvement; no live/provider authority is granted by this handoff. Original complete requests/preturn snapshots remain unavailable. Historical imported judgments remain unchanged and new evidence is not authenticated human review.

Recommended next action: external review of this package, including whether the documented HTTP coverage gap is acceptable for retaining the bounded implementation. Do not implement any next action in this pass. Stop after generating/verifying CURRENT_REVIEW(YYYYMMDD-HHMMSS).zip and await external review.

Explicit confirmations: no schema changes; no parser changes; no new persistent state; no additional provider calls or response-generation stages; no live inference; no provider connectivity diagnostics; no experimental PR-EG integration; frozen ATGB baseline unchanged; no unauthorized gameplay state mutations; no secrets included; no commit or push performed. Protected entry hashes and source-only AST checks support these at the measured deterministic scope, not as a guarantee about future live completions.
'''
}
for name,body in reports.items(): write(REPORT/name,body)
# Orientation update is required by the Constitution, with preexisting content preserved.
orientation=(OUT/'NEXT_SESSION.md.before').read_text(encoding='utf-8')
entry='''## Latest bounded implementation — ATGB-R2-04

2026-10-19: **B — Conditional.** Existing live interpretation system instruction
now distinguishes requested detail/answer-bearing evidence from related topics,
preserves unique follow-up subjects/rejected interpretations, and separates an
unavailable answer from subject ambiguity. Schema/parser/host/gameplay unchanged.
Focused 198 passed; broader non-HTTP 332 passed, 39 explicitly environment-blocked
HTTP cases; matching entry slice 314 passed/39 deselected. Four R2-03 raw controls
retain honest S02 limitations and S05 account clarification with grounded runner.
Instruction +442 characters (~111 chars/4 estimated tokens); no provider calls.
Reports: development/reports/atgb_r2_04/; evidence: artifacts/atgb/atgb_r2_04/;
review: handoff/CURRENT_REVIEW.md and timestamped ZIP. Retain for external review;
live behavioral improvement/authority and complete HTTP regression unproven.
R1-07 acceptance remains pending; R2-02 accepted scope unchanged. No frozen-data
or experimental integration changes; dirty entry tree preserved, no commit/push.
Stop for external review; no next implementation or live trial authorized.

'''
orientation=orientation.replace('Updated 2026-10-19 / ATGB-R2-03.','Updated 2026-10-19 / ATGB-R2-04.',1)
orientation=orientation.replace('## Latest investigation — ATGB-R2-03',entry+'## Latest investigation — ATGB-R2-03',1)
write(ROOT/'docs/NEXT_SESSION.md',orientation)
write(OUT/'orientation.diff',''.join(difflib.unified_diff((OUT/'NEXT_SESSION.md.before').read_text(encoding='utf-8').splitlines(True),orientation.splitlines(True),fromfile='entry/docs/NEXT_SESSION.md',tofile='after/docs/NEXT_SESSION.md')))
(OUT/'repository_status_after.txt').write_bytes(subprocess.check_output(['git','status','--short']))
# Explicit sources only. No env/config secrets, broad repository crawl or previous ZIP payloads.
sources=[p for p in OUT.iterdir() if p.is_file() and p.suffix!='.zip']+list(REPORT.glob('*.md'))
sources += [ROOT/p for p in ['game/live_chat_interpretation.py','tests/test_atgb_r2_04_question_evidence_contract.py','tests/test_atgb_r1_07_correction_contract.py','tests/test_atgb_r1_04_readiness.py','docs/NEXT_SESSION.md','docs/DEVELOPMENT_CONSTITUTION.md','docs/validation_evidence_standard.md','docs/product_realization_validation.md','development/tmp/atgb_r2_04_baseline.py','development/tmp/atgb_r2_04_capture.py','development/tmp/atgb_r2_04_evidence.py','development/tmp/atgb_r2_04_nonhttp.py','development/tmp/atgb_r2_04_package.py','artifacts/atgb/atgb_r2_03/adapter_controls.json','artifacts/atgb/atgb_r2_03/context_and_original_logs.json','artifacts/atgb/atgb_r2_03/historical_trace_excerpts.json','artifacts/atgb/atgb_r2_02/regression_slice.txt']]
sources += [ROOT/r['path'] for r in provenance if r['path'].endswith('.jsonl')]
sources=list(dict.fromkeys(sources))
secret_pattern=re.compile(rb'(?:sk-[A-Za-z0-9_-]{16,}|Bearer\s+[A-Za-z0-9._-]{16,}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)')
assert not [rel(p) for p in sources if secret_pattern.search(p.read_bytes())]
write(OUT/'sensitive_payload_check.json',{'policy':'Explicit local sources only; no credential/config files or dumps; secret-shaped value scan of selected payloads','files_scanned':len(sources),'matches':[],'no_secrets_included':True})
if OUT/'sensitive_payload_check.json' not in sources:
    sources.append(OUT/'sensitive_payload_check.json')
config={'campaign_id':'atgb_r2_04','campaign_name':'ATGB-R2-04 — Question-to-Evidence Interpretation Contract Repair','campaign_date':'2026-10-19',
 'purpose':'External review of bounded existing instruction replacement; no live-provider authority',
 'executive_summary':'B — Conditional. Instruction and deterministic host compatibility pass; 39 explicitly blocked HTTP tests leave a regression coverage gap. 198 focused / 332 broader non-HTTP passed. No live inference or behavioral improvement claim. Historical evidence packet below is R2-03 provenance, not a new R2-04 performance result.',
 'objective_status':'B — Conditional','primary_report':rel(REPORT/'08_final_verdict_and_handoff.md'),
 'evidence_packets':['artifacts/validation_evidence/atgb_r2_03'],
 'supporting_files':[{'path':rel(p),'role':'report' if p.parent==REPORT else 'qualification_evidence','why':'Explicit source/test, baseline, captured request, deterministic compatibility or validation evidence needed for external review.'} for p in sources if p!=REPORT/'08_final_verdict_and_handoff.md'],
 'changes':{'production':['One existing system instruction literal in game/live_chat_interpretation.py.'],'validation':['18 new tests of effective request and R2-03 controlled host inputs.'],'tooling':['Disposable offline scripts packaged as reproducibility evidence; no runtime/tool owner changes.'],'documentation':['Eight reports and concise canonical session orientation.'],'generated_artifacts':['Captured requests/schema, source diff, compatibility/authority, size and regression evidence.']},
 'testing':{'focused':'198 passed; no HTTP transport.','broader':'332 passed, 39 explicitly deselected HTTP cases; entry comparison 314/39.','full_suite':'Not run; full broader HTTP attempts interrupted before completion.',
 'runtime_validation':'Four controlled substitutions pass current adapter + unchanged host record reconsideration, all in memory; original semantic failures remain historical.',
 'model_runtime_boundary':'Offline only. Provider dispatch replaced; network forbidden in captures/controls; pytest live-model guard active. No live inference or connectivity diagnostic.',
 'new_regressions':'None demonstrated in completed scope; HTTP result unknown.','pre_existing_failures':'No failed case in completed entry slice; two historically known HTTP failures not reproduced in current environment. Initial partial error/failure log remains indeterminate.'},
 'decisions_requiring_human_review':['Review bounded wording and whether HTTP coverage gap permits retention; no next action or provider trial executed.'],
 'known_problems':{'campaign_specific':['39 HTTP tests could not complete on entry; B verdict.', 'No new model selection/repair-effect result.'],'pre_existing':['Semantic failures retained in original ATGB logs; R1-07 live acceptance pending.']},
 'missing_concepts':['No new architecture requirement established.'],
 'does_not_prove':['Improved live evidence selection or subject continuity.','Live authority preservation, broad conversational competence, benchmark or independent generalization.','Complete HTTP or full-suite regression.'],
 'recommended_next_step':'External review of this ZIP and HTTP coverage limitation; stop before further implementation or live work.',
 'self_contained_review_test':'All eight reports, exact instruction before/after, working-entry diff, source/test snapshots, requests/schema, exact host controls, XML/logs and excluded node inventory are included; ZIP hashes verified after construction.',
 'configuration_source':'artifacts/atgb/atgb_r2_04/review_config.json'}
write(OUT/'review_config.json',config)
# Preserve superseded review exports without packaging previous review ZIPs.
backup=ROOT/'development/tmp/atgb_r2_04_prior_handoff'; backup.mkdir(exist_ok=True)
for name in ['CURRENT_REVIEW.md','CURRENT_REVIEW.zip','REVIEW_MANIFEST.json']:
    if (ROOT/'handoff'/name).exists() and not (backup/name).exists(): shutil.copyfile(ROOT/'handoff'/name,backup/name)
from tools.build_review_handoff import build_handoff
try:
    now=datetime.now(ZoneInfo('America/New_York'))
except Exception:
    # Client date is 2026-10-19 in New York (EDT); local tzdata is absent.
    now=datetime.now(timezone(timedelta(hours=-4)))
result=build_handoff(config,root=ROOT,output_dir=ROOT/'handoff',generated_at=now.isoformat(),archive_history=True)
assert all('duplicate content of' in row['reason'] for row in result['omitted']),result['omitted']
zip_path=ROOT/'handoff'/f'CURRENT_REVIEW({now:%Y%m%d-%H%M%S}).zip'
shutil.copyfile(ROOT/'handoff/CURRENT_REVIEW.zip',zip_path)
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None
    manifest=json.loads(z.read('REVIEW_MANIFEST.json'))
    for row in manifest['included_files']:
        if row.get('sha256'):
            assert hashlib.sha256(z.read(row['bundle_path'])).hexdigest()==row['sha256']
    assert len([n for n in z.namelist() if '/development/reports/atgb_r2_04/' in n])==8
print(json.dumps({'verdict':'B — Conditional','zip':str(zip_path),'files':result['file_count'],'bytes':result['zip_size_bytes'],'omitted':result['omitted'],'zip_sha256':sha(zip_path),'verification':'CRC, included hashes and eight reports verified'},indent=2,ensure_ascii=False))
