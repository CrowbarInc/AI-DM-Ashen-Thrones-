import ast, hashlib, json, subprocess
from pathlib import Path
ROOT = Path.cwd()
OUT = ROOT / 'artifacts/atgb/atgb_r2_04'
OUT.mkdir(parents=True, exist_ok=True)
def save(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2)+'\n', encoding='utf-8')
paths = []
for folder in ['game', 'data', 'experiments', 'tests', 'static', 'tools/atgb', 'artifacts/atgb/atgb_r2_01', 'artifacts/atgb/atgb_r2_02', 'artifacts/atgb/atgb_r2_03']:
    paths.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts)
save('entry_hashes.json', {p.relative_to(ROOT).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in paths})
for path in ['game/live_chat_interpretation.py', 'docs/NEXT_SESSION.md']:
    (OUT/(Path(path).name+'.before')).write_bytes((ROOT/path).read_bytes())
(OUT/'repository_status_before.txt').write_bytes(subprocess.check_output(['git','status','--short']))
save('baseline.json', {'head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(), 'branch':subprocess.check_output(['git','branch','--show-current'],text=True).strip(), 'support_handoff_exists':False})
tree=ast.parse((ROOT/'game/live_chat_interpretation.py').read_text(encoding='utf-8'))
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='interpret_production_turn')
instruction=next(n.value.value for n in ast.walk(fn) if isinstance(n,ast.AugAssign) and isinstance(n.value,ast.Constant) and isinstance(n.value.value,str) and 'Establish communication.recipient' in n.value.value)
(OUT/'instruction_before.txt').write_text(instruction,encoding='utf-8')
print('Entry snapshots and protected hashes recorded')
