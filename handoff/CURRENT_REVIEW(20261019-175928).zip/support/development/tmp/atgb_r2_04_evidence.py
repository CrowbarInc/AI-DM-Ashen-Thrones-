"""Offline qualification evidence; every provider boundary is substituted."""
import ast, copy, difflib, hashlib, json, os, sys
from pathlib import Path
from unittest.mock import patch
ROOT=Path.cwd(); sys.path.insert(0,str(ROOT))
OUT=ROOT/'artifacts/atgb/atgb_r2_04'
os.environ['ASHEN_DISABLE_PROVIDER_CALLS']='1'
os.environ['ASHEN_DISABLE_LIVE_INTERPRETATION']='1'
def save(name,obj):
    (OUT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
from game import live_chat_interpretation as live
from game.conversational_orchestration import decision_from_interpretation_record
from game.ordinary_semantic_ownership import assess_addressee_grounding
before=json.loads((OUT/'effective_before.json').read_text(encoding='utf-8'))
after=json.loads((OUT/'effective_after.json').read_text(encoding='utf-8'))
assert len(before)==len(after)==4
assert all(a['schema']==b['schema'] for a,b in zip(before,after))
old=(OUT/'live_chat_interpretation.py.before').read_text(encoding='utf-8')
new=(ROOT/'game/live_chat_interpretation.py').read_text(encoding='utf-8')
def instruction(tree):
    return next(n for n in ast.walk(tree) if isinstance(n,ast.AugAssign) and isinstance(n.value,ast.Constant) and isinstance(n.value.value,str) and 'Establish communication.recipient' in n.value.value)
trees=[ast.parse(s) for s in [old,new]]
texts=[instruction(t).value.value for t in trees]
(OUT/'instruction_after.txt').write_text(texts[1],encoding='utf-8')
for t in trees:
    instruction(t).value=ast.Constant(value='instruction-only delta')
assert ast.dump(trees[0])==ast.dump(trees[1])
save('contract_preservation.json',{'schema_exactly_equal':True,'all_other_production_AST_equal':True,'schema_sha256':hashlib.sha256(json.dumps(before[0]['schema'],sort_keys=True).encode()).hexdigest(),'production_delta':'one existing system instruction string only','parser_validation_enums_modes_unchanged':True})
diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='entry/game/live_chat_interpretation.py',tofile='after/game/live_chat_interpretation.py'))
test_path='tests/test_atgb_r2_04_question_evidence_contract.py'
diff+=''.join(difflib.unified_diff([], (ROOT/test_path).read_text(encoding='utf-8').splitlines(True),fromfile='/dev/null',tofile=test_path))
(OUT/'source.diff').write_text(diff,encoding='utf-8')
encoding=None; tokenizer_reason=None
with patch('socket.socket',side_effect=AssertionError('network forbidden')):
    try:
        import tiktoken
        encoding=tiktoken.get_encoding('o200k_base')
    except Exception as error:
        tokenizer_reason=type(error).__name__+': local encoding unavailable without network'
def measure(a,b):
    def metric(x,y):
        return {'before':x,'after':y,'difference':y-x,'percentage':round((y-x)*100/x,4)}
    result={'characters':metric(len(a),len(b))}
    if encoding:
        result['local_tokens']=metric(len(encoding.encode(a)),len(encoding.encode(b)))
    else:
        result['estimated_tokens_chars_div_4']=metric(round(len(a)/4),round(len(b)/4))
    return result
size={'instruction':measure(*texts),'effective_system':measure(before[0]['messages'][0]['content'],after[0]['messages'][0]['content']),
      'tokenizer': 'o200k_base (local proxy, not a provider measurement)' if encoding else 'unavailable; chars/4 estimates only', 'tokenizer_limitation':tokenizer_reason,
      'request_count':0,'new_stages':0,'latency':'not measured; no added round trip; modest input size delta only','full_requests':[]}
for a,b in zip(before,after):
    size['full_requests'].append({'turn_id':a['turn_id'],**measure(json.dumps({'messages':a['messages'],'schema':a['schema']},ensure_ascii=False,separators=(',',':')),json.dumps({'messages':b['messages'],'schema':b['schema']},ensure_ascii=False,separators=(',',':')))})
save('prompt_sizes.json',size)
H=ROOT/'artifacts/atgb/atgb_r2_03'
controls=json.loads((H/'adapter_controls.json').read_text(encoding='utf-8'))
traces=json.loads((H/'historical_trace_excerpts.json').read_text(encoding='utf-8'))
contexts=json.loads((H/'context_and_original_logs.json').read_text(encoding='utf-8'))
baseline=ROOT/'data/validation/atgb/baselines/frontier-gate-v1'
scene=json.loads((baseline/'scenes/frontier_gate.json').read_text()); world=json.loads((baseline/'world.json').read_text())
results=[]
with patch('socket.socket',side_effect=AssertionError('network forbidden')):
    for row in controls:
        trace=next(r for r in traces if r['turn_id']==row['turn_id'])
        context=next(r for r in contexts if r['turn_id']==row['turn_id'])
        session={'active_scene_id':'frontier_gate'}
        if row['turn_id']=='S05.3':
            session.update(turn_counter=2,clocks={'suspicion':0,'unrest':0,'danger':0},interaction_context={'active_interaction_target_id':'tavern_runner','active_interaction_kind':'social','interaction_mode':'social','engagement_level':'engaged'})
        original=copy.deepcopy((scene,world,session,row['exact_substituted_raw']))
        def wire(messages,**kwargs):
            return {'ok':True,'sent':False,'text':json.dumps(row['exact_substituted_raw'])}
        with patch.object(live,'production_live_interpretation_enabled',return_value=True),patch.object(live,'request_interpretation',side_effect=wire):
            result=live.interpret_production_turn(player_text=trace['player_input'],mode='AUTO',scene=scene,world=world,session=session,log=context['preceding_log'])
        decision=decision_from_interpretation_record(result['record'],player_text=trace['player_input'],scene=scene,world=world,session=session).to_public_dict()
        assert decision['category']==row['reconsidered_host_decision']['category']
        assert decision['player_facing_text']==row['reconsidered_host_decision']['player_facing_text']
        unchanged=original==(scene,world,session,row['exact_substituted_raw']); assert unchanged
        results.append({'turn_id':row['turn_id'],'classification':'synthetic_positive_control based on R2-03 controlled substitutions; minimal reconstructed session, not full historical replay','player_input':trace['player_input'],'preceding_context':trace['preceding_conversation'],'exact_substituted_raw':row['exact_substituted_raw'],'adapter_status':result['status'],'adapter_reason':result['reason'],'adapted_record':result['record'],'host_decision':decision,'inputs_unchanged':unchanged})
        if row['turn_id']=='S05.3':
            results[-1]['independent_addressee_grounding']=assess_addressee_grounding(trace['player_input'],scene=scene,world=world,session=session,proposed_target_id='tavern_runner')
save('historical_compatibility.json',results)
entry=json.loads((OUT/'entry_hashes.json').read_text())
changed=[p for p,h in entry.items() if not (ROOT/p).is_file() or hashlib.sha256((ROOT/p).read_bytes()).hexdigest()!=h]
save('integrity.json',{'protected_entry_file_count':len(entry),'changed':changed,'expected_changes':['game/live_chat_interpretation.py'],'frozen_atgb_unchanged':not any(p.startswith('data/validation/atgb/') for p in changed),'canonical_data_unchanged':not any(p.startswith('data/') for p in changed),'experiments_unchanged':not any(p.startswith('experiments/') for p in changed),'prior_atgb_evidence_unchanged':not any(p.startswith('artifacts/atgb/') for p in changed),'all_other_production_unchanged':changed==['game/live_chat_interpretation.py']})
assert changed==['game/live_chat_interpretation.py'],changed
print(json.dumps({'size':size['instruction'],'tokenizer':size['tokenizer'],'historical_controls':len(results),'changed':changed},indent=2))
