# Campaign

Campaign: PR-PLAY-09 — Automated Five-Turn Gameplay Smoke Test
Identifier: `pr_play_09`
Date: 2026-10-30
Generated: 2026-10-30T19:03:08.137369+00:00
Purpose: Offline bounded harness extension; stop before live execution.

# Executive Summary

33 gameplay instrument checks pass. 586 passing checks and six matching pre-existing failures across relevant lanes. Synthetic HTTP example completes four turns within six requests; fifth skipped. No live calls or production changes.

Objective status: `B — Conditionally ready; six-request diagnostic may stop before five turns`.

# Changes Made

## Production changes

- No changes in this category.

## Validation changes

- G1–G25 controls, coverage registry and bounded regression lanes.

## Tooling changes

- Existing runner/worker extended with bounded five-action scenario, native evidence evaluation and transcript export.

## Documentation changes

- Nine reports, guide and current session handoff.

## Generated artifacts

- Selected transcripts, JUnit/logs, source diff/status and protected hashes.

# What Was Tested

- **Focused tests:** 33 gameplay and 35 prior harness/registry checks passed.
- **Broader relevant tests:** 586 passed / six matching pre-existing failures; no timeout or error.
- **Full suite:** Not run.
- **Runtime validation:** Owned localhost HTTP and production pipeline, synthetic SDK and external socket denial.
- **Model/runtime boundary:** Zero live provider/connectivity operations.
- **New regressions:** None demonstrated in completed scope.
- **Pre-existing failures:** Three rich-opening, one stew-price conversation and two stale source-attestation assertions.
- **Self-contained bundle review:** Nine reports, scenario/source/diff, G1–G25/JUnit/regression evidence, complete selected synthetic HTTP example, feasibility and future command.

# Behavioral Evidence

No standardized behavioral evidence packet was supplied.

# Decisions Requiring Human Review

- External review of conditional readiness and six-request feasibility before any separately authorized Live invocation.

# Known Problems / Unresolved Findings

## Campaign-specific

- No end-to-end successful five-turn execution under six requests demonstrated; G1 is evaluator-only. Narrative quality and complete authority need human review.

## Pre-existing baseline

- Six baseline failures; stale ATGB source attestations are not rewritten.

# Missing Concepts / Future Capabilities

- None recorded.

# What This Campaign Does NOT Prove

- Live meaningful five-turn play, rendered UI, conversational competence, independent generalization or ATGB performance.

# Recommended Next Step

External review only; do not execute the future Live command in this pass.

# Review Bundle Contents

Bundle file count: `113`
Bundle ZIP size: `000001494827` bytes
Size warning threshold: `20971520` bytes
Size status: `WITHIN_THRESHOLD`

- `CURRENT_REVIEW.md`: generated orientation and decision surface.
- `REVIEW_MANIFEST.json`: generated provenance, inclusion, omission, and size record.
- `support/development/campaigns/product_realization/pr_play_09/09_FINAL_VERDICT_AND_HANDOFF.md`: Primary campaign standard/report used to orient the review. Canonical source: `development/campaigns/product_realization/pr_play_09/09_FINAL_VERDICT_AND_HANDOFF.md`.
- `support/tools/playtest/runner.py`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `tools/playtest/runner.py`.
- `support/tools/playtest/worker.py`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `tools/playtest/worker.py`.
- `support/tools/playtest/gameplay.py`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `tools/playtest/gameplay.py`.
- `support/tools/playtest/scenarios/FiveTurnGameplay.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `tools/playtest/scenarios/FiveTurnGameplay.json`.
- `support/scripts/run_live_playtest.ps1`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `scripts/run_live_playtest.ps1`.
- `support/tests/test_five_turn_gameplay.py`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `tests/test_five_turn_gameplay.py`.
- `support/tests/validation_coverage_registry.py`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `tests/validation_coverage_registry.py`.
- `support/tools/validate_pr_play_09.py`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `tools/validate_pr_play_09.py`.
- `support/tools/report_pr_play_09.py`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `tools/report_pr_play_09.py`.
- `support/docs/AUTOMATED_PLAYTEST_GUIDE.md`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `docs/AUTOMATED_PLAYTEST_GUIDE.md`.
- `support/docs/NEXT_SESSION.md`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `docs/NEXT_SESSION.md`.
- `support/development/campaigns/product_realization/pr_play_09/01_BASELINE_AND_EXISTING_HARNESS.md`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `development/campaigns/product_realization/pr_play_09/01_BASELINE_AND_EXISTING_HARNESS.md`.
- `support/development/campaigns/product_realization/pr_play_09/02_SCENARIO_DESIGN.md`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `development/campaigns/product_realization/pr_play_09/02_SCENARIO_DESIGN.md`.
- `support/development/campaigns/product_realization/pr_play_09/03_HARNESS_IMPLEMENTATION.md`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `development/campaigns/product_realization/pr_play_09/03_HARNESS_IMPLEMENTATION.md`.
- `support/development/campaigns/product_realization/pr_play_09/04_MECHANICAL_EVALUATION.md`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `development/campaigns/product_realization/pr_play_09/04_MECHANICAL_EVALUATION.md`.
- `support/development/campaigns/product_realization/pr_play_09/05_NARRATIVE_QUALITY_EVALUATION.md`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `development/campaigns/product_realization/pr_play_09/05_NARRATIVE_QUALITY_EVALUATION.md`.
- `support/development/campaigns/product_realization/pr_play_09/06_PROVIDER_SAFETY_AND_PERFORMANCE.md`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `development/campaigns/product_realization/pr_play_09/06_PROVIDER_SAFETY_AND_PERFORMANCE.md`.
- `support/development/campaigns/product_realization/pr_play_09/07_DETERMINISTIC_VALIDATION.md`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `development/campaigns/product_realization/pr_play_09/07_DETERMINISTIC_VALIDATION.md`.
- `support/development/campaigns/product_realization/pr_play_09/08_LIVE_TEST_READINESS.md`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `development/campaigns/product_realization/pr_play_09/08_LIVE_TEST_READINESS.md`.
- `support/artifacts/pr_play_09/conversation_regression.txt`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/conversation_regression.txt`.
- `support/artifacts/pr_play_09/conversation_regression.xml`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/conversation_regression.xml`.
- `support/artifacts/pr_play_09/diagnostics_regression.txt`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/diagnostics_regression.txt`.
- `support/artifacts/pr_play_09/diagnostics_regression.xml`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/diagnostics_regression.xml`.
- `support/artifacts/pr_play_09/entry_status.txt`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/entry_status.txt`.
- `support/artifacts/pr_play_09/entry_to_exit_integrity.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/entry_to_exit_integrity.json`.
- `support/artifacts/pr_play_09/example_run.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/example_run.json`.
- `support/artifacts/pr_play_09/exit_status.txt`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/exit_status.txt`.
- `support/artifacts/pr_play_09/export_atgb_regression.txt`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/export_atgb_regression.txt`.
- `support/artifacts/pr_play_09/export_atgb_regression.xml`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/export_atgb_regression.xml`.
- `support/artifacts/pr_play_09/G1_G25_results.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/G1_G25_results.json`.
- `support/artifacts/pr_play_09/gameplay.xml`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/gameplay.xml`.
- `support/artifacts/pr_play_09/gameplay_regression.txt`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/gameplay_regression.txt`.
- `support/artifacts/pr_play_09/gameplay_regression.xml`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/gameplay_regression.xml`.
- `support/artifacts/pr_play_09/harness_regression.txt`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/harness_regression.txt`.
- `support/artifacts/pr_play_09/harness_regression.xml`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/harness_regression.xml`.
- `support/artifacts/pr_play_09/historical_opening_summary.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/historical_opening_summary.json`.
- `support/artifacts/pr_play_09/live_execution_instructions.md`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/live_execution_instructions.md`.
- `support/artifacts/pr_play_09/opening_regression.txt`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/opening_regression.txt`.
- `support/artifacts/pr_play_09/opening_regression.xml`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/opening_regression.xml`.
- `support/artifacts/pr_play_09/protected_before.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/protected_before.json`.
- `support/artifacts/pr_play_09/protected_integrity.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/protected_integrity.json`.
- `support/artifacts/pr_play_09/provider_budget_feasibility.md`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/provider_budget_feasibility.md`.
- `support/artifacts/pr_play_09/provider_regression.txt`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/provider_regression.txt`.
- `support/artifacts/pr_play_09/provider_regression.xml`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/provider_regression.xml`.
- `support/artifacts/pr_play_09/regression_runs.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/regression_runs.json`.
- `support/artifacts/pr_play_09/revision.txt`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/revision.txt`.
- `support/artifacts/pr_play_09/rules_persistence_regression.txt`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/rules_persistence_regression.txt`.
- `support/artifacts/pr_play_09/rules_persistence_regression.xml`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/rules_persistence_regression.xml`.
- `support/artifacts/pr_play_09/source_diff.patch`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/source_diff.patch`.
- `support/artifacts/pr_play_09/structured_regression.txt`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/structured_regression.txt`.
- `support/artifacts/pr_play_09/structured_regression.xml`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/structured_regression.xml`.
- `support/artifacts/pr_play_09/test_summary.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/test_summary.json`.
- `support/artifacts/pr_play_09/validation_protected_before.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/validation_protected_before.json`.
- `support/artifacts/pr_play_09/world_regression.txt`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/world_regression.txt`.
- `support/artifacts/pr_play_09/world_regression.xml`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/world_regression.xml`.
- `support/artifacts/pr_play_09/example/GAMEPLAY_REPORT.md`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/example/GAMEPLAY_REPORT.md`.
- `support/artifacts/pr_play_09/example/result.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/example/result.json`.
- `support/artifacts/pr_play_09/example/SUMMARY.md`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/pr_play_09/example/SUMMARY.md`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/configuration/run.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/configuration/run.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/api_state.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/api_state.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/documents.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/documents.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/campaign.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/campaign.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/character.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/character.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/combat.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/combat.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/conditions.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/conditions.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/session.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/session.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/session_log.jsonl`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/session_log.jsonl`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/world.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/world.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/frontier_gate.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/frontier_gate.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/market_quarter.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/market_quarter.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/old_milestone.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/old_milestone.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/api_state.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/api_state.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/documents.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/documents.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/combat.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/combat.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/session.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/session.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/session_log.jsonl`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/session_log.jsonl`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/world.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/world.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/api_state.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/api_state.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/documents.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/documents.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/persistent/combat.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/persistent/combat.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/persistent/session.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/persistent/session.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/persistent/session_log.jsonl`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/persistent/session_log.jsonl`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/persistent/world.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/persistent/world.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/api_response.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/api_response.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/evaluation.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/evaluation.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/api_response.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/api_response.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/evaluation.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/evaluation.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/api_response.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/api_response.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/evaluation.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/evaluation.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/api_response.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/api_response.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/evaluation.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/evaluation.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/after/api_state.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/after/api_state.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/after/documents.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/after/documents.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/after/persistent/session.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/after/persistent/session.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/after/persistent/session_log.jsonl`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/after/persistent/session_log.jsonl`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/after/api_state.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/after/api_state.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/after/documents.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/after/documents.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/after/persistent/session.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/after/persistent/session.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/after/persistent/session_log.jsonl`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/after/persistent/session_log.jsonl`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/after/api_state.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/after/api_state.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/after/documents.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/after/documents.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/after/persistent/session.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/after/persistent/session.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/after/persistent/session_log.jsonl`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/after/persistent/session_log.jsonl`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/diagnostics/9ab0ce46869a4ce4abc393505cf6da96-1.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/diagnostics/9ab0ce46869a4ce4abc393505cf6da96-1.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/diagnostics/application.log`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/diagnostics/application.log`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/diagnostics/budget_snapshot.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/diagnostics/budget_snapshot.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/diagnostics/execution_log.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/diagnostics/execution_log.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/diagnostics/provider_usage.jsonl`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/diagnostics/provider_usage.jsonl`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/diagnostics/ready.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/diagnostics/ready.json`.
- `support/artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/evidence/manifest.json`: Explicit PR-PLAY-09 source, report, provenance or deterministic evidence. Canonical source: `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/evidence/manifest.json`.

## Explicit omissions

- `artifacts/pr_play_09/source_snapshots/tools/playtest/runner.py`: duplicate content of tools/playtest/runner.py; canonical reference retained
- `artifacts/pr_play_09/source_snapshots/tools/playtest/worker.py`: duplicate content of tools/playtest/worker.py; canonical reference retained
- `artifacts/pr_play_09/source_snapshots/tools/playtest/gameplay.py`: duplicate content of tools/playtest/gameplay.py; canonical reference retained
- `artifacts/pr_play_09/source_snapshots/tools/playtest/scenarios/FiveTurnGameplay.json`: duplicate content of tools/playtest/scenarios/FiveTurnGameplay.json; canonical reference retained
- `artifacts/pr_play_09/source_snapshots/scripts/run_live_playtest.ps1`: duplicate content of scripts/run_live_playtest.ps1; canonical reference retained
- `artifacts/pr_play_09/source_snapshots/tests/test_five_turn_gameplay.py`: duplicate content of tests/test_five_turn_gameplay.py; canonical reference retained
- `artifacts/pr_play_09/source_snapshots/tests/validation_coverage_registry.py`: duplicate content of tests/validation_coverage_registry.py; canonical reference retained
- `artifacts/pr_play_09/source_snapshots/tools/validate_pr_play_09.py`: duplicate content of tools/validate_pr_play_09.py; canonical reference retained
- `artifacts/pr_play_09/source_snapshots/tools/report_pr_play_09.py`: duplicate content of tools/report_pr_play_09.py; canonical reference retained
- `artifacts/pr_play_09/source_snapshots/docs/AUTOMATED_PLAYTEST_GUIDE.md`: duplicate content of docs/AUTOMATED_PLAYTEST_GUIDE.md; canonical reference retained
- `artifacts/pr_play_09/source_snapshots/docs/NEXT_SESSION.md`: duplicate content of docs/NEXT_SESSION.md; canonical reference retained
- `development/campaigns/product_realization/pr_play_09/09_FINAL_VERDICT_AND_HANDOFF.md`: duplicate content of development/campaigns/product_realization/pr_play_09/09_FINAL_VERDICT_AND_HANDOFF.md; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/configuration/scenario.json`: duplicate content of tools/playtest/scenarios/FiveTurnGameplay.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/campaign.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/campaign.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/character.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/character.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/conditions.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/conditions.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/scenes/frontier_gate.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/frontier_gate.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/scenes/market_quarter.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/market_quarter.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/scenes/old_milestone.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/old_milestone.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/persistent/campaign.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/campaign.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/persistent/character.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/character.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/persistent/conditions.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/conditions.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/persistent/scenes/frontier_gate.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/frontier_gate.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/persistent/scenes/market_quarter.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/market_quarter.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/persistent/scenes/old_milestone.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/old_milestone.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/before/api_state.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/api_state.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/before/documents.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/documents.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/after/persistent/campaign.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/campaign.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/after/persistent/character.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/character.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/after/persistent/combat.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/combat.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/after/persistent/conditions.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/conditions.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/after/persistent/world.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/world.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/after/persistent/scenes/frontier_gate.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/frontier_gate.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/after/persistent/scenes/market_quarter.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/market_quarter.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/after/persistent/scenes/old_milestone.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/old_milestone.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/before/persistent/campaign.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/campaign.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/before/persistent/character.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/character.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/before/persistent/combat.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/combat.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/before/persistent/conditions.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/conditions.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/before/persistent/session.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/session.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/before/persistent/session_log.jsonl`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/session_log.jsonl; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/before/persistent/world.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/world.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/before/persistent/scenes/frontier_gate.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/frontier_gate.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/before/persistent/scenes/market_quarter.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/market_quarter.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/before/persistent/scenes/old_milestone.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/old_milestone.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/before/api_state.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/after/api_state.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/before/documents.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/after/documents.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/after/persistent/campaign.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/campaign.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/after/persistent/character.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/character.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/after/persistent/combat.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/combat.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/after/persistent/conditions.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/conditions.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/after/persistent/world.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/world.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/after/persistent/scenes/frontier_gate.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/frontier_gate.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/after/persistent/scenes/market_quarter.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/market_quarter.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/after/persistent/scenes/old_milestone.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/old_milestone.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/before/persistent/campaign.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/campaign.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/before/persistent/character.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/character.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/before/persistent/combat.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/combat.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/before/persistent/conditions.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/conditions.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/before/persistent/session.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/after/persistent/session.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/before/persistent/session_log.jsonl`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T1/after/persistent/session_log.jsonl; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/before/persistent/world.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/world.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/before/persistent/scenes/frontier_gate.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/frontier_gate.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/before/persistent/scenes/market_quarter.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/market_quarter.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/before/persistent/scenes/old_milestone.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/old_milestone.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/before/api_state.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/after/api_state.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/before/documents.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/after/documents.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/after/persistent/campaign.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/campaign.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/after/persistent/character.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/character.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/after/persistent/combat.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/persistent/combat.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/after/persistent/conditions.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/conditions.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/after/persistent/world.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/persistent/world.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/after/persistent/scenes/frontier_gate.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/frontier_gate.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/after/persistent/scenes/market_quarter.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/market_quarter.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/after/persistent/scenes/old_milestone.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/old_milestone.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/before/persistent/campaign.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/campaign.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/before/persistent/character.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/character.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/before/persistent/combat.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/combat.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/before/persistent/conditions.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/conditions.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/before/persistent/session.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/after/persistent/session.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/before/persistent/session_log.jsonl`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T2/after/persistent/session_log.jsonl; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/before/persistent/world.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/opening/persistent/world.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/before/persistent/scenes/frontier_gate.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/frontier_gate.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/before/persistent/scenes/market_quarter.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/market_quarter.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/before/persistent/scenes/old_milestone.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/old_milestone.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/after/api_state.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/api_state.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/after/documents.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/documents.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/before/api_state.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/after/api_state.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/before/documents.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/after/documents.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/after/persistent/campaign.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/campaign.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/after/persistent/character.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/character.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/after/persistent/combat.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/persistent/combat.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/after/persistent/conditions.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/conditions.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/after/persistent/session.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/persistent/session.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/after/persistent/session_log.jsonl`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/persistent/session_log.jsonl; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/after/persistent/world.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/persistent/world.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/after/persistent/scenes/frontier_gate.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/frontier_gate.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/after/persistent/scenes/market_quarter.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/market_quarter.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/after/persistent/scenes/old_milestone.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/old_milestone.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/before/persistent/campaign.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/campaign.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/before/persistent/character.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/character.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/before/persistent/combat.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/persistent/combat.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/before/persistent/conditions.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/conditions.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/before/persistent/session.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/after/persistent/session.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/before/persistent/session_log.jsonl`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T3/after/persistent/session_log.jsonl; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/before/persistent/world.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/after/persistent/world.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/before/persistent/scenes/frontier_gate.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/frontier_gate.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/before/persistent/scenes/market_quarter.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/market_quarter.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/turns/T4/before/persistent/scenes/old_milestone.json`: duplicate content of artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/baseline/persistent/scenes/old_milestone.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/reports/GAMEPLAY_REPORT.md`: duplicate content of artifacts/pr_play_09/example/GAMEPLAY_REPORT.md; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/reports/result.json`: duplicate content of artifacts/pr_play_09/example/result.json; canonical reference retained
- `artifacts/atgb/automated_playtests/20261030T190153Z-94326faa32f3/reports/SUMMARY.md`: duplicate content of artifacts/pr_play_09/example/SUMMARY.md; canonical reference retained

The bundle intentionally excludes repository copies, dependency/cache directories, previous handoffs, unrelated artifacts, and sensitive configuration.
Canonical repository files remain authoritative; packaged copies are review conveniences with hashes and source paths.
