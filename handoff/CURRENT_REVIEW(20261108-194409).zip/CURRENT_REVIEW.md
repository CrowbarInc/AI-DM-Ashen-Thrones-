# Campaign

Campaign: PR-PLAY Adjacent Regression Reconciliation — Verified Recovery
Identifier: `pr_play_adjacent_regression`
Date: 2026-11-08
Generated: 2026-11-09T00:43:05.685802+00:00
Purpose: Recover handoff integrity and individually investigate twelve adjacent HTTP failures.

# Executive Summary

Audit A/PASS; previous repair B — Conditional acceptance. Same 176 adjacent tests: 164 passed, 12 failed, zero errors/skips; seven focused controls pass. Classifications A=0/B=0/C=9/D=0/E=3. Nine obsolete public-resolution assertions are grounded in PR-PLAY-67; three prose defects have unresolved origin. Local stable ZIP was the prior repair package while Markdown/manifest had advanced. New archive independently verified. No production/test changes, live provider calls, or campaign openings.

Objective status: `A/PASS`.

# Changes Made

## Production changes

- No changes in this category.

## Validation changes

- Unchanged tests; fresh isolated evidence only.

## Tooling changes

- No changes in this category.

## Documentation changes

- Eight recovery reports; prepended NEXT_SESSION preserving historical entries.

## Generated artifacts

- Fresh evidence and coherent standard review bundle; historical reports preserved.

# What Was Tested

- **Focused tests:** 7 passed; T04/T05/T06/T09 and negative controls.
- **Broader relevant tests:** 176 tests: 164 passed, same 12 failures, zero errors/skips. C=9/E=3.
- **Full suite:** Not run.
- **Runtime validation:** In-process provider-free TestClient; synthetic already-started sessions only.
- **Model/runtime boundary:** Live provider calls 0. No external network attempts in valid run.
- **New regressions:** None confirmed; three origins unresolved.
- **Pre-existing failures:** No B classifications claimed without exact baseline. Nine C assertions conflict with PR-PLAY-67.
- **Self-contained bundle review:** Exact new ZIP opened after generation; reports, 12-row matrix, canonical hashes and both handoffs verified; external seal record retained.

# Behavioral Evidence

No standardized behavioral evidence packet was supplied.

# Decisions Requiring Human Review

- Conditional repair acceptance; authenticate baseline/provenance before full acceptance.

# Known Problems / Unresolved Findings

## Campaign-specific

- T05 clue plus stock sentence remains.

## Pre-existing baseline

- Dirty worktree; exact pre-repair baseline absent. Three publication defects have unresolved origin.

# Missing Concepts / Future Capabilities

- Authenticated exact pre-repair dirty source snapshot.

# What This Campaign Does NOT Prove

- No broad playability, independent holdout, live-model evaluation or Gameplay Benchmark.
- Historical origin of three prose defects remains unresolved. No authorization for a new repair cycle.

# Recommended Next Step

Option C — Baseline-integrity correction. Stop here; defer T05 repair.

# Review Bundle Contents

Bundle file count: `40`
Bundle ZIP size: `000004654662` bytes
Size warning threshold: `20971520` bytes
Size status: `WITHIN_THRESHOLD`

- `CURRENT_REVIEW.md`: generated orientation and decision surface.
- `REVIEW_MANIFEST.json`: generated provenance, inclusion, omission, and size record.
- `support/development/campaigns/product_realization/pr_play_adjacent_regression_recovery/SUMMARY.md`: Primary campaign standard/report used to orient the review. Canonical source: `development/campaigns/product_realization/pr_play_adjacent_regression_recovery/SUMMARY.md`.
- `support/development/campaigns/product_realization/pr_play_adjacent_regression_recovery/HANDOFF_RECOVERY.md`: Supports recovered audit claims and review provenance. Canonical source: `development/campaigns/product_realization/pr_play_adjacent_regression_recovery/HANDOFF_RECOVERY.md`.
- `support/development/campaigns/product_realization/pr_play_adjacent_regression_recovery/FAILURE_INVENTORY.md`: Supports recovered audit claims and review provenance. Canonical source: `development/campaigns/product_realization/pr_play_adjacent_regression_recovery/FAILURE_INVENTORY.md`.
- `support/development/campaigns/product_realization/pr_play_adjacent_regression_recovery/BASELINE_RECONSTRUCTION.md`: Supports recovered audit claims and review provenance. Canonical source: `development/campaigns/product_realization/pr_play_adjacent_regression_recovery/BASELINE_RECONSTRUCTION.md`.
- `support/development/campaigns/product_realization/pr_play_adjacent_regression_recovery/CONTRACT_ANALYSIS.md`: Supports recovered audit claims and review provenance. Canonical source: `development/campaigns/product_realization/pr_play_adjacent_regression_recovery/CONTRACT_ANALYSIS.md`.
- `support/development/campaigns/product_realization/pr_play_adjacent_regression_recovery/TARGETED_REPAIR_VERIFICATION.md`: Supports recovered audit claims and review provenance. Canonical source: `development/campaigns/product_realization/pr_play_adjacent_regression_recovery/TARGETED_REPAIR_VERIFICATION.md`.
- `support/development/campaigns/product_realization/pr_play_adjacent_regression_recovery/NEXT_STEP_DECISION.md`: Supports recovered audit claims and review provenance. Canonical source: `development/campaigns/product_realization/pr_play_adjacent_regression_recovery/NEXT_STEP_DECISION.md`.
- `support/development/campaigns/product_realization/pr_play_adjacent_regression_recovery/INTEGRITY.md`: Supports recovered audit claims and review provenance. Canonical source: `development/campaigns/product_realization/pr_play_adjacent_regression_recovery/INTEGRITY.md`.
- `support/artifacts/pr_play_adjacent_regression_recovery/classification_matrix.json`: Supports recovered audit claims and review provenance. Canonical source: `artifacts/pr_play_adjacent_regression_recovery/classification_matrix.json`.
- `support/artifacts/pr_play_adjacent_regression_recovery/http_capture.json`: Supports recovered audit claims and review provenance. Canonical source: `artifacts/pr_play_adjacent_regression_recovery/http_capture.json`.
- `support/artifacts/pr_play_adjacent_regression_recovery/failures.json`: Supports recovered audit claims and review provenance. Canonical source: `artifacts/pr_play_adjacent_regression_recovery/failures.json`.
- `support/artifacts/pr_play_adjacent_regression_recovery/recovery_junit.xml`: Supports recovered audit claims and review provenance. Canonical source: `artifacts/pr_play_adjacent_regression_recovery/recovery_junit.xml`.
- `support/artifacts/pr_play_adjacent_regression_recovery/targeted_controls.json`: Supports recovered audit claims and review provenance. Canonical source: `artifacts/pr_play_adjacent_regression_recovery/targeted_controls.json`.
- `support/artifacts/pr_play_adjacent_regression_recovery/archive_diagnosis.json`: Supports recovered audit claims and review provenance. Canonical source: `artifacts/pr_play_adjacent_regression_recovery/archive_diagnosis.json`.
- `support/artifacts/pr_play_adjacent_regression_recovery/source_comparison.json`: Supports recovered audit claims and review provenance. Canonical source: `artifacts/pr_play_adjacent_regression_recovery/source_comparison.json`.
- `support/artifacts/pr_play_adjacent_regression_recovery/execution_integrity.json`: Supports recovered audit claims and review provenance. Canonical source: `artifacts/pr_play_adjacent_regression_recovery/execution_integrity.json`.
- `support/artifacts/pr_play_adjacent_regression_recovery/command.json`: Supports recovered audit claims and review provenance. Canonical source: `artifacts/pr_play_adjacent_regression_recovery/command.json`.
- `support/artifacts/pr_play_adjacent_regression_recovery/collected_nodes.json`: Supports recovered audit claims and review provenance. Canonical source: `artifacts/pr_play_adjacent_regression_recovery/collected_nodes.json`.
- `support/artifacts/pr_play_adjacent_regression_recovery/entry_hashes.json`: Supports recovered audit claims and review provenance. Canonical source: `artifacts/pr_play_adjacent_regression_recovery/entry_hashes.json`.
- `support/artifacts/pr_play_adjacent_regression_recovery/entry_git_status.txt`: Supports recovered audit claims and review provenance. Canonical source: `artifacts/pr_play_adjacent_regression_recovery/entry_git_status.txt`.
- `support/artifacts/pr_play_adjacent_regression_recovery/run_audit.py`: Supports recovered audit claims and review provenance. Canonical source: `artifacts/pr_play_adjacent_regression_recovery/run_audit.py`.
- `support/development/campaigns/product_realization/pr_play_67/05_PLAYER_SAFE_RESPONSE_CONTRACT.md`: Supports recovered audit claims and review provenance. Canonical source: `development/campaigns/product_realization/pr_play_67/05_PLAYER_SAFE_RESPONSE_CONTRACT.md`.
- `support/development/campaigns/product_realization/pr_play_67/09_FRONTEND_COMPATIBILITY.md`: Supports recovered audit claims and review provenance. Canonical source: `development/campaigns/product_realization/pr_play_67/09_FRONTEND_COMPATIBILITY.md`.
- `support/development/campaigns/product_realization/pr_play_67/10_DEVELOPMENT_TESTS.md`: Supports recovered audit claims and review provenance. Canonical source: `development/campaigns/product_realization/pr_play_67/10_DEVELOPMENT_TESTS.md`.
- `support/artifacts/pr_play_67/response_contract.json`: Supports recovered audit claims and review provenance. Canonical source: `artifacts/pr_play_67/response_contract.json`.
- `support/docs/NEXT_SESSION.md`: Supports recovered audit claims and review provenance. Canonical source: `docs/NEXT_SESSION.md`.
- `support/artifacts/pr_play_adjacent_regression/overlay_manifest.json`: Supports recovered audit claims and review provenance. Canonical source: `artifacts/pr_play_adjacent_regression/overlay_manifest.json`.
- `support/artifacts/pr_play_adjacent_regression/current_capture.json`: Supports recovered audit claims and review provenance. Canonical source: `artifacts/pr_play_adjacent_regression/current_capture.json`.
- `support/artifacts/pr_play_adjacent_regression/historical_capture.json`: Supports recovered audit claims and review provenance. Canonical source: `artifacts/pr_play_adjacent_regression/historical_capture.json`.
- `support/artifacts/pr_play_post_npc/implementation.diff`: Supports recovered audit claims and review provenance. Canonical source: `artifacts/pr_play_post_npc/implementation.diff`.
- `support/development/campaigns/product_realization/pr_play_post_npc/REGRESSION_RESULTS.md`: Supports recovered audit claims and review provenance. Canonical source: `development/campaigns/product_realization/pr_play_post_npc/REGRESSION_RESULTS.md`.
- `support/development/campaigns/product_realization/pr_play_post_npc/ROUTING_CONTRACT.md`: Supports recovered audit claims and review provenance. Canonical source: `development/campaigns/product_realization/pr_play_post_npc/ROUTING_CONTRACT.md`.
- `support/game/player_http_projection.py`: Supports recovered audit claims and review provenance. Canonical source: `game/player_http_projection.py`.
- `support/game/perception_grounding.py`: Supports recovered audit claims and review provenance. Canonical source: `game/perception_grounding.py`.
- `support/game/immutable_valid_response.py`: Supports recovered audit claims and review provenance. Canonical source: `game/immutable_valid_response.py`.
- `support/tests/test_referenced_surface_grounding_inspection_resolution.py`: Supports recovered audit claims and review provenance. Canonical source: `tests/test_referenced_surface_grounding_inspection_resolution.py`.
- `support/tests/test_pr_play_39_action_admission.py`: Supports recovered audit claims and review provenance. Canonical source: `tests/test_pr_play_39_action_admission.py`.
- `support/tests/test_pr_play_post_npc_handoff.py`: Supports recovered audit claims and review provenance. Canonical source: `tests/test_pr_play_post_npc_handoff.py`.

## Explicit omissions

No explicitly requested file was omitted.

The bundle intentionally excludes repository copies, dependency/cache directories, previous handoffs, unrelated artifacts, and sensitive configuration.
Canonical repository files remain authoritative; packaged copies are review conveniences with hashes and source paths.
