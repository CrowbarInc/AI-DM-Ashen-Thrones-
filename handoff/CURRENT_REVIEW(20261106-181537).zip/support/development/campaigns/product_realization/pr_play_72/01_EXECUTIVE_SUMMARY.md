# PR-PLAY-72 — 01 EXECUTIVE SUMMARY

B — PARTIAL / DETERMINISTIC INITIATIVE WITH VERIFICATION LIMITATIONS

The feature is deterministic and default off. Browser verification is blocked; live AI interpretation is not claimed. Read every machine result as scoped evidence, not a full-suite or external-validation claim.

```json
{
  "development": {
    "cases": 60,
    "passed": 59,
    "failed": 1,
    "failures": [
      "tests.test_pr_play_72_supplemental::test_explicit_npc_interaction_resolves"
    ]
  },
  "holdout": {
    "cases": 60,
    "passed": 52,
    "failed": [
      {
        "id": "H04",
        "checks": [
          "resolved_action"
        ]
      },
      {
        "id": "H05",
        "checks": [
          "resolved_action"
        ]
      },
      {
        "id": "H09",
        "checks": [
          "resolved_action"
        ]
      },
      {
        "id": "H10",
        "checks": [
          "resolved_action"
        ]
      },
      {
        "id": "H11",
        "checks": [
          "resolved_action"
        ]
      },
      {
        "id": "H15",
        "checks": [
          "resolved_action"
        ]
      },
      {
        "id": "H20",
        "checks": [
          "resolved_action"
        ]
      },
      {
        "id": "H38",
        "checks": [
          "category"
        ]
      }
    ],
    "manifest_sha256": "f9baae313a54716f910d34498e528abedd315cf052746ae5f9ec08eb65fdd131",
    "executions": 1,
    "authorship": "developer-authored; not independent external validation"
  },
  "http": {
    "campaigns": [
      {
        "branch": "survey",
        "identity": "f5b11c7287d3af4ce78be685",
        "snapshot_id": "2026-11-06T23-10-05_1f796970",
        "followup_flag": "patrol_survey_recorded",
        "information": "Faint overlapping prints mark the mud around the old milestone, but their number, origin, and direction stay unclear. The missing patrol was last seen taking the northwest mud track past the crates. The northwest mud track reaches an old milestone beyond the gate. The mud around the marker is churned; any trail beyond it is unclear. You commit to surveying the ground beyond the milestone yourself. Reporting to the watch is no longer your response to this discovery. You can now record the limits of your survey here. You record your survey: the overlapping prints remain inconclusive. Your survey is now recorded; you have not warned the watch. You can return to the gate or continue investigating here.",
        "resumed": true,
        "natural_followup": true,
        "transcript_restored": true
      },
      {
        "branch": "report",
        "identity": "e9e75fb9d8c25f63a750e5bb",
        "snapshot_id": "2026-11-06T23-11-39_f192f32d",
        "followup_flag": "patrol_guards_warned",
        "information": "Faint overlapping prints mark the mud around the old milestone, but their number, origin, and direction stay unclear. The missing patrol was last seen taking the northwest mud track past the crates. Follow the missing patrol rumor The patrol route changed after the Ash Compact census choke worsened. Cold rain needles Cinderwatch's eastern gate under frayed banners. The approach is jammed with refugees, wagons, and travelers; guards watch with hard, tired discipline. A notice board announces new taxes and curfews, and names a missing patrol. A tavern runner is hawking hot stew and rumor for coin. A ragged stranger hangs back, watching the crowd more than the queue. You commit to bringing the uncertain trail to the watch instead of conducting a private survey. Return to Cinderwatch Gate to give your report. The watch receives your report that the patrol trail becomes unclear at the milestone. The watch has now been warned; no private survey was conducted. You can continue your inquiry at the gate or return to the milestone. You have no established report of further guard activity.",
        "resumed": true,
        "natural_followup": true,
        "transcript_restored": true
      }
    ],
    "requests": 36,
    "mean_http_ms": 1623.9246027705829,
    "median_http_ms": 1338.2852000067942,
    "max_http_ms": 4556.402100017294,
    "provider_requests": 0,
    "provider_tokens": 0,
    "hidden_exposures": 0,
    "stage_timings": "Server function durations captured through ContextVar middleware; HTTP total measured separately. Replay interpretation is labeled separately."
  }
}
```

