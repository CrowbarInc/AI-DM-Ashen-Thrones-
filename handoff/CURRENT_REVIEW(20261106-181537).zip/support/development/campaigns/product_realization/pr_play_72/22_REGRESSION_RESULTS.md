# PR-PLAY-72 — 22 REGRESSION RESULTS

```json
{
  "focused": {
    "command": [
      "C:\\Users\\Master Mandalcio\\Documents\\Tabletop Gaming\\AI Dungeon Master\\ashen_thrones_ai_gm\\.venv\\Scripts\\python.exe",
      "-m",
      "pytest",
      "tests/test_pr_play_66_publication.py",
      "tests/test_pr_play_65_authoritative_disclosure.py",
      "tests/test_pr_play_64_discovery_language.py",
      "tests/test_pr_play_63_disclosure.py",
      "tests/test_state_authority.py",
      "tests/test_pr_play_61_player_facing.py",
      "tests/test_pr_play_62_investigation_quality.py",
      "tests/test_pr_play_60_inventory_projection.py",
      "tests/test_pr_play_60_gameplay_readiness.py",
      "tests/test_pr_play_59_persistent_consequences.py",
      "tests/test_pr_play_57_integrated_narration.py",
      "tests/test_pr_play_58_semantic_coverage.py",
      "tests/test_pr_play_55_discovery_claims.py",
      "tests/test_pr_play_54_consequential_validation.py",
      "tests/test_pr_play_53_quarantined_live.py",
      "tests/test_pr_play_52_quarantined_integration.py",
      "tests/test_pr_play_42_evidence_boundaries.py",
      "tests/test_pr_play_51_geography_grounding.py",
      "tests/test_pr_play_49_anchored_narration.py",
      "tests/test_pr_play_47_controlled_renderer.py",
      "tests/test_pr_play_45_narration_authority.py",
      "tests/test_pr_play_46_mechanical_boundary.py",
      "tests/test_pr_play_44_information_delivery.py",
      "tests/test_pr_bu_lexical_scope.py",
      "tests/test_provider_accounting_integrity.py",
      "tests/test_pr_bw_narration_only_envelope.py",
      "tests/test_diegetic_fallback_narration.py",
      "tests/test_narration_state_consistency.py",
      "tests/test_pr_play_68_structured_publication.py",
      "tests/test_pr_play_69_target_references.py",
      "tests/test_pr_play_70_branching.py",
      "tests/test_pr_play_71_lifecycle.py",
      "tests/test_pr_play_71_persistence_recovery.py",
      "tests/test_pr_play_71v_verification.py",
      "--tb=line",
      "--junitxml=C:\\Users\\Master Mandalcio\\Documents\\Tabletop Gaming\\AI Dungeon Master\\ashen_thrones_ai_gm\\artifacts\\pr_play_72\\focused.xml",
      "--basetemp=C:\\Users\\Master Mandalcio\\Documents\\Tabletop Gaming\\AI Dungeon Master\\ashen_thrones_ai_gm\\artifacts\\pr_play_72\\focused_tmp"
    ],
    "exit_code": 1,
    "passed": 1064,
    "failed": [
      "tests.test_pr_play_54_consequential_validation::test_corpus_validation_stays_fast_and_local",
      "tests.test_provider_accounting_integrity::test_readiness_acceptance_is_not_live_execution",
      "tests.test_narration_state_consistency::test_refusal_text_with_location_repair_updates_state_and_clues",
      "tests.test_narration_state_consistency::test_usable_location_in_text_updates_structured_topic_and_clues",
      "tests.test_pr_play_71_lifecycle::test_normal_lifecycle[survey]",
      "tests.test_pr_play_71_lifecycle::test_normal_lifecycle[report]",
      "tests.test_pr_play_71_lifecycle::test_enrollment_isolation[off]",
      "tests.test_pr_play_71_lifecycle::test_enrollment_isolation[no_optin]",
      "tests.test_pr_play_71_lifecycle::test_enrollment_isolation[other_identity]",
      "tests.test_pr_play_71_lifecycle::test_duplicate_start",
      "tests.test_pr_play_71_persistence_recovery::test_new_campaign_failure_restores_prior_runtime",
      "tests.test_pr_play_71v_verification::test_new_campaign_rollback_on_each_runtime_file",
      "tests.test_pr_play_71v_verification::test_new_campaign_identifier_failure_changes_nothing",
      "tests.test_pr_play_71v_verification::test_opening_persistence_failure_does_not_publish_start",
      "tests.test_pr_play_71v_verification::test_chat_transient_rename_commits_one_turn[1]",
      "tests.test_pr_play_71v_verification::test_chat_transient_rename_commits_one_turn[3]",
      "tests.test_pr_play_71v_verification::test_chat_permanent_rename_does_not_publish_success",
      "tests.test_pr_play_71v_verification::test_transcript_and_authoritative_isolation",
      "tests.test_pr_play_71v_verification::test_player_safe_projection_across_lifecycle",
      "tests.test_pr_play_71v_verification::test_mandatory_disclosure_survives_rejected_narration",
      "tests.test_pr_play_71v_verification::test_duplicate_request_does_not_duplicate_branch"
    ]
  },
  "boundary": {
    "command": [
      "C:\\Users\\Master Mandalcio\\Documents\\Tabletop Gaming\\AI Dungeon Master\\ashen_thrones_ai_gm\\.venv\\Scripts\\python.exe",
      "-m",
      "pytest",
      "tests/test_pr_play_67_player_projection.py",
      "tests/test_ui_mode_backend_integration.py",
      "tests/test_ui_mode_regression_matrix_objective15.py",
      "tests/test_frontend_ui_mode_hardening_objective15.py",
      "tests/test_state_channels.py",
      "tests/test_snapshots.py",
      "tests/test_start_campaign_api.py",
      "tests/test_pr_play_37_opening_recovery.py",
      "--tb=line",
      "--junitxml=C:\\Users\\Master Mandalcio\\Documents\\Tabletop Gaming\\AI Dungeon Master\\ashen_thrones_ai_gm\\artifacts\\pr_play_72\\boundary.xml",
      "--basetemp=C:\\Users\\Master Mandalcio\\Documents\\Tabletop Gaming\\AI Dungeon Master\\ashen_thrones_ai_gm\\artifacts\\pr_play_72\\boundary_tmp"
    ],
    "exit_code": 1,
    "passed": 101,
    "failed": [
      "tests.test_start_campaign_api::test_start_campaign_emits_opening_and_sets_started",
      "tests.test_start_campaign_api::test_start_campaign_scene_opening_reconcile_cannot_shorten_rich_post_gate_text",
      "tests.test_start_campaign_api::test_start_campaign_promotes_valid_upstream_prepared_scene_opening",
      "tests.test_start_campaign_api::test_failed_start_campaign_does_not_mark_started",
      "tests.test_pr_play_37_opening_recovery::test_http_invalid_declaration_discards_provider_text",
      "tests.test_pr_play_37_opening_recovery::test_http_composer_failure_does_not_commit"
    ]
  },
  "broader": {
    "command": [
      "C:\\Users\\Master Mandalcio\\Documents\\Tabletop Gaming\\AI Dungeon Master\\ashen_thrones_ai_gm\\.venv\\Scripts\\python.exe",
      "-m",
      "pytest",
      "tests/test_pr_cx_authority_assurance.py",
      "--tb=line",
      "--junitxml=C:\\Users\\Master Mandalcio\\Documents\\Tabletop Gaming\\AI Dungeon Master\\ashen_thrones_ai_gm\\artifacts\\pr_play_72\\broader.xml",
      "--basetemp=C:\\Users\\Master Mandalcio\\Documents\\Tabletop Gaming\\AI Dungeon Master\\ashen_thrones_ai_gm\\artifacts\\pr_play_72\\broader_tmp"
    ],
    "exit_code": 1,
    "passed": 0,
    "failed": [
      "tests.test_pr_cx_authority_assurance::test_pr_cx_rejects_inherited_objective_authority_violations[biography-The guard captain was born in Blackharbor and served for twenty years.-biography]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_rejects_inherited_objective_authority_violations[geography-The old milestone lies east beyond the trading crossroads.-geography]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_rejects_inherited_objective_authority_violations[hidden_information-A secret tunnel runs beneath the gate into the keep.-hidden_information]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_rejects_inherited_objective_authority_violations[npc_action-The captain unlocks the gate and lets you pass.-npc_action]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_rejects_inherited_objective_authority_violations[discovery-You discover a hidden map beneath the notice board.-discovery]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_preserves_harmless_dialogue_and_grounded_observation[preference-The guard captain says, \"I prefer a dry watch.\"]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_preserves_harmless_dialogue_and_grounded_observation[opinion-The guard captain says, \"I like the square best after rain.\"]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_preserves_harmless_dialogue_and_grounded_observation[incidental_characterization-The guard captain shrugs and nods.]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_preserves_harmless_dialogue_and_grounded_observation[grounded_observation-A notice board lists new taxes, curfews, and a posted warning about a missing patrol.]"
    ]
  },
  "lifecycle_isolated": {
    "command": [
      "C:\\Users\\Master Mandalcio\\Documents\\Tabletop Gaming\\AI Dungeon Master\\ashen_thrones_ai_gm\\.venv\\Scripts\\python.exe",
      "-m",
      "pytest",
      "tests/test_pr_play_71_lifecycle.py",
      "tests/test_pr_play_71_persistence_recovery.py",
      "tests/test_pr_play_71v_verification.py",
      "--tb=line",
      "--junitxml=C:\\Users\\Master Mandalcio\\Documents\\Tabletop Gaming\\AI Dungeon Master\\ashen_thrones_ai_gm\\artifacts\\pr_play_72\\lifecycle_isolated.xml",
      "--basetemp=C:\\Users\\Master Mandalcio\\Documents\\Tabletop Gaming\\AI Dungeon Master\\ashen_thrones_ai_gm\\artifacts\\pr_play_72\\lifecycle_isolated_tmp"
    ],
    "exit_code": 0,
    "passed": 39,
    "failed": []
  }
}
```

Combined focused: 1064 passed / 21 failed. The prior 20 failed identities remain, with one additional corpus timing assertion. That timing assertion passed in the fresh post-repair process; it is not labelled historical. Boundary 101/6 and broader 0/9 match prior failed-node sets. Clean lifecycle/persistence: 39/39. Additional post-repair owner/compatibility lane: 42 passed / 12 failed. The same 12 failures reproduce with the preserved pre-repair owner loaded in memory (37 passed / 12 failed across its 49 cases); this is a targeted comparison, not a full entry-tree replay. Most expect internal resolution data omitted by the existing player projection. See regression_assessment.json for both messages and comparison provenance. No confirmed new product regression remains in these executed lanes; no full-suite or official ATGB claim.

Early combined regression regenerated some legacy analysis report outputs. Later collection hooks redirect their OUT paths, and the write guard protects prior artifact roots. Entry hashes were recorded for production-like data, not every earlier analysis report: preservation of those regenerated reports is not claimed. See final_isolation_result.json and historical_evidence_guard_integrity.json.
