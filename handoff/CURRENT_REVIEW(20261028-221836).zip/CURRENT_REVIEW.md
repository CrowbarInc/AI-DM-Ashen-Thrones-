# Campaign

Campaign: PR-PLAY-06 — Structured Opening Output Budget and Contract Efficiency
Identifier: `pr_play_06`
Date: 2026-10-28
Generated: 2026-10-29T02:17:58.234146+00:00
Purpose: Bounded offline repair; no live/connectivity authority. Stop after ZIP.

# Executive Summary

Opening-only 3000-token default (hard configurable bound 4096), explicit incomplete-status rejection. Ordinary controlled output 600; aggregate limits and retries unchanged. 58 focused pass; 361 broader pass / 5 entry-reproduced failures. No prompt reductions. Structural-only evidence; live adequacy unproven. No live provider calls. No provider connectivity diagnostics. No model changes.
No response-schema changes. No additional provider operations. No automatic retries.
No unauthorized gameplay-state mutations. No new persistent gameplay structures.
No experimental PR-EG integration. Frozen ATGB baseline unchanged. No secrets included.
No commit or push performed.

Objective status: `B — Conditionally ready`.

# Changes Made

## Production changes

- Opening-specific bounded setting and unfinished-opening status rejection in existing GM owner.

## Validation changes

- 19 new deterministic tests; existing diagnostic fixture ceilings updated.

## Tooling changes

- Offline bounded test driver, measurement, inventory, manual/report preparation.

## Documentation changes

- Eight reports, executable operator procedure, canonical session handoff.

## Generated artifacts

- Explicit review ZIP, provenance manifest, snapshots, source diff and measurements.

# What Was Tested

- **Focused tests:** 58 passed, zero live calls.
- **Broader relevant tests:** 361 passed / 5 confirmed preexisting failures.
- **Full suite:** Not run; bounded relevant slices only.
- **Runtime validation:** Synthetic SDK responses through existing endpoint/acceptance/persistence path; local HTTP control passed.
- **Model/runtime boundary:** No provider generation. Token estimates; 3000 is a defensible trial allowance.
- **New regressions:** None observed in completed scope.
- **Pre-existing failures:** Five matching IDs reproduced with saved entry GM source; see entry_failures.xml.
- **Self-contained bundle review:** ZIP entries/provenance hashes, eight reports, source diff, required manual and verdict checked by package finalizer.

# Behavioral Evidence

No standardized behavioral evidence packet was supplied.

# Decisions Requiring Human Review

- External reviewer to accept/redirect conditional readiness before any one-Start operator test.

# Known Problems / Unresolved Findings

## Campaign-specific

- Exact tokenizer unavailable; live structured generation remains unproven.

## Pre-existing baseline

- Three verbose-rich emission assertions, stale source attestation and stew-price conversation assertion.

# Missing Concepts / Future Capabilities

- None recorded.

# What This Campaign Does NOT Prove

- Live success, statistical reliability, independent generalization or gameplay benchmark improvement.
- Cost neutrality: opening ceiling rises 600 to 3000 (+2400).

# Recommended Next Step

External review of this package. Do not run another live opening until accepted.

# Review Bundle Contents

Bundle file count: `106`
Bundle ZIP size: `000000504969` bytes
Size warning threshold: `20971520` bytes
Size status: `WITHIN_THRESHOLD`

- `CURRENT_REVIEW.md`: generated orientation and decision surface.
- `REVIEW_MANIFEST.json`: generated provenance, inclusion, omission, and size record.
- `support/development/campaigns/product_realization/pr_play_06/08_final_verdict_and_handoff.md`: Primary campaign standard/report used to orient the review. Canonical source: `development/campaigns/product_realization/pr_play_06/08_final_verdict_and_handoff.md`.
- `support/development/campaigns/product_realization/pr_play_06/01_baseline_and_historical_evidence.md`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `development/campaigns/product_realization/pr_play_06/01_baseline_and_historical_evidence.md`.
- `support/development/campaigns/product_realization/pr_play_06/02_structured_output_requirements.md`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `development/campaigns/product_realization/pr_play_06/02_structured_output_requirements.md`.
- `support/development/campaigns/product_realization/pr_play_06/03_output_budget_implementation.md`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `development/campaigns/product_realization/pr_play_06/03_output_budget_implementation.md`.
- `support/development/campaigns/product_realization/pr_play_06/04_opening_prompt_inventory.md`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `development/campaigns/product_realization/pr_play_06/04_opening_prompt_inventory.md`.
- `support/development/campaigns/product_realization/pr_play_06/05_deterministic_validation.md`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `development/campaigns/product_realization/pr_play_06/05_deterministic_validation.md`.
- `support/development/campaigns/product_realization/pr_play_06/06_regression_and_performance.md`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `development/campaigns/product_realization/pr_play_06/06_regression_and_performance.md`.
- `support/development/campaigns/product_realization/pr_play_06/07_live_test_readiness.md`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `development/campaigns/product_realization/pr_play_06/07_live_test_readiness.md`.
- `support/development/campaigns/product_realization/pr_play_06/PR_PLAY_06_LIVE_OPENING_TEST.txt`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `development/campaigns/product_realization/pr_play_06/PR_PLAY_06_LIVE_OPENING_TEST.txt`.
- `support/game/gm.py`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `game/gm.py`.
- `support/tests/test_pr_play_05_diagnostics.py`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `tests/test_pr_play_05_diagnostics.py`.
- `support/tests/test_pr_play_06_opening_budget.py`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `tests/test_pr_play_06_opening_budget.py`.
- `support/tests/helpers/pr_play_06_entry_source.py`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `tests/helpers/pr_play_06_entry_source.py`.
- `support/tools/analyze_pr_play_06.py`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `tools/analyze_pr_play_06.py`.
- `support/tools/measure_pr_play_06.py`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `tools/measure_pr_play_06.py`.
- `support/tools/prepare_pr_play_06_manual.py`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `tools/prepare_pr_play_06_manual.py`.
- `support/tools/report_pr_play_06.py`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `tools/report_pr_play_06.py`.
- `support/tools/validate_pr_play_06.py`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `tools/validate_pr_play_06.py`.
- `support/docs/NEXT_SESSION.md`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `docs/NEXT_SESSION.md`.
- `support/artifacts/pr_play_06/aggregate_refusal.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/aggregate_refusal.json`.
- `support/artifacts/pr_play_06/baseline.txt`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/baseline.txt`.
- `support/artifacts/pr_play_06/baseline.xml`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/baseline.xml`.
- `support/artifacts/pr_play_06/baseline_measurements/declarations.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/baseline_measurements/declarations.json`.
- `support/artifacts/pr_play_06/baseline_measurements/minimal.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/baseline_measurements/minimal.json`.
- `support/artifacts/pr_play_06/baseline_measurements/multiple_details.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/baseline_measurements/multiple_details.json`.
- `support/artifacts/pr_play_06/baseline_measurements/npc.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/baseline_measurements/npc.json`.
- `support/artifacts/pr_play_06/baseline_measurements/over_600.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/baseline_measurements/over_600.json`.
- `support/artifacts/pr_play_06/baseline_measurements/rich.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/baseline_measurements/rich.json`.
- `support/artifacts/pr_play_06/baseline_measurements/typical.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/baseline_measurements/typical.json`.
- `support/artifacts/pr_play_06/diagnostics/budget.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/diagnostics/budget.json`.
- `support/artifacts/pr_play_06/diagnostics/concurrent.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/diagnostics/concurrent.json`.
- `support/artifacts/pr_play_06/diagnostics/D1.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/diagnostics/D1.json`.
- `support/artifacts/pr_play_06/diagnostics/D10.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/diagnostics/D10.json`.
- `support/artifacts/pr_play_06/diagnostics/D2.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/diagnostics/D2.json`.
- `support/artifacts/pr_play_06/diagnostics/D3.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/diagnostics/D3.json`.
- `support/artifacts/pr_play_06/diagnostics/D4.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/diagnostics/D4.json`.
- `support/artifacts/pr_play_06/diagnostics/D5.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/diagnostics/D5.json`.
- `support/artifacts/pr_play_06/diagnostics/D6.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/diagnostics/D6.json`.
- `support/artifacts/pr_play_06/diagnostics/D7.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/diagnostics/D7.json`.
- `support/artifacts/pr_play_06/diagnostics/D8.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/diagnostics/D8.json`.
- `support/artifacts/pr_play_06/diagnostics/D9.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/diagnostics/D9.json`.
- `support/artifacts/pr_play_06/diagnostics/extraction.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/diagnostics/extraction.json`.
- `support/artifacts/pr_play_06/diagnostics/placeholder.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/diagnostics/placeholder.json`.
- `support/artifacts/pr_play_06/diagnostics/placeholder_http.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/diagnostics/placeholder_http.json`.
- `support/artifacts/pr_play_06/diagnostics/repeat.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/diagnostics/repeat.json`.
- `support/artifacts/pr_play_06/diagnostics/retry.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/diagnostics/retry.json`.
- `support/artifacts/pr_play_06/diagnostics/validation.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/diagnostics/validation.json`.
- `support/artifacts/pr_play_06/entry/gm.py`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/entry/gm.py`.
- `support/artifacts/pr_play_06/entry/test_pr_play_05_diagnostics.py`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/entry/test_pr_play_05_diagnostics.py`.
- `support/artifacts/pr_play_06/entry_failures.txt`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/entry_failures.txt`.
- `support/artifacts/pr_play_06/entry_failures.xml`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/entry_failures.xml`.
- `support/artifacts/pr_play_06/entry_failures_run.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/entry_failures_run.json`.
- `support/artifacts/pr_play_06/entry_head.txt`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/entry_head.txt`.
- `support/artifacts/pr_play_06/entry_status.txt`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/entry_status.txt`.
- `support/artifacts/pr_play_06/environment_attempts.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/environment_attempts.json`.
- `support/artifacts/pr_play_06/export.txt`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/export.txt`.
- `support/artifacts/pr_play_06/export.xml`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/export.xml`.
- `support/artifacts/pr_play_06/export_run.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/export_run.json`.
- `support/artifacts/pr_play_06/final_status.txt`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/final_status.txt`.
- `support/artifacts/pr_play_06/focused.txt`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/focused.txt`.
- `support/artifacts/pr_play_06/focused.xml`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/focused.xml`.
- `support/artifacts/pr_play_06/focused_non_http.txt`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/focused_non_http.txt`.
- `support/artifacts/pr_play_06/focused_non_http.xml`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/focused_non_http.xml`.
- `support/artifacts/pr_play_06/focused_non_http_run.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/focused_non_http_run.json`.
- `support/artifacts/pr_play_06/focused_run.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/focused_run.json`.
- `support/artifacts/pr_play_06/historical_evidence.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/historical_evidence.json`.
- `support/artifacts/pr_play_06/historical_rich_rejection.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/historical_rich_rejection.json`.
- `support/artifacts/pr_play_06/incomplete_content_filter.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/incomplete_content_filter.json`.
- `support/artifacts/pr_play_06/incomplete_max_output_tokens.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/incomplete_max_output_tokens.json`.
- `support/artifacts/pr_play_06/manual_syntax.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/manual_syntax.json`.
- `support/artifacts/pr_play_06/measurements/declarations.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/measurements/declarations.json`.
- `support/artifacts/pr_play_06/measurements/minimal.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/measurements/minimal.json`.
- `support/artifacts/pr_play_06/measurements/multiple_details.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/measurements/multiple_details.json`.
- `support/artifacts/pr_play_06/measurements/npc.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/measurements/npc.json`.
- `support/artifacts/pr_play_06/measurements/over_600.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/measurements/over_600.json`.
- `support/artifacts/pr_play_06/measurements/rich.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/measurements/rich.json`.
- `support/artifacts/pr_play_06/measurements/typical.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/measurements/typical.json`.
- `support/artifacts/pr_play_06/new.xml`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/new.xml`.
- `support/artifacts/pr_play_06/opening.txt`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/opening.txt`.
- `support/artifacts/pr_play_06/opening.xml`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/opening.xml`.
- `support/artifacts/pr_play_06/opening_run.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/opening_run.json`.
- `support/artifacts/pr_play_06/ordinary.txt`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/ordinary.txt`.
- `support/artifacts/pr_play_06/ordinary.xml`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/ordinary.xml`.
- `support/artifacts/pr_play_06/ordinary_run.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/ordinary_run.json`.
- `support/artifacts/pr_play_06/performance.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/performance.json`.
- `support/artifacts/pr_play_06/prompt_integrity.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/prompt_integrity.json`.
- `support/artifacts/pr_play_06/prompt_inventory.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/prompt_inventory.json`.
- `support/artifacts/pr_play_06/protected_entry.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/protected_entry.json`.
- `support/artifacts/pr_play_06/protected_integrity.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/protected_integrity.json`.
- `support/artifacts/pr_play_06/provider.txt`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/provider.txt`.
- `support/artifacts/pr_play_06/provider.xml`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/provider.xml`.
- `support/artifacts/pr_play_06/provider_run.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/provider_run.json`.
- `support/artifacts/pr_play_06/requests/declarations.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/requests/declarations.json`.
- `support/artifacts/pr_play_06/requests/minimal.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/requests/minimal.json`.
- `support/artifacts/pr_play_06/requests_before/declarations.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/requests_before/declarations.json`.
- `support/artifacts/pr_play_06/requests_before/minimal.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/requests_before/minimal.json`.
- `support/artifacts/pr_play_06/source_diff.patch`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/source_diff.patch`.
- `support/artifacts/pr_play_06/structured.txt`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/structured.txt`.
- `support/artifacts/pr_play_06/structured.xml`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/structured.xml`.
- `support/artifacts/pr_play_06/structured_run.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/structured_run.json`.
- `support/artifacts/pr_play_06/test_summary.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/test_summary.json`.
- `support/artifacts/pr_play_06/world.txt`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/world.txt`.
- `support/artifacts/pr_play_06/world.xml`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/world.xml`.
- `support/artifacts/pr_play_06/world_run.json`: PR-PLAY-06 scoped source, report, manual or deterministic evidence. Canonical source: `artifacts/pr_play_06/world_run.json`.

## Explicit omissions

- `development/campaigns/product_realization/pr_play_06/08_final_verdict_and_handoff.md`: duplicate content of development/campaigns/product_realization/pr_play_06/08_final_verdict_and_handoff.md; canonical reference retained
- `artifacts/pr_play_06/requests/multiple_details.json`: duplicate content of artifacts/pr_play_06/requests/declarations.json; canonical reference retained
- `artifacts/pr_play_06/requests/npc.json`: duplicate content of artifacts/pr_play_06/requests/declarations.json; canonical reference retained
- `artifacts/pr_play_06/requests/over_600.json`: duplicate content of artifacts/pr_play_06/requests/declarations.json; canonical reference retained
- `artifacts/pr_play_06/requests/rich.json`: duplicate content of artifacts/pr_play_06/requests/declarations.json; canonical reference retained
- `artifacts/pr_play_06/requests/typical.json`: duplicate content of artifacts/pr_play_06/requests/declarations.json; canonical reference retained
- `artifacts/pr_play_06/requests_before/multiple_details.json`: duplicate content of artifacts/pr_play_06/requests_before/declarations.json; canonical reference retained
- `artifacts/pr_play_06/requests_before/npc.json`: duplicate content of artifacts/pr_play_06/requests_before/declarations.json; canonical reference retained
- `artifacts/pr_play_06/requests_before/over_600.json`: duplicate content of artifacts/pr_play_06/requests_before/declarations.json; canonical reference retained
- `artifacts/pr_play_06/requests_before/rich.json`: duplicate content of artifacts/pr_play_06/requests_before/declarations.json; canonical reference retained
- `artifacts/pr_play_06/requests_before/typical.json`: duplicate content of artifacts/pr_play_06/requests_before/declarations.json; canonical reference retained

The bundle intentionally excludes repository copies, dependency/cache directories, previous handoffs, unrelated artifacts, and sensitive configuration.
Canonical repository files remain authoritative; packaged copies are review conveniences with hashes and source paths.
