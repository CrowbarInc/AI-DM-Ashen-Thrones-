"""Observability and evaluator read helpers (delegate facade).

Delegates to :mod:`game.final_emission_meta_read`, which in turn delegates to the
canonical FEM write owner. This module adds **no** ownership authority, bucket
mapping, or write paths.

Phase 2 will route diagnostics evaluators and observability tests here instead
of importing ``final_emission_meta_read`` alongside attribution sources.
"""
from __future__ import annotations

from game.final_emission_meta_read import (
    FINAL_EMISSION_META_KEY,
    NARRATIVE_AUTHENTICITY_FEM_KEYS,
    OPENING_FALLBACK_EMITTED_METADATA_FIELDS,
    OPENING_FALLBACK_FAIL_CLOSED_DIAGNOSTIC_FIELDS,
    OPENING_FALLBACK_OUT_OF_BAND_TELEMETRY_FIELDS,
    OPENING_FALLBACK_OUT_OF_BAND_TELEMETRY_RTD_MERGE_FIELDS,
    PRODUCER_REPAIR_KIND_FALLBACK_BEHAVIOR_REPAIR,
    PRODUCER_REPAIR_KIND_FIELD,
    PRODUCER_REPAIR_KIND_FIRST_MENTION_ENFORCEMENT,
    PRODUCER_REPAIR_KIND_PASSIVE_SCENE_CONCRETE_BEAT,
    PRODUCER_REPAIR_KIND_PASSIVE_SCENE_PRESSURE_FALLBACK,
    PRODUCER_REPAIR_KIND_REFERENTIAL_CLARITY_ENFORCEMENT,
    PRODUCER_REPAIR_KIND_REFERENTIAL_CLARITY_LOCAL_SUBSTITUTION,
    PRODUCER_REPAIR_KIND_SANITIZER_EMPTY_OUTPUT,
    PRODUCER_REPAIR_KIND_SANITIZER_STRIP_ONLY,
    PRODUCER_REPAIR_KIND_STRICT_SOCIAL_REPAIR,
    PRODUCER_REPAIR_KIND_VISIBILITY_ENFORCEMENT,
    SEMANTIC_MUTATION_WRITE_SITES_KEY,
    assemble_unified_observational_telemetry_bundle,
    build_fem_observability_events,
    build_narrative_authenticity_emission_trace,
    classify_dead_turn,
    default_response_type_debug,
    final_emission_meta_read_side_surface,
    infer_accept_path_final_emitted_source,
    merge_response_type_meta,
    normalize_final_emission_meta_for_observability,
    normalize_merged_na_telemetry_for_eval,
    normalized_observational_telemetry_bundle,
    opening_fallback_metadata_classification_parity_errors,
    opening_fallback_metadata_field_registry_parity_errors,
    read_dead_turn_from_gm_output,
    read_debug_notes_from_turn_payload,
    read_emission_debug_lane,
    read_emission_debug_lane_from_turn_payload,
    read_final_emission_meta_dict,
    read_final_emission_meta_from_turn_payload,
    stage_diff_narrative_authenticity_projection,
    summarize_gameplay_validation_for_turn,
)

__all__ = [
    "FINAL_EMISSION_META_KEY",
    "NARRATIVE_AUTHENTICITY_FEM_KEYS",
    "OPENING_FALLBACK_EMITTED_METADATA_FIELDS",
    "OPENING_FALLBACK_FAIL_CLOSED_DIAGNOSTIC_FIELDS",
    "OPENING_FALLBACK_OUT_OF_BAND_TELEMETRY_FIELDS",
    "OPENING_FALLBACK_OUT_OF_BAND_TELEMETRY_RTD_MERGE_FIELDS",
    "PRODUCER_REPAIR_KIND_FALLBACK_BEHAVIOR_REPAIR",
    "PRODUCER_REPAIR_KIND_FIELD",
    "PRODUCER_REPAIR_KIND_FIRST_MENTION_ENFORCEMENT",
    "PRODUCER_REPAIR_KIND_PASSIVE_SCENE_CONCRETE_BEAT",
    "PRODUCER_REPAIR_KIND_PASSIVE_SCENE_PRESSURE_FALLBACK",
    "PRODUCER_REPAIR_KIND_REFERENTIAL_CLARITY_ENFORCEMENT",
    "PRODUCER_REPAIR_KIND_REFERENTIAL_CLARITY_LOCAL_SUBSTITUTION",
    "PRODUCER_REPAIR_KIND_SANITIZER_EMPTY_OUTPUT",
    "PRODUCER_REPAIR_KIND_SANITIZER_STRIP_ONLY",
    "PRODUCER_REPAIR_KIND_STRICT_SOCIAL_REPAIR",
    "PRODUCER_REPAIR_KIND_VISIBILITY_ENFORCEMENT",
    "SEMANTIC_MUTATION_WRITE_SITES_KEY",
    "assemble_unified_observational_telemetry_bundle",
    "build_fem_observability_events",
    "build_narrative_authenticity_emission_trace",
    "classify_dead_turn",
    "default_response_type_debug",
    "final_emission_meta_read_side_surface",
    "infer_accept_path_final_emitted_source",
    "merge_response_type_meta",
    "normalize_final_emission_meta_for_observability",
    "normalize_merged_na_telemetry_for_eval",
    "normalized_observational_telemetry_bundle",
    "observability_attribution_read_surface",
    "opening_fallback_metadata_classification_parity_errors",
    "opening_fallback_metadata_field_registry_parity_errors",
    "read_dead_turn_from_gm_output",
    "read_debug_notes_from_turn_payload",
    "read_emission_debug_lane",
    "read_emission_debug_lane_from_turn_payload",
    "read_final_emission_meta_dict",
    "read_final_emission_meta_from_turn_payload",
    "stage_diff_narrative_authenticity_projection",
    "summarize_gameplay_validation_for_turn",
]

_OBSERVABILITY_SYMBOLS: tuple[str, ...] = (
    "assemble_unified_observational_telemetry_bundle",
    "build_fem_observability_events",
    "build_narrative_authenticity_emission_trace",
    "classify_dead_turn",
    "default_response_type_debug",
    "infer_accept_path_final_emitted_source",
    "normalize_final_emission_meta_for_observability",
    "normalize_merged_na_telemetry_for_eval",
    "normalized_observational_telemetry_bundle",
    "read_dead_turn_from_gm_output",
    "read_debug_notes_from_turn_payload",
    "read_emission_debug_lane",
    "read_emission_debug_lane_from_turn_payload",
    "read_final_emission_meta_dict",
    "read_final_emission_meta_from_turn_payload",
    "stage_diff_narrative_authenticity_projection",
    "summarize_gameplay_validation_for_turn",
)

_PRODUCER_REPAIR_KIND_FIELD_CONSTANT: str = "PRODUCER_REPAIR_KIND_FIELD"

# Classifier-aligned producer repair kinds (parity with ``ALLOWED_PRODUCER_REPAIR_KINDS``).
_PRODUCER_REPAIR_KIND_CLASSIFIER_CONSTANTS: tuple[str, ...] = (
    "PRODUCER_REPAIR_KIND_VISIBILITY_ENFORCEMENT",
    "PRODUCER_REPAIR_KIND_FIRST_MENTION_ENFORCEMENT",
    "PRODUCER_REPAIR_KIND_REFERENTIAL_CLARITY_ENFORCEMENT",
    "PRODUCER_REPAIR_KIND_REFERENTIAL_CLARITY_LOCAL_SUBSTITUTION",
    "PRODUCER_REPAIR_KIND_PASSIVE_SCENE_CONCRETE_BEAT",
    "PRODUCER_REPAIR_KIND_PASSIVE_SCENE_PRESSURE_FALLBACK",
    "PRODUCER_REPAIR_KIND_SANITIZER_EMPTY_OUTPUT",
    "PRODUCER_REPAIR_KIND_SANITIZER_STRIP_ONLY",
    "PRODUCER_REPAIR_KIND_STRICT_SOCIAL_REPAIR",
    "PRODUCER_REPAIR_KIND_FALLBACK_BEHAVIOR_REPAIR",
)

def observability_attribution_read_surface() -> dict[str, object]:
    """Diagnostic registry for BV10 Phase 2 observability read facade."""
    return {
        "facade": "game.observability_attribution_read",
        "delegate_module": "game.final_emission_meta_read",
        "observability_symbols": list(_OBSERVABILITY_SYMBOLS),
        "producer_repair_kind_field_constant": _PRODUCER_REPAIR_KIND_FIELD_CONSTANT,
        "producer_repair_kind_constants": list(_PRODUCER_REPAIR_KIND_CLASSIFIER_CONSTANTS),
        "narrative_authenticity_fem_keys": list(NARRATIVE_AUTHENTICITY_FEM_KEYS),
    }
