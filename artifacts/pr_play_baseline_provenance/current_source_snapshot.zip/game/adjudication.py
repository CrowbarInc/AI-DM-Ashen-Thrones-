"""Deterministic adjudication query routing for GM-facing procedural questions.

This module handles lightweight question categories before GPT narration fallback.
It does not mutate authoritative state.

Directed NPC information questions are excluded via
:func:`game.interaction_context.resolve_directed_social_entry` inside
:func:`classify_adjudication_query` — that gate is authoritative; do not duplicate its rules here.
"""
from __future__ import annotations

import re
from typing import Any, Dict, Optional

from game.interaction_context import (
    addressable_scene_npc_id_universe,
    canonical_scene_addressable_roster,
    extract_place_existence_subject,
    is_rules_or_engine_mechanics_question,
    _looks_like_place_existence_question,
    _place_existence_content_tokens,
    _place_existence_subject_matches_present_person,
    resolve_directed_social_entry,
)
from game.models import make_check_request
from game.social import find_npc_by_target


ADJUDICATION_CATEGORIES = (
    "state_query",
    "perception_query",
    "roll_requirement_query",
    "action_feasibility_query",
)


_ENGINE_VOICE_PREFIX_RE = re.compile(
    r"^\s*(?:\[(?:engine|adjudication)\]\s*)?(?:adjudication)\s*[:\-–—]\s*",
    re.IGNORECASE,
)


def neutralize_engine_voice_for_player(text: str) -> str:
    """Remove immersion-breaking engine-voice prefixes from deterministic outputs.

    This is intentionally narrow: it only strips leading markers (e.g. "Adjudication:")
    without attempting broader rewriting.
    """
    if not isinstance(text, str):
        return ""
    original = text
    out = _ENGINE_VOICE_PREFIX_RE.sub("", text, count=1)
    out = out.lstrip()
    return out if out.strip() else original.strip()


def _finalize_adjudication_result(result: Dict[str, Any]) -> Dict[str, Any]:
    """Apply narrow player-facing sanitization to adjudication payloads."""
    if not isinstance(result, dict):
        return result
    out = dict(result)
    if isinstance(out.get("player_facing_text"), str):
        out["player_facing_text"] = neutralize_engine_voice_for_player(out["player_facing_text"])
    check = out.get("check_request")
    if isinstance(check, dict) and isinstance(check.get("player_prompt"), str):
        check_out = dict(check)
        check_out["player_prompt"] = neutralize_engine_voice_for_player(check_out["player_prompt"])
        out["check_request"] = check_out
    return out


def _in_scene_npcs(world: Dict[str, Any], scene_id: str) -> list[dict]:
    npcs = world.get("npcs") or []
    if not isinstance(npcs, list):
        return []
    out: list[dict] = []
    for npc in npcs:
        if not isinstance(npc, dict):
            continue
        loc = str(npc.get("location") or npc.get("scene_id") or "").strip()
        if loc and loc != scene_id:
            continue
        out.append(npc)
    return out


def _resolve_target_hint(text: str, session: Dict[str, Any]) -> Optional[str]:
    t = (text or "").strip().lower()
    if not t:
        return None
    # Pronoun-based targeting uses current interaction target.
    if re.search(r"\b(he|him|his|she|her|they|them|that person)\b", t):
        ctx = session.get("interaction_context") or {}
        target_id = str((ctx or {}).get("active_interaction_target_id") or "").strip()
        if target_id:
            return target_id

    # Common phrase captures.
    matchers = (
        r"\bif\s+(.+?)\s+is\s+armed\b",
        r"\bcan\s+(.+?)\s+tell\s+if\b",
        r"\bhow\s+far\s+away\s+is\s+(.+?)\b",
        r"\bwould\s+(.+?)\s+notice\b",
    )
    for pattern in matchers:
        m = re.search(pattern, t)
        if m and m.lastindex:
            hint = (m.group(1) or "").strip(" .?!,")
            if hint:
                return hint
    return None


def _inner_scene(scene: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if not isinstance(scene, dict):
        return {}
    inner = scene.get("scene") if isinstance(scene.get("scene"), dict) else scene
    return inner if isinstance(inner, dict) else {}


def _place_tokens_cover_surface(subject: str, *surfaces: str) -> bool:
    tokens = _place_existence_content_tokens(subject)
    if not tokens:
        return False
    surface_tokens: set[str] = set()
    for surface in surfaces:
        surface_tokens.update(_place_existence_content_tokens(surface))
    if tokens <= surface_tokens:
        return True
    for tok in tokens:
        stem = tok[:-1] if tok.endswith("s") and len(tok) >= 4 else tok
        if stem not in surface_tokens and f"{stem}s" not in surface_tokens:
            return False
    return True


def _strip_present_npc_name_spans(text: str, roster: list[dict]) -> str:
    out = str(text or "")
    names: list[str] = []
    for npc in roster:
        if not isinstance(npc, dict):
            continue
        name = str(npc.get("name") or "").strip()
        if len(name) >= 3:
            names.append(name)
        for ref in (
            list(npc.get("aliases") or [])
            + list(npc.get("address_roles") or [])
        ):
            label = str(ref or "").strip()
            if len(label) >= 3:
                names.append(label)
    names.sort(key=len, reverse=True)
    for name in names:
        out = re.sub(rf"\b{re.escape(name)}\b", " ", out, flags=re.IGNORECASE)
    return out


def _authoritative_nearby_place_evidence(
    subject: str,
    *,
    scene: Dict[str, Any],
    session: Dict[str, Any],
    world: Dict[str, Any],
) -> Optional[Dict[str, str]]:
    """Return current-scene or current-exit evidence for a place subject, or None.

    Historical / off-scene knowledge is not nearby authority.
    """
    inner = _inner_scene(scene)
    if not inner or not str(subject or "").strip():
        return None
    location = str(inner.get("location") or "").strip()
    scene_id = str(inner.get("id") or "").strip()
    if _place_tokens_cover_surface(subject, location, scene_id.replace("_", " ")):
        return {
            "kind": "current_scene",
            "label": location or scene_id.replace("_", " ") or subject,
        }

    interactables = inner.get("interactables") or []
    if isinstance(interactables, list):
        for item in interactables:
            if not isinstance(item, dict):
                continue
            surfaces = [
                str(item.get("label") or "").strip(),
                str(item.get("id") or "").replace("_", " "),
                *[str(alias).strip() for alias in (item.get("aliases") or []) if str(alias).strip()],
            ]
            if _place_tokens_cover_surface(subject, *surfaces):
                label = str(item.get("label") or item.get("id") or subject).strip()
                return {"kind": "current_scene", "label": label}

    from game.scene_destination_binding import (
        known_scene_ids_from_exits,
        resolve_place_phrase_to_exit_target,
    )

    exits = inner.get("exits") or []
    if isinstance(exits, list) and exits:
        core = re.sub(r"^(?:a|an|any|some)\s+", "", subject.strip(), flags=re.IGNORECASE)
        target = resolve_place_phrase_to_exit_target(
            core,
            exits,
            known_scene_ids_from_exits(exits),
        )
        if target:
            label = target.replace("_", " ")
            for exit_row in exits:
                if not isinstance(exit_row, dict):
                    continue
                tid = str(exit_row.get("target_scene_id") or exit_row.get("targetSceneId") or "").strip()
                if tid == target:
                    exit_label = str(exit_row.get("label") or "").strip()
                    if exit_label:
                        label = exit_label
                    break
            return {"kind": "known_destination", "label": label, "target_scene_id": target}

    roster = canonical_scene_addressable_roster(
        world if isinstance(world, dict) else {},
        scene_id,
        scene_envelope=scene if isinstance(scene, dict) else None,
        session=session if isinstance(session, dict) else None,
    )
    facts = inner.get("visible_facts") or []
    if isinstance(facts, list):
        for fact in facts:
            cleaned = _strip_present_npc_name_spans(str(fact or ""), roster)
            if _place_tokens_cover_surface(subject, cleaned):
                return {
                    "kind": "current_scene",
                    "label": location or scene_id.replace("_", " ") or subject,
                }
    return None


def _place_existence_is_person_owned(
    text: str,
    *,
    session: Optional[Dict[str, Any]],
    world: Optional[Dict[str, Any]],
    scene: Optional[Dict[str, Any]],
) -> bool:
    if not _looks_like_place_existence_question(text):
        return False
    subject = extract_place_existence_subject(text) or ""
    return _place_existence_subject_matches_present_person(
        subject,
        session=session if isinstance(session, dict) else None,
        world=world if isinstance(world, dict) else None,
        scene=scene if isinstance(scene, dict) else None,
    )


def classify_adjudication_query(
    text: str,
    *,
    has_active_interaction: bool = False,
    session: Optional[Dict[str, Any]] = None,
    world: Optional[Dict[str, Any]] = None,
    scene: Optional[Dict[str, Any]] = None,
) -> Optional[str]:
    """Classify likely adjudication questions into a small inspectable category set.

    When *has_active_interaction* is True the classifier skips broad feasibility
    patterns that overlap with normal in-character social questioning (e.g.
    "can I …", "can <name> tell if …").  Explicitly mechanical language still
    routes to adjudication regardless.

    When *session*, *world*, and *scene* are provided, directed NPC information
    questions are excluded so they can route to social exchange first.

    Untargeted current-surroundings questions are existing local observation,
    not earshot / NPC-presence adjudication.
    """
    t = (text or "").strip().lower()
    if not t or "?" not in t:
        return None

    # Social-before-adjudication gate (single owner: interaction_context).
    # Mechanics/rules fragments (including extracted parentheticals) must not be captured as social.
    if (
        session is not None
        and world is not None
        and scene is not None
        and isinstance(session, dict)
        and isinstance(world, dict)
        and isinstance(scene, dict)
        and not is_rules_or_engine_mechanics_question(text)
    ):
        entry = resolve_directed_social_entry(
            session=session,
            scene=scene,
            world=world,
            segmented_turn=None,
            raw_text=text,
        )
        if entry.get("should_route_social"):
            return None

    # Untargeted current-surroundings questions are existing observe, not earshot.
    from game.interaction_context import _looks_like_local_observation_question

    if _looks_like_local_observation_question(
        text,
        session=session if isinstance(session, dict) else None,
        scene_envelope=scene if isinstance(scene, dict) else None,
        world=world if isinstance(world, dict) else None,
    ):
        return None

    # Place-existence + locality is world knowledge, not earshot roster presence.
    if _looks_like_place_existence_question(text) and not _place_existence_is_person_owned(
        text,
        session=session,
        world=world,
        scene=scene,
    ):
        return "perception_query"

    # Keep this lane explicitly procedural; do not treat ordinary social language
    # (e.g., "I require an audience.") as a mechanics query.
    has_skill_term = bool(
        re.search(
            r"\b("
            r"sleight of hand|"
            r"stealth|"
            r"perception|"
            r"sense motive|"
            r"diplomacy|"
            r"intimidate|"
            r"bluff|"
            r"thievery"
            r")\b",
            t,
        )
    )
    if has_skill_term and re.search(r"\b(need(?:ed)?|require(?:s|d)?)\b", t):
        return "roll_requirement_query"
    if re.search(
        r"\b("
        r"need(?:\s+to)?\s+roll|"
        r"roll\s+needed|"
        r"does\s+this\s+need|"
        r"does\s+that\s+need|"
        r"require(?:s|d)?\s+(?:a\s+)?(?:roll|check)|"
        r"roll\s+required|"
        r"skill\s+check|"
        r"saving\s+throw|"
        r"\bdc\b|"
        r"difficulty"
        r")\b",
        t,
    ):
        return "roll_requirement_query"
    if re.search(r"\b(what|which)\s+actions?\s+are\s+available\b", t):
        return "state_query"
    if re.search(r"\b(earshot|nearby|who is here|anyone else here|who can hear|in range|distance|how far)\b", t):
        return "perception_query"

    # --- Action feasibility ---
    # Mechanical anchors always qualify regardless of interaction state.
    _MECHANICAL_FEASIBILITY_ANCHORS = re.compile(
        r"\b("
        r"reach|"
        r"range|"
        r"sneak|"
        r"stealth|"
        r"sleight of hand|"
        r"climb|"
        r"jump|"
        r"pick\s+(?:the\s+)?lock|"
        r"disarm|"
        r"grapple|"
        r"swim|"
        r"lift|"
        r"break|"
        r"carry|"
        r"without\s+(?:being\s+)?(?:seen|noticed|detected|heard)"
        r")\b"
    )
    # Feasibility openers: player (I/we) or third-party ("can the door…"), not NPC-directed "can you…".
    _FEASIBILITY_OPENER = re.compile(
        r"\b("
        r"can\s+i\b|could\s+i\b|would\s+i\b|"
        r"can\s+we\b|could\s+we\b|would\s+we\b|"
        r"can\s+(?!you\b|ye\b)\w+|"
        r"could\s+(?!you\b|ye\b)\w+|"
        r"would\s+(?!you\b|ye\b)\w+|"
        r"would it work|is it possible|feasible|can .* tell if"
        r")\b",
        re.IGNORECASE,
    )
    if _FEASIBILITY_OPENER.search(t):
        if _MECHANICAL_FEASIBILITY_ANCHORS.search(t):
            return "action_feasibility_query"
        if not has_active_interaction:
            return "action_feasibility_query"
        # During active interaction, only classify if it contains no social verb
        # that marks it as in-character questioning.
        _SOCIAL_VERB_GUARD = re.compile(
            r"\b("
            r"ask|"
            r"tell|"
            r"say|"
            r"speak|"
            r"convince|"
            r"persuade|"
            r"request|"
            r"inquire|"
            r"question|"
            r"negotiate|"
            r"appeal|"
            r"warn|"
            r"thank|"
            r"greet|"
            r"offer|"
            r"suggest|"
            r"mention|"
            r"explain|"
            r"reply"
            r")\b"
        )
        if not _SOCIAL_VERB_GUARD.search(t):
            return "action_feasibility_query"
        return None

    if re.search(r"\b(is anyone|who is here|what is my|where is my|how many)\b", t):
        return "state_query"
    return None


_FAMILY_CATEGORY = {
    "earshot": "perception_query",
    "nearby_presence": "perception_query",
    "place_location": "perception_query",
    "feasibility": "action_feasibility_query",
    "state_query": "state_query",
    "roll_mechanical": "roll_requirement_query",
    "generic_adjudication": "state_query",
}


def _availability_subject(text: str) -> str:
    """Noun the contract already asked about. Not a route decision."""
    match = re.search(
        r"\b(supplies|shelter|tavern|inn|lodging|water|food)\b",
        str(text or ""),
        re.IGNORECASE,
    )
    if not match:
        return ""
    return str(match.group(1) or "").strip()


def resolve_adjudication_query(
    text: str,
    *,
    scene: Dict[str, Any],
    session: Dict[str, Any],
    world: Dict[str, Any],
    character: Dict[str, Any],
    has_active_interaction: bool = False,
    resolver_family: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    """Resolve an adjudication query from authoritative state only.

    Returns None when text is not an adjudication query.

    ``resolver_family`` is set only after an authoritative Resolution Contract
    has already chosen the family. In that mode the raw text is content for the
    chosen resolver. It does not reclassify the turn, and a place or feasibility
    family cannot fall through into the earshot roster.
    """
    _ = character  # Reserved for future skill/context checks.
    forced = str(resolver_family or "").strip()
    if forced:
        category = _FAMILY_CATEGORY.get(forced)
        if not category:
            return None
    else:
        category = classify_adjudication_query(
            text,
            has_active_interaction=has_active_interaction,
            session=session,
            world=world,
            scene=scene,
        )
        if category is None:
            return None

    scene_id = str(((scene or {}).get("scene") or {}).get("id") or "").strip()
    npcs_here = _in_scene_npcs(world, scene_id)
    universe = addressable_scene_npc_id_universe(session, scene, world)
    roster_addr = canonical_scene_addressable_roster(
        world if isinstance(world, dict) else {},
        scene_id,
        scene_envelope=scene if isinstance(scene, dict) else None,
        session=session if isinstance(session, dict) else None,
    )
    roster_by_id = {
        str(r.get("id") or "").strip(): r
        for r in roster_addr
        if isinstance(r, dict) and str(r.get("id") or "").strip()
    }

    # 1) Roll requirement queries.
    if category == "roll_requirement_query":
        low_text = text.lower()
        covert_attempt = bool(
            re.search(r"\b(conceal|hide|palm|slip|pocket|plant|pass)\b", low_text)
            and re.search(r"\b(while|without|unnoticed|watching|observing|in front of|in plain sight)\b", low_text)
        )
        if covert_attempt:
            prompt = (
                "Adjudication: This is a covert action under observation. "
                "Roll Sleight of Hand to determine whether it goes unnoticed."
            )
            return _finalize_adjudication_result(
                {
                "category": category,
                "answer_type": "check_required",
                "player_facing_text": prompt,
                "requires_check": True,
                "check_request": make_check_request(
                    requires_check=True,
                    check_type="sleight_of_hand",
                    skill="sleight_of_hand",
                    difficulty=None,
                    reason="covert_action_under_observation",
                    player_prompt=prompt,
                ),
                }
            )
        if re.search(r"\b(sleight of hand|stealth|perception|sense motive|diplomacy|intimidate|bluff)\b", text.lower()):
            prompt = "Adjudication: This is uncertain and requires a check. Declare the concrete action/target and resolve it through the engine."
            return _finalize_adjudication_result(
                {
                "category": category,
                "answer_type": "check_required",
                "player_facing_text": prompt,
                "requires_check": True,
                "check_request": make_check_request(
                    requires_check=True,
                    check_type=None,
                    skill=None,
                    difficulty=None,
                    reason="uncertain_action",
                    player_prompt=prompt,
                ),
                }
            )
        return _finalize_adjudication_result(
            {
            "category": category,
            "answer_type": "needs_concrete_action",
            "player_facing_text": "Adjudication: I cannot determine roll requirements yet. State the specific action and target first.",
            "requires_check": None,
            "check_request": None,
            }
        )

    # 2) Place-existence / locality knowledge from current-scene or current-exit authority.
    place_question = _looks_like_place_existence_question(text) and not _place_existence_is_person_owned(
        text,
        session=session,
        world=world,
        scene=scene,
    )
    if forced == "place_location" or (not forced and place_question):
        subject = extract_place_existence_subject(text) or _availability_subject(text) or "that place"
        evidence = _authoritative_nearby_place_evidence(
            subject,
            scene=scene,
            session=session,
            world=world,
        )
        if evidence and evidence.get("kind") == "current_scene":
            label = str(evidence.get("label") or subject).strip() or subject
            return _finalize_adjudication_result(
                {
                    "category": "perception_query",
                    "answer_type": "place_existence",
                    "player_facing_text": f"Adjudication: There is a {label} here.",
                    "requires_check": False,
                    "check_request": None,
                }
            )
        if evidence and evidence.get("kind") == "known_destination":
            label = str(evidence.get("label") or subject).strip() or subject
            return _finalize_adjudication_result(
                {
                    "category": "perception_query",
                    "answer_type": "place_existence",
                    "player_facing_text": (
                        f"Adjudication: There is a nearby destination: {label}."
                    ),
                    "requires_check": False,
                    "check_request": None,
                }
            )
        core = re.sub(r"^(?:a|an|any|some)\s+", "", str(subject or "").strip(), flags=re.IGNORECASE)
        core = core or "that place"
        return _finalize_adjudication_result(
            {
                "category": "perception_query",
                "answer_type": "place_existence_unknown",
                "player_facing_text": (
                    f"Adjudication: No nearby {core} is currently established in this scene."
                ),
                "requires_check": False,
                "check_request": None,
            }
        )

    # 3) Earshot/nearby presence queries from scene state.
    # A contract-selected place, roll, feasibility, or state family must not
    # fall through into this roster because the utterance also contains "nearby".
    presence_tokens = (
        "earshot" in text.lower() or "nearby" in text.lower() or "who can hear" in text.lower()
    )
    if forced in {"earshot", "nearby_presence"} or (not forced and presence_tokens):
        names = [str(n.get("name") or n.get("id") or "").strip() for n in npcs_here]
        names = [n for n in names if n]
        ctx = session.get("interaction_context") or {}
        active_target = str((ctx or {}).get("active_interaction_target_id") or "").strip()
        filtered = []
        for npc in npcs_here:
            nid = str(npc.get("id") or "").strip()
            name = str(npc.get("name") or nid).strip()
            if not name:
                continue
            if active_target and nid == active_target:
                continue
            filtered.append(name)
        if not filtered and universe:
            for uid in sorted(universe):
                if active_target and uid == active_target:
                    continue
                row = roster_by_id.get(uid)
                label = (
                    str((row or {}).get("name") or "").strip()
                    if isinstance(row, dict)
                    else ""
                ) or uid.replace("_", " ").replace("-", " ").title()
                if label:
                    filtered.append(label)
        if filtered:
            return _finalize_adjudication_result(
                {
                "category": "perception_query",
                "answer_type": "direct_answer",
                "player_facing_text": f"Adjudication: In earshot right now: {', '.join(filtered)}.",
                "requires_check": False,
                "check_request": None,
                }
            )
        if names:
            return _finalize_adjudication_result(
                {
                "category": "perception_query",
                "answer_type": "direct_answer",
                "player_facing_text": "Adjudication: No one else is clearly in earshot beyond your current counterpart.",
                "requires_check": False,
                "check_request": None,
                }
            )
        return _finalize_adjudication_result(
            {
            "category": "perception_query",
            "answer_type": "direct_answer",
            "player_facing_text": "Adjudication: No nearby NPC presence is currently established in this scene.",
            "requires_check": False,
            "check_request": None,
            }
        )

    # 3) Armed/distance feasibility or perception checks.
    if re.search(r"\barmed\b", text.lower()) or re.search(r"\bhow far\b|\bdistance\b", text.lower()):
        target_hint = _resolve_target_hint(text, session)
        npc = find_npc_by_target(world, target_hint or "", scene_id) if target_hint else None
        if not npc:
            return _finalize_adjudication_result(
                {
                "category": "action_feasibility_query",
                "answer_type": "needs_concrete_action",
                "player_facing_text": "Adjudication: I need a concrete, in-scene target before I can resolve that.",
                "requires_check": None,
                "check_request": None,
                }
            )
        if "armed" in text.lower():
            armed = npc.get("armed")
            if isinstance(armed, bool):
                armed_text = "is armed" if armed else "does not appear armed"
                return _finalize_adjudication_result(
                    {
                    "category": "action_feasibility_query",
                    "answer_type": "direct_answer",
                    "player_facing_text": f"Adjudication: {npc.get('name') or 'Target'} {armed_text} from established state.",
                    "requires_check": False,
                    "check_request": None,
                    }
                )
            return _finalize_adjudication_result(
                {
                "category": "action_feasibility_query",
                "answer_type": "needs_concrete_action",
                "player_facing_text": "Adjudication: The current state does not establish whether they are armed yet.",
                "requires_check": None,
                "check_request": None,
                }
            )
        if re.search(r"\bhow far\b|\bdistance\b", text.lower()):
            distance = npc.get("distance_ft")
            if isinstance(distance, (int, float)):
                return _finalize_adjudication_result(
                    {
                    "category": "perception_query",
                    "answer_type": "direct_answer",
                    "player_facing_text": f"Adjudication: Estimated distance is about {int(distance)} feet.",
                    "requires_check": False,
                    "check_request": None,
                    }
                )
            return _finalize_adjudication_result(
                {
                "category": "perception_query",
                "answer_type": "needs_concrete_action",
                "player_facing_text": "Adjudication: Distance is not established in authoritative state yet.",
                "requires_check": None,
                "check_request": None,
                }
            )

    # 4) Generic state query fallback.
    return _finalize_adjudication_result(
        {
        "category": category,
        "answer_type": "needs_concrete_action",
        "player_facing_text": "Adjudication: I need a more concrete action or target to resolve that procedurally.",
        "requires_check": None,
        "check_request": None,
        }
    )
