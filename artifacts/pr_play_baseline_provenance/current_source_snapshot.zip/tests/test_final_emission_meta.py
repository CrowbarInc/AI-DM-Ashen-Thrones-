"""Unit tests for :mod:`game.final_emission_meta` (telemetry schema + normalization helpers)."""

from __future__ import annotations

import json

import pytest

from game.final_emission_ownership_schema import (
    VISIBILITY_FALLBACK_OWNER_SEALED_GATE,
    VISIBILITY_FALLBACK_SELECTION_OWNER,
)
from game.final_emission_sealed_fallback import (
    non_strict_sealed_replacement_realization_family_token,
    prepare_sealed_replacement_route_meta,
    stamp_non_strict_sealed_replacement_realization_family,
)
from game.final_emission_replay_projection import (
    OPENING_FALLBACK_CONTENT_OWNER,
    OPENING_FALLBACK_SELECTION_OWNER,
    SANITIZER_FALLBACK_SELECTION_OWNER,
    SANITIZER_STRICT_SOCIAL_CONTENT_OWNER,
    SEALED_FALLBACK_MODULE_CONTENT_OWNER,
    SEALED_FALLBACK_SELECTION_OWNER,
    SEALED_FALLBACK_UNKNOWN_CONTENT_OWNER,
    SEALED_REPLACEMENT_SUBKIND_ANTI_RESET_CONTINUATION,
    SEALED_REPLACEMENT_SUBKIND_GLOBAL_SCENE,
    SEALED_REPLACEMENT_SUBKIND_NPC_PURSUIT_NEUTRAL,
    SEALED_REPLACEMENT_SUBKIND_OPENING,
    SEALED_REPLACEMENT_SUBKIND_PASSIVE_SCENE_PRESSURE,
    SEALED_REPLACEMENT_SUBKIND_SOCIAL_INTERLOCUTOR,
    SEALED_REPLACEMENT_SUBKIND_UNKNOWN,
    SEALED_REPLACEMENT_SUBKINDS,
    STRICT_SOCIAL_FALLBACK_CONTENT_OWNER,
    STRICT_SOCIAL_FALLBACK_SELECTION_OWNER,
    UPSTREAM_FAST_FALLBACK_CONTENT_OWNER,
    UPSTREAM_FAST_FALLBACK_SELECTION_OWNER,
    project_sealed_replacement_subkind_from_fem,
    read_side_lineage_projection_surface,
)
from game.realization_provenance import (
    GATE_TERMINAL_REPAIR,
    REALIZATION_FALLBACK_FAMILY_FIELD,
    STRICT_SOCIAL_DETERMINISTIC_FALLBACK,
)
from game.social_exchange_projection import (
    project_strict_social_replace_realization_family,
    stamp_strict_social_deterministic_fallback_family,
    strict_social_deterministic_fallback_family_token,
)
from game.final_emission_owner_bucket_views import opening_fallback_owner_bucket_from_meta
from game.final_emission_meta import (
    build_narration_constraint_debug,
    default_narration_constraint_debug,
    merge_narration_constraint_debug_meta,
    narration_constraint_reason_codes,
    narration_constraint_small_code,
    narration_constraint_small_str,
    EVALUATOR_FEM_KEY_PREFIX_FAMILIES,
    EMISSION_DEBUG_LANE_KEY,
    FINAL_EMISSION_META_KEY,
    FINAL_EMISSION_MUTATION_LINEAGE_KEY,
    INTERNAL_STATE_KEY,
    NARRATIVE_AUTHENTICITY_FEM_KEYS,
    NARRATIVE_MODE_OUTPUT_FEM_KEYS,
    OPENING_FALLBACK_OWNER_BUCKETS,
    OPENING_FALLBACK_OWNER_RETRY,
    OPENING_FALLBACK_OWNER_SEALED_GATE,
    OPENING_FALLBACK_OWNER_UPSTREAM_PREPARED,
    OPENING_FALLBACK_PROJECTION_FIELDS,
    OPENING_FALLBACK_OUT_OF_BAND_TELEMETRY_FIELDS,
    OPENING_FALLBACK_OUT_OF_BAND_TELEMETRY_RTD_MERGE_FIELDS,
    OPENING_FALLBACK_FAIL_CLOSED_DIAGNOSTIC_FIELDS,
    OPENING_FALLBACK_FAIL_CLOSED_RELATED_RESPONSE_TYPE_DEBUG_FIELDS,
    OPENING_FALLBACK_EMITTED_METADATA_FIELDS,
    OPENING_FALLBACK_RESULT_META_FIELDS,
    opening_fallback_metadata_classification_parity_errors,
    opening_fallback_metadata_field_registry_parity_errors,
    opening_fallback_metadata_field_registry_surface,
    UPSTREAM_FAST_FALLBACK_PROVENANCE_PACKAGER,
    SEMANTIC_MUTATION_WRITE_SITES_KEY,
    append_semantic_mutation_write_site,
    upstream_fast_fallback_provenance_field_registry_parity_errors,
    upstream_fast_fallback_provenance_field_registry_surface,
    SEALED_FALLBACK_OWNER_BUCKETS,
    SEALED_FALLBACK_OWNER_SEALED_GATE,
    VISIBILITY_FALLBACK_OWNER_BUCKETS,
    apply_opening_fallback_projection_fields,
    assemble_unified_observational_telemetry_bundle,
    build_fem_observability_events,
    build_fem_runtime_lineage_events,
    build_narrative_authenticity_emission_trace,
    build_narrative_authenticity_trace_slice,
    default_narrative_authenticity_layer_meta,
    default_narrative_mode_output_layer_meta,
    default_response_type_debug,
    ensure_final_emission_meta_dict,
    final_emission_meta_read_side_surface,
    infer_accept_path_final_emitted_source,
    merge_narrative_authenticity_into_final_emission_meta,
    merge_narrative_mode_output_into_final_emission_meta,
    merge_response_type_meta,
    normalize_final_emission_meta_for_observability,
    normalize_merged_na_telemetry_for_eval,
    opening_fallback_projection_fields,
    package_emission_channel_sidecar,
    normalized_observational_telemetry_bundle,
    patch_final_emission_meta,
    read_emission_debug_lane,
    read_final_emission_meta_dict,
    read_final_emission_meta_from_turn_payload,
    response_type_decision_payload,
    resolve_narrative_authenticity_emission_status,
    slim_na_evidence,
    slim_na_metrics,
    stage_diff_narrative_authenticity_projection,
    stamp_retry_terminal_fallback_producer_metadata,
    stamp_upstream_prepared_opening_producer_metadata,
)
from game.runtime_lineage_telemetry import (
    RUNTIME_LINEAGE_EVENT_FALLBACK_SELECTED,
    RUNTIME_LINEAGE_EVENT_GATE_OUTCOME,
    RUNTIME_LINEAGE_EVENT_MUTATION,
    RUNTIME_LINEAGE_EVENT_SPEAKER_REPAIR,
    RUNTIME_LINEAGE_STAGE_GATE,
    RUNTIME_LINEAGE_STAGE_SANITIZER,
    runtime_lineage_vocabulary_summary,
)
from game.upstream_response_repairs import OPENING_FALLBACK_AUTHORSHIP_UPSTREAM_PREPARED
from tests.helpers.golden_replay_api import (
    assert_runtime_lineage_event_matches,
    expected_runtime_fallback_lineage_event,
)
from tests.helpers.opening_fallback_evidence import (
    fail_closed_opening_fem_meta,
    opening_dual_family_fem_meta,
    successful_opening_fem_meta,
)

from game.narrative_mode_contract import (
    build_narrative_mode_contract,
    build_narrative_mode_emission_trace,
    validate_narrative_mode_output,
)


def test_semantic_mutation_write_site_helper_appends_bounds_and_omits_text() -> None:
    meta: dict[str, object] = {}
    append_semantic_mutation_write_site(
        meta,
        before_text="The guard waits.",
        after_text="The gate is sealed.",
        write_site_family="fallback",
        write_site_file="game/example.py",
        write_site_function="replace_text",
        mutation_reason="unit_test",
        owner="game.example",
        max_records=2,
    )
    append_semantic_mutation_write_site(
        meta,
        before_text="The gate is sealed.",
        after_text="The gate is sealed.",
        write_site_family="fallback",
        write_site_file="game/example.py",
        write_site_function="replace_text",
    )
    append_semantic_mutation_write_site(
        meta,
        before_text="A",
        after_text="B",
        write_site_family="repair",
        write_site_file="game/example.py",
        write_site_function="repair_text",
        max_records=2,
    )
    append_semantic_mutation_write_site(
        meta,
        before_text="B",
        after_text="C",
        write_site_family="final_emission",
        write_site_file="game/example.py",
        write_site_function="finalize",
        max_records=2,
    )

    records = meta[SEMANTIC_MUTATION_WRITE_SITES_KEY]
    assert isinstance(records, list)
    assert len(records) == 2
    assert records[-1]["write_site_family"] == "final_emission"
    assert records[-1]["selected_active_stream"] is True
    assert records[-1]["candidate_only"] is False
    assert "before_text" not in records[-1]
    assert "after_text" not in records[-1]


def test_semantic_mutation_write_site_helper_noops_on_bad_metadata() -> None:
    append_semantic_mutation_write_site(  # type: ignore[arg-type]
        None,
        before_text="A",
        after_text="B",
        write_site_family="fallback",
        write_site_file="game/example.py",
        write_site_function="replace_text",
    )
    malformed = {"semantic_mutation_write_sites": "not-a-list"}
    append_semantic_mutation_write_site(
        malformed,
        before_text="A",
        after_text="B",
        write_site_family="not_allowed",
        write_site_file="game/example.py",
        write_site_function="replace_text",
    )
    assert malformed["semantic_mutation_write_sites"] == "not-a-list"


def test_prepare_sealed_replacement_route_meta_records_selected_fallback_write_site() -> None:
    meta: dict[str, object] = {}
    out = {"player_facing_text": "For a breath, the scene stays still."}
    prepare_sealed_replacement_route_meta(
        meta,
        gm_output=out,
        pre_gate_candidate_text="Validator: internal scaffold.",
        final_emitted_source="minimal_social_emergency_fallback",
        strict_social_route=True,
        composition_meta=None,
    )

    records = meta.get(SEMANTIC_MUTATION_WRITE_SITES_KEY)
    assert isinstance(records, list)
    assert records[-1]["write_site_family"] == "fallback"
    assert records[-1]["write_site_file"] == "game/final_emission_sealed_fallback.py"
    assert records[-1]["candidate_only"] is False
    assert records[-1]["selected_active_stream"] is True


def test_narration_constraint_small_str_rejects_long_and_whitespace() -> None:
    assert narration_constraint_small_str("ok") == "ok"
    assert narration_constraint_small_str("x" * 65) is None
    assert narration_constraint_small_str("bad\nline") is None


def test_narration_constraint_reason_codes_respects_limit() -> None:
    codes = narration_constraint_reason_codes(
        ["a", "b", "c", "d", "e", "f"],
        limit=5,
    )
    assert len(codes) == 5


def test_build_narration_constraint_debug_visibility_reason_cap() -> None:
    payload = build_narration_constraint_debug(
        visibility_meta={
            "visibility_validation_passed": False,
            "visibility_replacement_applied": True,
            "visibility_violation_kinds": [
                "hidden_fact_reference",
                "unseen_entity_reference",
                "hidden_fact_reference",
                "offscene_reference",
                "continuity_bleed",
                "should_not_fit",
            ],
        },
        narration_visibility={"visible_entity_ids": ["a"], "hidden_fact_strings": []},
    )
    assert payload["visibility"]["decision_mode"] == "replaced"
    assert len(payload["visibility"]["reason_codes"]) == 5


def _iter_narration_constraint_strings(value):
    if isinstance(value, str):
        yield value
        return
    if isinstance(value, dict):
        for child in value.values():
            yield from _iter_narration_constraint_strings(child)
        return
    if isinstance(value, list):
        for child in value:
            yield from _iter_narration_constraint_strings(child)


def _assert_narration_constraint_payload_is_compact(payload: dict) -> None:
    assert set(payload) == {"response_type", "visibility", "speaker_selection"}
    assert set(payload["response_type"]) == {
        "required",
        "contract_source",
        "candidate_ok",
        "repair_used",
        "repair_kind",
        "upstream_prepared_absent",
    }
    assert set(payload["visibility"]) == {
        "contract_present",
        "decision_mode",
        "visible_entity_count",
        "withheld_fact_count",
        "reason_codes",
    }
    assert set(payload["speaker_selection"]) == {
        "speaker_id",
        "speaker_name",
        "selection_source",
        "reason_code",
        "binding_confident",
    }
    assert isinstance(payload["visibility"]["reason_codes"], list)
    assert len(payload["visibility"]["reason_codes"]) <= 5
    assert payload["visibility"]["visible_entity_count"] is None or isinstance(
        payload["visibility"]["visible_entity_count"], int
    )
    assert payload["visibility"]["withheld_fact_count"] is None or isinstance(
        payload["visibility"]["withheld_fact_count"], int
    )
    for text in _iter_narration_constraint_strings(payload):
        assert len(text) <= 120


def _assert_payload_omits_sentinels(payload: dict, *sentinels: str) -> None:
    blob = json.dumps(payload, sort_keys=True)
    for sentinel in sentinels:
        assert sentinel not in blob


def test_default_narration_constraint_debug_shape() -> None:
    assert default_narration_constraint_debug() == {
        "response_type": {
            "required": None,
            "contract_source": None,
            "candidate_ok": None,
            "repair_used": False,
            "repair_kind": None,
            "upstream_prepared_absent": None,
        },
        "visibility": {
            "contract_present": False,
            "decision_mode": None,
            "visible_entity_count": None,
            "withheld_fact_count": None,
            "reason_codes": [],
        },
        "speaker_selection": {
            "speaker_id": None,
            "speaker_name": None,
            "selection_source": None,
            "reason_code": None,
            "binding_confident": None,
        },
    }


def test_narration_constraint_debug_builder_and_merge_are_null_safe() -> None:
    payload = build_narration_constraint_debug(
        response_type_debug={
            "response_type_required": "dialogue",
            "response_type_contract_source": "resolution.metadata",
            "response_type_candidate_ok": True,
            "response_type_repair_used": False,
            "response_type_repair_kind": None,
        },
        narration_visibility={
            "visible_entity_ids": ["runner", "guard"],
            "hidden_fact_strings": ["hidden one", "hidden two"],
        },
        visibility_meta={
            "visibility_validation_passed": False,
            "visibility_replacement_applied": True,
            "visibility_violation_kinds": [
                "hidden_fact_reference",
                "unseen_entity_reference",
                "hidden_fact_reference",
                "offscene_reference",
                "continuity_bleed",
                "should_not_fit",
            ],
        },
        speaker_selection_contract={
            "primary_speaker_id": "runner",
            "primary_speaker_name": "Tavern Runner",
            "primary_speaker_source": "continuity",
            "continuity_locked": True,
            "speaker_switch_allowed": False,
            "debug": {"grounding_reason_code": "grounded_in_scene_npc"},
        },
        speaker_contract_enforcement={
            "final_reason_code": "speaker_contract_match",
            "validation": {
                "reason_code": "speaker_contract_match",
                "details": {"signature": {"confidence": "high"}},
            },
        },
    )

    assert payload == {
        "response_type": {
            "required": "dialogue",
            "contract_source": "resolution.metadata",
            "candidate_ok": True,
            "repair_used": False,
            "repair_kind": None,
            "upstream_prepared_absent": None,
        },
        "visibility": {
            "contract_present": True,
            "decision_mode": "replaced",
            "visible_entity_count": 2,
            "withheld_fact_count": 2,
            "reason_codes": [
                "hidden_fact_reference",
                "unseen_entity_reference",
                "offscene_reference",
                "continuity_bleed",
                "should_not_fit",
            ],
        },
        "speaker_selection": {
            "speaker_id": "runner",
            "speaker_name": "Tavern Runner",
            "selection_source": "continuity",
            "reason_code": "speaker_contract_match",
            "binding_confident": True,
        },
    }

    metadata = {
        "other_key": 7,
        "emission_debug": {
            "speaker_contract_enforcement": {"final_reason_code": "speaker_contract_match"},
            "narration_constraint_debug": {
                "speaker_selection": {
                    "speaker_id": "runner",
                    "selection_source": "existing_source",
                }
            },
        },
    }
    merge_narration_constraint_debug_meta(
        metadata,
        {
            "response_type": {"required": "dialogue"},
            "speaker_selection": {"speaker_name": "Tavern Runner"},
        },
    )

    merged = metadata["emission_debug"]["narration_constraint_debug"]
    assert metadata["other_key"] == 7
    assert metadata["emission_debug"]["speaker_contract_enforcement"]["final_reason_code"] == "speaker_contract_match"
    assert merged["response_type"]["required"] == "dialogue"
    assert merged["response_type"]["repair_used"] is False
    assert merged["speaker_selection"]["speaker_id"] == "runner"
    assert merged["speaker_selection"]["selection_source"] == "existing_source"
    assert merged["speaker_selection"]["speaker_name"] == "Tavern Runner"
    assert merged["visibility"]["reason_codes"] == []


def test_narration_constraint_debug_excludes_sensitive_and_verbose_inputs() -> None:
    hidden_fact = "The cult leader's name is Marrow Vale."
    unpublished_clue = "The ledger under the chapel floor names Iven as the courier."
    raw_prompt = "Player prompt fragment: tell me the secret name from the hidden ledger right now."
    candidate_generation = (
        'Candidate generation: Tavern Runner says, "The ledger under the chapel floor names Iven as the courier."'
    )
    contract_dump = (
        'Contract dump: {"allowed_speaker_ids":["runner","guard"],"debug":{"authoritative_source":"prompt"}}'
    )
    roster_dump = "Scene roster: Tavern Runner, Gate Guard, Harbor Priest, Smuggler Lookout, Dock Clerk."
    long_narration = " ".join(["Rain hammers the slate roof while the harbor bells answer the wind."] * 8)

    payload = build_narration_constraint_debug(
        response_type_debug={
            "response_type_required": "dialogue",
            "response_type_contract_source": raw_prompt,
            "response_type_candidate_ok": True,
            "response_type_repair_used": True,
            "response_type_repair_kind": candidate_generation,
        },
        narration_visibility={
            "visible_entity_ids": ["runner", "guard", "priest"],
            "hidden_fact_strings": [hidden_fact, unpublished_clue],
        },
        visibility_meta={
            "visibility_validation_passed": False,
            "visibility_violation_kinds": [
                hidden_fact,
                unpublished_clue,
                raw_prompt,
                candidate_generation,
                contract_dump,
                roster_dump,
                long_narration,
            ],
        },
        speaker_selection_contract={
            "primary_speaker_id": "runner",
            "primary_speaker_name": roster_dump,
            "primary_speaker_source": raw_prompt,
            "debug": {
                "grounding_reason_code": contract_dump,
                "authoritative_source": roster_dump,
            },
        },
        speaker_contract_enforcement={
            "final_reason_code": candidate_generation,
            "validation": {
                "reason_code": unpublished_clue,
                "canonical_speaker_name": long_narration,
                "details": {"signature": {"confidence": "high"}},
            },
        },
        speaker_binding_bridge={
            "speaker_reason_code": contract_dump,
            "malformed_attribution_detected": False,
        },
    )

    assert payload["response_type"]["required"] == "dialogue"
    assert payload["visibility"]["contract_present"] is True
    assert payload["visibility"]["visible_entity_count"] == 3
    assert payload["visibility"]["withheld_fact_count"] == 2
    _assert_narration_constraint_payload_is_compact(payload)
    _assert_payload_omits_sentinels(
        payload,
        hidden_fact,
        unpublished_clue,
        raw_prompt,
        candidate_generation,
        contract_dump,
        roster_dump,
        long_narration,
    )


def test_narration_constraint_debug_speaker_fallback_reason_codes_are_stable() -> None:
    explicit = build_narration_constraint_debug(
        speaker_selection_contract={
            "primary_speaker_id": "runner",
            "primary_speaker_name": "Tavern Runner",
            "primary_speaker_source": "explicit_target",
        }
    )
    assert explicit["speaker_selection"]["reason_code"] == "speaker_from_explicit_target"

    continuity = build_narration_constraint_debug(
        speaker_selection_contract={
            "primary_speaker_id": "runner",
            "primary_speaker_name": "Tavern Runner",
            "primary_speaker_source": "continuity",
        }
    )
    assert continuity["speaker_selection"]["reason_code"] == "speaker_from_continuity"

    unresolved = build_narration_constraint_debug()
    assert unresolved["speaker_selection"]["reason_code"] == "speaker_unresolved"


def test_narration_constraint_debug_prefers_grounded_speaker_reason_code_over_fallbacks() -> None:
    payload = build_narration_constraint_debug(
        speaker_selection_contract={
            "primary_speaker_id": "runner",
            "primary_speaker_name": "Tavern Runner",
            "primary_speaker_source": "continuity",
            "debug": {"grounding_reason_code": "speaker_from_continuity"},
        },
        speaker_contract_enforcement={
            "final_reason_code": "local_rebind",
            "validation": {"details": {"signature": {"confidence": "high"}}},
        },
        speaker_binding_bridge={"speaker_reason_code": "speaker_from_explicit_target"},
    )
    assert payload["speaker_selection"]["reason_code"] == "local_rebind"


def test_narration_constraint_debug_missing_speaker_inputs_do_not_emit_noisy_values() -> None:
    noisy = "Malformed prompt fragment that should never surface in narration_constraint_debug output."
    payload = build_narration_constraint_debug(
        speaker_selection_contract={
            "primary_speaker_source": noisy,
            "debug": {
                "grounding_reason_code": noisy,
                "authoritative_source": noisy,
            },
        },
        speaker_contract_enforcement={
            "validation": {"reason_code": noisy},
        },
        speaker_binding_bridge={"speaker_reason_code": noisy},
    )

    assert payload["speaker_selection"]["speaker_id"] is None
    assert payload["speaker_selection"]["speaker_name"] is None
    assert payload["speaker_selection"]["reason_code"] == "speaker_unresolved"
    _assert_payload_omits_sentinels(payload, noisy)


def test_merge_narration_constraint_debug_meta_triple_sink_is_null_safe_and_preserves_metadata() -> None:
    out_metadata = {
        "top_level_keep": {"ok": True},
        "emission_debug": {
            "existing_out_debug": {"count": 1},
        },
    }
    resolution_metadata = {
        "resolution_keep": {"source": "original"},
        "emission_debug": {"existing_resolution_debug": {"count": 2}},
    }
    effective_metadata = {
        "effective_keep": {"source": "effective"},
        "emission_debug": {"existing_effective_debug": {"count": 3}},
    }

    payload = build_narration_constraint_debug(
        response_type_debug={"response_type_required": "neutral_narration"},
    )
    merge_narration_constraint_debug_meta(out_metadata, payload)
    merge_narration_constraint_debug_meta(resolution_metadata, payload)
    merge_narration_constraint_debug_meta(effective_metadata, payload)

    out_payload = ((out_metadata.get("emission_debug") or {}).get("narration_constraint_debug"))
    res_payload = ((resolution_metadata.get("emission_debug") or {}).get("narration_constraint_debug"))
    eff_payload = ((effective_metadata.get("emission_debug") or {}).get("narration_constraint_debug"))

    assert out_metadata["top_level_keep"] == {"ok": True}
    assert out_metadata["emission_debug"]["existing_out_debug"] == {"count": 1}
    assert resolution_metadata["resolution_keep"] == {"source": "original"}
    assert resolution_metadata["emission_debug"]["existing_resolution_debug"] == {"count": 2}
    assert effective_metadata["effective_keep"] == {"source": "effective"}
    assert effective_metadata["emission_debug"]["existing_effective_debug"] == {"count": 3}
    assert out_payload == res_payload == eff_payload
    assert out_payload["response_type"]["required"] == "neutral_narration"
    assert out_payload["speaker_selection"]["reason_code"] == "speaker_unresolved"
    _assert_narration_constraint_payload_is_compact(out_payload)


def test_stamp_strict_social_deterministic_fallback_family() -> None:
    meta: dict[str, object] = {}
    stamp_strict_social_deterministic_fallback_family(meta)
    assert meta[REALIZATION_FALLBACK_FAMILY_FIELD] == STRICT_SOCIAL_DETERMINISTIC_FALLBACK
    assert strict_social_deterministic_fallback_family_token() == STRICT_SOCIAL_DETERMINISTIC_FALLBACK


def test_project_strict_social_replace_realization_family_defaults_missing() -> None:
    assert (
        project_strict_social_replace_realization_family(None)
        == STRICT_SOCIAL_DETERMINISTIC_FALLBACK
    )
    assert project_strict_social_replace_realization_family("") == STRICT_SOCIAL_DETERMINISTIC_FALLBACK


def test_stamp_non_strict_sealed_replacement_realization_family() -> None:
    meta: dict[str, object] = {}
    stamp_non_strict_sealed_replacement_realization_family(meta)
    assert meta[REALIZATION_FALLBACK_FAMILY_FIELD] == GATE_TERMINAL_REPAIR
    assert meta["sealed_fallback_owner_bucket"] == SEALED_FALLBACK_OWNER_SEALED_GATE
    assert non_strict_sealed_replacement_realization_family_token() == GATE_TERMINAL_REPAIR


def test_infer_accept_path_final_emitted_source_strict_social_initial() -> None:
    assert (
        infer_accept_path_final_emitted_source(
            "normalized_social_candidate",
            response_type_debug={},
        )
        == "normalized_social_candidate"
    )
    assert (
        infer_accept_path_final_emitted_source(
            "",
            response_type_debug={},
        )
        == ""
    )


def test_infer_accept_path_final_emitted_source_generic_initial() -> None:
    assert (
        infer_accept_path_final_emitted_source("generated_candidate", response_type_debug={})
        == "generated_candidate"
    )


def test_infer_accept_path_final_emitted_source_later_layers_win_in_order() -> None:
    layers = {
        "response_type_debug": {
            "response_type_repair_used": True,
            "response_type_repair_kind": "response_type_contract_repair",
        },
        "retry_output": True,
        "ac_layer_meta": {"answer_completeness_repaired": True, "answer_completeness_repair_mode": "ac_mode"},
        "ffnc_layer_meta": {
            "fast_fallback_neutral_composition_repaired": True,
            "fast_fallback_neutral_composition_repair_mode": "ffnc_mode",
        },
    }
    assert (
        infer_accept_path_final_emitted_source(
            "generated_candidate",
            response_type_debug=layers["response_type_debug"],
            retry_output=layers["retry_output"],
            ac_layer_meta=layers["ac_layer_meta"],
            ffnc_layer_meta=layers["ffnc_layer_meta"],
        )
        == "ffnc_mode"
    )


def test_infer_accept_path_final_emitted_source_srs_requires_passed() -> None:
    assert (
        infer_accept_path_final_emitted_source(
            "generated_candidate",
            srs_layer_meta={
                "social_response_structure_repair_applied": True,
                "social_response_structure_passed": False,
                "social_response_structure_repair_mode": "srs_mode",
            },
        )
        == "generated_candidate"
    )
    assert (
        infer_accept_path_final_emitted_source(
            "generated_candidate",
            srs_layer_meta={
                "social_response_structure_repair_applied": True,
                "social_response_structure_passed": True,
                "social_response_structure_repair_mode": "srs_mode",
            },
        )
        == "srs_mode"
    )


def test_infer_accept_path_final_emitted_source_purity_uses_fixed_token() -> None:
    assert (
        infer_accept_path_final_emitted_source(
            "generated_candidate",
            purity_layer_meta={"player_facing_narration_purity_repaired": True},
        )
        == "player_facing_narration_purity_repair"
    )


def test_default_layer_meta_has_all_fem_keys() -> None:
    d = default_narrative_authenticity_layer_meta()
    for k in NARRATIVE_AUTHENTICITY_FEM_KEYS:
        assert k in d


def test_default_narrative_mode_output_layer_meta_covers_registry() -> None:
    d = default_narrative_mode_output_layer_meta()
    assert set(d.keys()) == NARRATIVE_MODE_OUTPUT_FEM_KEYS


def test_evaluator_fem_prefix_registry_includes_acceptance_quality_family() -> None:
    assert "acceptance_quality_" in EVALUATOR_FEM_KEY_PREFIX_FAMILIES


def test_opening_fallback_projection_field_helper_preserves_raw_and_fem_shapes() -> None:
    # Opening fallback owner-bucket boundary: this file owns normalized FEM
    # projection helpers and lineage construction only. Gate selection/path
    # behavior remains in test_final_emission_gate.py, golden replay owns
    # observed-field transport, and the failure classifier owns diagnostics.
    source = {
        "opening_fallback_context_source": "opening_curated_facts",
        "opening_fallback_basis_count": "3",
        "opening_fallback_context_missing": "",
        "opening_fallback_failed_closed": None,
        "opening_curated_facts_present": "yes",
        "opening_curated_facts_count": 3,
        "opening_curated_facts_source": "selector",
        "opening_selector_source_used": "selector",
        "opening_selector_selected_facts": ["gate"],
        "opening_curated_facts": ["gate"],
        "opening_final_fallback_basis": ["gate"],
        "opening_final_basis_matches_selector": True,
        "opening_fallback_authorship_source": OPENING_FALLBACK_AUTHORSHIP_UPSTREAM_PREPARED,
    }

    raw = opening_fallback_projection_fields(source)
    assert set(raw.keys()) == set(OPENING_FALLBACK_PROJECTION_FIELDS)
    assert set(OPENING_FALLBACK_RESULT_META_FIELDS).issubset(set(OPENING_FALLBACK_PROJECTION_FIELDS))
    assert raw["opening_fallback_basis_count"] == "3"
    assert raw["opening_fallback_context_missing"] == ""
    assert raw["opening_fallback_authorship_source"] == OPENING_FALLBACK_AUTHORSHIP_UPSTREAM_PREPARED

    target: dict[str, object] = {"keep": True}
    apply_opening_fallback_projection_fields(
        target,
        source,
        coerce_for_fem=True,
        include_authorship_source=False,
    )
    assert target["keep"] is True
    assert target["opening_fallback_basis_count"] == 3
    assert target["opening_fallback_context_missing"] is False
    assert target["opening_curated_facts_present"] is True
    assert "opening_fallback_authorship_source" not in target


def test_opening_fallback_metadata_field_registry_surface_matches_canonical_constants() -> None:
    assert opening_fallback_metadata_field_registry_parity_errors() == []
    assert opening_fallback_metadata_classification_parity_errors() == []
    surface = opening_fallback_metadata_field_registry_surface()
    assert tuple(surface["opening_fallback_projection_fields"]) == OPENING_FALLBACK_PROJECTION_FIELDS
    assert tuple(surface["opening_fallback_result_meta_fields"]) == OPENING_FALLBACK_RESULT_META_FIELDS
    assert tuple(surface["opening_fallback_out_of_band_telemetry_fields"]) == (
        OPENING_FALLBACK_OUT_OF_BAND_TELEMETRY_FIELDS
    )
    assert tuple(surface["opening_fallback_fail_closed_diagnostic_fields"]) == (
        OPENING_FALLBACK_FAIL_CLOSED_DIAGNOSTIC_FIELDS
    )
    assert tuple(surface["opening_fallback_emitted_metadata_fields"]) == OPENING_FALLBACK_EMITTED_METADATA_FIELDS


def test_opening_fallback_emitted_metadata_fields_partition_is_complete_and_disjoint() -> None:
    """Every emitted opening_fallback_* key belongs to exactly one primary registry."""
    projection = frozenset(OPENING_FALLBACK_PROJECTION_FIELDS)
    telemetry = frozenset(OPENING_FALLBACK_OUT_OF_BAND_TELEMETRY_FIELDS)
    diagnostics = frozenset(OPENING_FALLBACK_FAIL_CLOSED_DIAGNOSTIC_FIELDS)
    assert projection.isdisjoint(telemetry)
    assert projection.isdisjoint(diagnostics)
    assert telemetry.isdisjoint(diagnostics)
    assert projection | telemetry | diagnostics == frozenset(OPENING_FALLBACK_EMITTED_METADATA_FIELDS)
    assert len(OPENING_FALLBACK_EMITTED_METADATA_FIELDS) == len(projection | telemetry | diagnostics)


def test_opening_fallback_out_of_band_telemetry_excluded_from_projection_registry() -> None:
    """Disabled telemetry fields are intentionally outside the canonical projection contract."""
    from game.final_emission_opening_fallback import (
        OPENING_FALLBACK_COMPATIBILITY_LOCAL_DISABLED_KEY,
        OPENING_FALLBACK_LOCAL_COMPOSITION_DISABLED_KEY,
    )

    assert OPENING_FALLBACK_OUT_OF_BAND_TELEMETRY_FIELDS == (
        OPENING_FALLBACK_COMPATIBILITY_LOCAL_DISABLED_KEY,
        OPENING_FALLBACK_LOCAL_COMPOSITION_DISABLED_KEY,
    )
    assert frozenset(OPENING_FALLBACK_OUT_OF_BAND_TELEMETRY_FIELDS).isdisjoint(
        OPENING_FALLBACK_PROJECTION_FIELDS
    )
    assert frozenset(OPENING_FALLBACK_OUT_OF_BAND_TELEMETRY_FIELDS).isdisjoint(
        OPENING_FALLBACK_RESULT_META_FIELDS
    )


def test_opening_fallback_local_composition_disabled_is_composition_meta_only_not_rtd_merged() -> None:
    """CK Block 9: alias is out-of-band telemetry but intentionally absent from RTD→FEM merge."""
    from game.final_emission_opening_fallback import (
        OPENING_FALLBACK_COMPATIBILITY_LOCAL_DISABLED_KEY,
        OPENING_FALLBACK_LOCAL_COMPOSITION_DISABLED_KEY,
    )

    assert OPENING_FALLBACK_OUT_OF_BAND_TELEMETRY_RTD_MERGE_FIELDS == (
        OPENING_FALLBACK_COMPATIBILITY_LOCAL_DISABLED_KEY,
    )
    assert OPENING_FALLBACK_LOCAL_COMPOSITION_DISABLED_KEY in OPENING_FALLBACK_OUT_OF_BAND_TELEMETRY_FIELDS
    assert OPENING_FALLBACK_LOCAL_COMPOSITION_DISABLED_KEY not in (
        OPENING_FALLBACK_OUT_OF_BAND_TELEMETRY_RTD_MERGE_FIELDS
    )

    dbg = default_response_type_debug({"required_response_type": "scene_opening"}, "resolution.metadata")
    assert OPENING_FALLBACK_COMPATIBILITY_LOCAL_DISABLED_KEY in dbg
    assert dbg[OPENING_FALLBACK_COMPATIBILITY_LOCAL_DISABLED_KEY] is False
    assert OPENING_FALLBACK_LOCAL_COMPOSITION_DISABLED_KEY not in dbg

    dbg[OPENING_FALLBACK_COMPATIBILITY_LOCAL_DISABLED_KEY] = True
    dbg[OPENING_FALLBACK_LOCAL_COMPOSITION_DISABLED_KEY] = True
    fem: dict = {}
    merge_response_type_meta(fem, dbg)
    assert fem[OPENING_FALLBACK_COMPATIBILITY_LOCAL_DISABLED_KEY] is True
    assert OPENING_FALLBACK_LOCAL_COMPOSITION_DISABLED_KEY not in fem


def test_opening_fallback_rtd_merge_quarantine_parity_errors_empty() -> None:
    """Registry parity locks composition-meta-only alias outside RTD merge defaults."""
    assert opening_fallback_metadata_classification_parity_errors() == []
    surface = opening_fallback_metadata_field_registry_surface()
    assert tuple(surface["opening_fallback_out_of_band_telemetry_rtd_merge_fields"]) == (
        OPENING_FALLBACK_OUT_OF_BAND_TELEMETRY_RTD_MERGE_FIELDS
    )


def test_apply_opening_fallback_projection_fields_omits_out_of_band_telemetry() -> None:
    """Projection copy helpers must not absorb telemetry-only disabled flags."""
    source = {
        "opening_fallback_context_source": "opening_curated_facts",
        "opening_fallback_basis_count": 1,
        "opening_fallback_context_missing": False,
        "opening_fallback_failed_closed": True,
        "opening_curated_facts_present": True,
        "opening_curated_facts_count": 1,
        "opening_curated_facts_source": "selector",
        "opening_selector_source_used": "selector",
        "opening_selector_selected_facts": ["gate"],
        "opening_curated_facts": ["gate"],
        "opening_final_fallback_basis": ["gate"],
        "opening_final_basis_matches_selector": True,
        "opening_fallback_authorship_source": None,
        "opening_fallback_compatibility_local_disabled": True,
        "opening_fallback_local_composition_disabled": True,
    }
    projected = opening_fallback_projection_fields(source)
    for key in OPENING_FALLBACK_OUT_OF_BAND_TELEMETRY_FIELDS:
        assert key not in projected
    for key in OPENING_FALLBACK_FAIL_CLOSED_DIAGNOSTIC_FIELDS:
        assert key not in projected


def test_apply_opening_fallback_projection_fields_omits_fail_closed_diagnostics() -> None:
    """Projection helpers must not absorb fail-closed diagnostic-only fields."""
    source = dict.fromkeys(OPENING_FALLBACK_EMITTED_METADATA_FIELDS, True)
    projected = opening_fallback_projection_fields(source)
    for key in OPENING_FALLBACK_FAIL_CLOSED_DIAGNOSTIC_FIELDS:
        assert key not in projected
    for key in OPENING_FALLBACK_OUT_OF_BAND_TELEMETRY_FIELDS:
        assert key not in projected
    assert set(projected.keys()) == set(OPENING_FALLBACK_PROJECTION_FIELDS)


def test_merge_response_type_meta_preserves_fail_closed_diagnostic_defaults() -> None:
    """Response-type debug merge remains backward compatible for fail-closed diagnostics."""
    dbg = default_response_type_debug({"required_response_type": "scene_opening"}, "resolution.metadata")
    for key in OPENING_FALLBACK_FAIL_CLOSED_DIAGNOSTIC_FIELDS:
        assert dbg.get(key) is False
    for key in OPENING_FALLBACK_FAIL_CLOSED_RELATED_RESPONSE_TYPE_DEBUG_FIELDS:
        assert dbg.get(key) is None

    dbg["opening_fallback_failed_closed"] = True
    dbg["opening_fallback_missing_upstream_prepared_payload"] = True
    dbg["opening_fallback_missing_curated_facts"] = True
    dbg["blocked_repair_kind"] = "opening_missing_curated_facts"
    fem: dict = {}
    merge_response_type_meta(fem, dbg)
    assert fem["opening_fallback_failed_closed"] is True
    assert fem["opening_fallback_missing_upstream_prepared_payload"] is True
    assert fem["opening_fallback_missing_curated_facts"] is True
    assert fem["blocked_repair_kind"] == "opening_missing_curated_facts"


def test_build_opening_fallback_result_meta_keys_match_registry() -> None:
    from game.final_emission_opening_fallback import build_opening_fallback_result_meta

    fail_closed = build_opening_fallback_result_meta(context=None)
    assert set(fail_closed.keys()) == set(OPENING_FALLBACK_RESULT_META_FIELDS)

    context_meta = build_opening_fallback_result_meta(
        context={
            "opening_fallback_context_source": "opening_curated_facts",
            "visible_facts": ["Rain on stone."],
            "opening_curated_facts_source": "realization",
            "opening_selector_source_used": "realization",
            "opening_selector_selected_facts": ["Rain on stone."],
            "opening_curated_facts": ["Rain on stone."],
            "opening_final_fallback_basis": ["Rain on stone."],
            "opening_final_basis_matches_selector": True,
        }
    )
    assert set(context_meta.keys()) == set(OPENING_FALLBACK_RESULT_META_FIELDS)


def test_upstream_fast_fallback_provenance_field_registry_surface_matches_canonical_constants() -> None:
    assert upstream_fast_fallback_provenance_field_registry_parity_errors() == []
    surface = upstream_fast_fallback_provenance_field_registry_surface()
    assert surface["provenance_packager"] == UPSTREAM_FAST_FALLBACK_PROVENANCE_PACKAGER
    assert surface["selection_owner"] == UPSTREAM_FAST_FALLBACK_SELECTION_OWNER
    assert surface["content_owner"] == UPSTREAM_FAST_FALLBACK_CONTENT_OWNER


def test_merge_narrative_mode_output_into_final_emission_meta() -> None:
    c = build_narrative_mode_contract(narration_obligations={"is_opening_scene": True})
    v = validate_narrative_mode_output("As before, the gate waits.", c)
    trace = build_narrative_mode_emission_trace(v, narrative_mode_contract=c)
    fem: dict = {"final_route": "accept_candidate"}
    merge_narrative_mode_output_into_final_emission_meta(fem, trace)
    assert fem["final_route"] == "accept_candidate"
    assert fem.get("narrative_mode_output_checked") is True
    assert fem.get("narrative_mode_output_passed") is False
    assert isinstance(fem.get("narrative_mode_output_failure_reasons"), list)


def test_merge_into_final_emission_meta_round_trip() -> None:
    fem: dict = {"final_route": "accept_candidate"}
    na = default_narrative_authenticity_layer_meta()
    na["narrative_authenticity_checked"] = True
    na["narrative_authenticity_failed"] = False
    na["narrative_authenticity_reason_codes"] = []
    na["narrative_authenticity_metrics"] = {"generic_filler_score": 0.1}
    merge_narrative_authenticity_into_final_emission_meta(fem, na)
    assert fem["narrative_authenticity_checked"] is True
    assert fem["final_route"] == "accept_candidate"


def test_emission_trace_terminal_statuses() -> None:
    contract = {"trace": {"rumor_turn_active": True, "rumor_turn_reason_codes": ["player_text:lex_rumor"]}}
    v_pass = {"checked": True, "passed": True, "failure_reasons": [], "metrics": {"rumor_turn_active": True}}
    t_pass = build_narrative_authenticity_emission_trace(v_pass, contract=contract)
    assert t_pass.get("narrative_authenticity_status") == "pass"
    assert "narrative_authenticity_metrics" in t_pass
    assert (t_pass.get("narrative_authenticity_trace") or {}).get("rumor_turn_active") is True

    v_relaxed = {
        **v_pass,
        "rumor_realism_relaxed_low_signal": True,
        "rumor_realism_relaxation_flags": {"brevity_alone": True},
    }
    t_relaxed = build_narrative_authenticity_emission_trace(v_relaxed, contract=contract)
    assert t_relaxed.get("narrative_authenticity_status") == "relaxed"
    assert t_relaxed.get("narrative_authenticity_rumor_relaxed_low_signal") is True

    v1 = {"checked": True, "passed": True, "failure_reasons": [], "metrics": {}}
    t_rep = build_narrative_authenticity_emission_trace(v1, contract=None, repaired=True, repair_mode="drop_adjacent_redundant_sentence")
    assert t_rep.get("narrative_authenticity_status") == "repaired"
    assert t_rep.get("narrative_authenticity_repair_modes") == ["drop_adjacent_redundant_sentence"]

    v_fail = {"checked": True, "passed": False, "failure_reasons": ["low_signal_generic_reply"], "metrics": {}}
    t_fail = build_narrative_authenticity_emission_trace(v_fail, contract=None, repaired=False, repair_failed=True)
    assert t_fail.get("narrative_authenticity_status") == "fail"
    assert "low_signal_generic_reply" in (t_fail.get("narrative_authenticity_reason_codes") or [])


def test_resolve_status_checked_failure_pre_repair_is_none() -> None:
    v = {"checked": True, "passed": False, "failure_reasons": ["x"], "metrics": {}}
    assert resolve_narrative_authenticity_emission_status(v, repaired=False, repair_failed=False) is None


def test_slim_helpers_stable() -> None:
    assert slim_na_metrics({"a": 1.234567, "b": None, "c": "ok"}) == {"a": 1.2346, "c": "ok"}
    ev = slim_na_evidence({"long": "x" * 200, "lst": list(range(10))})
    assert str(ev["long"]).endswith("…")
    assert len(ev["lst"]) <= 6


def test_trace_slice_contract_only() -> None:
    c = {"trace": {"rumor_turn_active": True, "rumor_trigger_spans": ["a", "b", "c", "d", "e", "f", "g"]}}
    sl = build_narrative_authenticity_trace_slice(None, contract=c)
    assert sl["rumor_turn_active"] is True
    assert len(sl.get("rumor_trigger_spans") or []) <= 6


def test_normalize_merged_na_for_eval_fills_none_nested() -> None:
    raw = {"narrative_authenticity_checked": True, "narrative_authenticity_metrics": None}
    n = normalize_merged_na_telemetry_for_eval(raw)
    assert n["narrative_authenticity_metrics"] == {}
    assert n["narrative_authenticity_trace"] == {}
    # Original mapping unchanged
    assert raw.get("narrative_authenticity_metrics") is None


def test_response_type_debug_defaults_and_fem_merge_are_stable() -> None:
    dbg = default_response_type_debug({"required_response_type": "dialogue"}, "resolution.metadata")
    expected_stable = {
        "response_type_required": "dialogue",
        "response_type_contract_source": "resolution.metadata",
        "response_type_candidate_ok": True,
        "response_type_repair_used": False,
        "response_type_repair_kind": None,
        "response_type_rejection_reasons": [],
        "non_hostile_escalation_blocked": False,
        "opening_generic_action_repair_blocked": False,
        "opening_specific_repair_used": False,
        "opening_validation_failed": False,
        "opening_failure_reasons": [],
        "opening_recovered_via_fallback": False,
        "opening_fallback_context_source": None,
        "opening_fallback_basis_count": 0,
        "opening_fallback_context_missing": False,
        "opening_fallback_failed_closed": False,
        "blocked_repair_kind": None,
        "opening_repair_source": "not_opening",
        "response_type_upstream_prepared_absent": False,
        "upstream_prepared_emission_used": False,
        "upstream_prepared_emission_valid": False,
        "upstream_prepared_emission_source": None,
        "upstream_prepared_emission_reject_reason": None,
        "final_emission_boundary_repair_used": False,
        "final_emission_boundary_semantic_repair_disabled": True,
        "fallback_family_used": None,
        "fallback_temporal_frame": None,
    }
    for key, value in expected_stable.items():
        assert dbg.get(key) == value
    assert {
        "opening_fallback_compatibility_local_disabled": False,
        "opening_fallback_missing_upstream_prepared_payload": False,
        "opening_fallback_missing_curated_facts": False,
        "opening_fallback_upstream_payload_unusable": False,
        "opening_fallback_upstream_payload_recovered": False,
        "opening_upstream_prepare_attach_build_failed": False,
        "opening_upstream_prepare_attach_failure_exc_type": None,
        "opening_upstream_prepare_attach_no_usable_payload_after_attempt": False,
        "opening_fallback_authorship_source": None,
    }.items() <= dbg.items()

    fem: dict = {"final_route": "accept_candidate"}
    merge_response_type_meta(fem, dbg)
    assert fem["final_route"] == "accept_candidate"
    assert fem["response_type_required"] == "dialogue"
    assert fem["response_type_contract_source"] == "resolution.metadata"
    assert fem["response_type_candidate_ok"] is True
    assert fem["response_type_repair_used"] is False
    assert fem["response_type_repair_kind"] is None
    assert fem["response_type_rejection_reasons"] == []
    assert fem["non_hostile_escalation_blocked"] is False
    assert fem["opening_validation_failed"] is False
    assert fem["opening_fallback_basis_count"] == 0
    assert fem["fallback_family_used"] is None
    assert fem["fallback_temporal_frame"] is None
    assert fem["response_type_upstream_prepared_absent"] is False
    assert fem["upstream_prepared_emission_used"] is False
    assert fem["upstream_prepared_emission_valid"] is False
    assert fem["upstream_prepared_emission_source"] is None
    assert fem["upstream_prepared_emission_reject_reason"] is None
    assert fem["final_emission_boundary_repair_used"] is False
    assert fem["final_emission_boundary_semantic_repair_disabled"] is True

    # Payload used by trace/log sinks is canonical and shallow.
    payload = response_type_decision_payload(dbg)
    for key, value in expected_stable.items():
        assert payload.get(key) == value
    assert {
        "opening_fallback_compatibility_local_disabled": False,
        "opening_fallback_missing_upstream_prepared_payload": False,
        "opening_fallback_missing_curated_facts": False,
        "opening_fallback_upstream_payload_unusable": False,
        "opening_fallback_upstream_payload_recovered": False,
        "opening_upstream_prepare_attach_build_failed": False,
        "opening_upstream_prepare_attach_failure_exc_type": None,
        "opening_upstream_prepare_attach_no_usable_payload_after_attempt": False,
        "opening_fallback_authorship_source": None,
    }.items() <= payload.items()


def test_read_helpers_prefer_sidecar_lane_over_legacy_top_level() -> None:
    gm = {
        "_final_emission_meta": {"from": "legacy"},
        INTERNAL_STATE_KEY: {EMISSION_DEBUG_LANE_KEY: {FINAL_EMISSION_META_KEY: {"from": "sidecar"}}},
    }
    assert read_final_emission_meta_dict(gm) == {"from": "sidecar"}

    # Legacy-only fallback still works for mixed fixtures.
    assert read_final_emission_meta_dict({"_final_emission_meta": {"k": 1}}) == {"k": 1}
    assert read_final_emission_meta_dict({}) == {}


def test_package_emission_channel_sidecar_omits_empty() -> None:
    assert package_emission_channel_sidecar(debug_top_level={}, author_top_level={}) == {}
    assert package_emission_channel_sidecar(debug_top_level=None, author_top_level=None) == {}


def test_read_final_emission_meta_from_turn_payload_supports_api_envelope_and_gm_output_dict() -> None:
    payload = {
        "gm_output": {"player_facing_text": "x"},
        "gm_output_debug": {
            EMISSION_DEBUG_LANE_KEY: {
                FINAL_EMISSION_META_KEY: {"narrative_authenticity_checked": True},
            }
        },
    }
    assert read_final_emission_meta_from_turn_payload(payload).get("narrative_authenticity_checked") is True

    gm_output_only = {
        "player_facing_text": "x",
        INTERNAL_STATE_KEY: {EMISSION_DEBUG_LANE_KEY: {FINAL_EMISSION_META_KEY: {"final_route": "accept_candidate"}}},
    }
    assert read_final_emission_meta_from_turn_payload(gm_output_only).get("final_route") == "accept_candidate"


def test_read_emission_debug_lane_reads_sidecar_lane_when_present() -> None:
    gm = {INTERNAL_STATE_KEY: {EMISSION_DEBUG_LANE_KEY: {"debug_notes": "hi", FINAL_EMISSION_META_KEY: {"k": 2}}}}
    lane = read_emission_debug_lane(gm)
    assert lane.get("debug_notes") == "hi"
    assert isinstance(lane.get(FINAL_EMISSION_META_KEY), dict)


def test_normalize_final_emission_meta_for_observability_fills_nested_defaults_deterministically() -> None:
    fem = {
        "narrative_authenticity_metrics": None,
        "narrative_authenticity_trace": None,
        "narrative_authenticity_evidence": None,
        "narrative_authenticity_relaxation_flags": None,
        "narrative_authenticity_reason_codes": None,
        "narrative_authenticity_failure_reasons": "not-a-list",
        "dead_turn": None,
    }
    n = normalize_final_emission_meta_for_observability(fem)
    assert isinstance(n["dead_turn"], dict)
    assert n["dead_turn"]["is_dead_turn"] is False
    assert n["narrative_authenticity_metrics"] == {}
    assert n["narrative_authenticity_trace"] == {}
    assert n["narrative_authenticity_evidence"] == {}
    assert n["narrative_authenticity_relaxation_flags"] == {}
    assert n["narrative_authenticity_failure_reasons"] == []
    # reason_codes None is treated as absent (no forced list insertion)
    assert "narrative_authenticity_reason_codes" in n


def test_stage_diff_na_projection_merges_failure_reasons_into_reason_codes() -> None:
    fem = {
        "narrative_authenticity_failure_reasons": ["gate_reason"],
        "narrative_authenticity_reason_codes": ["packaged", "gate_reason"],
        "narrative_authenticity_status": "pass",
    }
    proj = stage_diff_narrative_authenticity_projection(fem)
    assert proj["narrative_authenticity_reason_codes"] == ["packaged", "gate_reason"]
    assert "narrative_authenticity_failure_reasons" not in proj


def test_stage_diff_na_projection_is_curated_and_does_not_pass_through_nested_payloads() -> None:
    fem = {
        "narrative_authenticity_status": "pass",
        "narrative_authenticity_reason_codes": ["a", "  ", 1],
        "narrative_authenticity_trace": {"rumor_turn_active": True, "extra": {"nested": "nope"}},
        # Should not pass through nested dict values.
        "narrative_authenticity_metrics": {"x": 1},
        "narrative_authenticity_evidence": {"y": 2},
        # Unknown key should not surface.
        "narrative_authenticity_private_blob": {"z": 3},
    }
    proj = stage_diff_narrative_authenticity_projection(fem)
    assert proj["narrative_authenticity_status"] == "pass"
    assert proj["narrative_authenticity_reason_codes"] == ["a", "1"]
    assert proj["rumor_turn_active"] is True
    assert "narrative_authenticity_metrics" not in proj
    assert "narrative_authenticity_evidence" not in proj
    assert "narrative_authenticity_private_blob" not in proj


def test_normalized_observational_bundle_has_stable_top_level_shapes() -> None:
    payload = {
        "gm_output": {"player_facing_text": "x"},
        "gm_output_debug": {
            EMISSION_DEBUG_LANE_KEY: {
                "debug_notes": "note",
                FINAL_EMISSION_META_KEY: {"dead_turn": {"is_dead_turn": True, "validation_playable": False}},
                "extra_lane_key": 1,
            }
        },
    }
    b = normalized_observational_telemetry_bundle(payload)
    assert set(b) == {
        "final_emission_meta",
        "dead_turn",
        "debug_notes",
        "stage_diff_na_projection",
        "emission_debug_lane_keys",
    }
    assert b["debug_notes"] == "note"
    assert isinstance(b["final_emission_meta"], dict)
    assert isinstance(b["dead_turn"], dict)
    assert b["dead_turn"]["is_dead_turn"] is True
    assert b["dead_turn"]["validation_playable"] is False
    assert isinstance(b["stage_diff_na_projection"], dict)
    assert sorted(b["emission_debug_lane_keys"]) == b["emission_debug_lane_keys"]
    assert FINAL_EMISSION_META_KEY in b["emission_debug_lane_keys"]


def test_build_fem_observability_events_bounded_curated_and_stable() -> None:
    fem = {
        "narrative_authenticity_checked": True,
        "narrative_authenticity_failed": False,
        "narrative_authenticity_reason_codes": ["a", "a"],
        "answer_completeness_checked": True,
        "answer_completeness_failed": False,
        "response_delta_checked": True,
        "response_delta_echo_overlap_ratio": 0.25,
        "fallback_behavior_checked": True,
        "fallback_behavior_contract_present": True,
        "response_type_required": "dialogue",
        "response_type_candidate_ok": True,
        "response_type_rejection_reasons": ["x"],
        "dead_turn": {"is_dead_turn": False, "dead_turn_class": "none"},
        "secret_blob": {"nested": "should-not-appear"},
        "narrative_authenticity_metrics": {"heavy": "payload"},
    }
    ev1 = build_fem_observability_events(fem)
    ev2 = build_fem_observability_events(fem)
    assert ev1 == ev2
    assert len(ev1) == 6
    owners = [e["owner"] for e in ev1]
    assert owners == [
        "narrative_authenticity",
        "answer_completeness",
        "response_delta",
        "fallback_behavior",
        "response_type",
        "dead_turn",
    ]
    for e in ev1:
        assert set(e.keys()) == {"phase", "owner", "action", "reasons", "scope", "data"}
        assert e["phase"] == "gate"
        assert e["scope"] == "turn"
        assert "secret_blob" not in e["data"]
    na = ev1[0]
    assert na["owner"] == "narrative_authenticity"
    assert na["data"].keys() <= {
        "checked",
        "failed",
        "repaired",
        "status",
        "skip_reason",
        "rumor_relaxed_low_signal",
    }
    assert "metrics" not in na["data"]
    assert na["reasons"] == ["a"]


def test_build_fem_observability_events_malformed_fem_does_not_crash() -> None:
    assert build_fem_observability_events(None) == []
    assert build_fem_observability_events([]) == []
    assert build_fem_observability_events({}) == []


def test_assemble_unified_bundle_stage_diff_surface_keys_sorted() -> None:
    fem = {"dead_turn": {"is_dead_turn": False, "dead_turn_class": "none"}}
    stage_diff = {
        "transitions": [{"from": "a", "to": "b", "diff": {"route_changed": True}}],
        "snapshots": [{"stage": "s"}],
    }
    b = assemble_unified_observational_telemetry_bundle(fem=fem, stage_diff=stage_diff, evaluator_result=None)
    assert list(b["stage_diff_surface"].keys()) == ["snapshots", "transitions"]


def test_assemble_unified_observational_telemetry_bundle_merges_three_sources_without_leakage() -> None:
    fem = {
        "narrative_authenticity_checked": True,
        "narrative_authenticity_failed": False,
        "dead_turn": {"is_dead_turn": False, "dead_turn_class": "none"},
    }
    stage_diff = {
        "snapshots": [{"stage": "s", "final_route": "accept"}],
        "transitions": [{"from": "a", "to": "b", "diff": {"route_changed": True}}],
        "prior_custom": {"secret": "must_not_surface"},
    }
    evaluator_result = {
        "passed": True,
        "narrative_authenticity_verdict": "clean_pass",
        "scores": {"signal_gain": 5},
        "reasons": [],
        "gameplay_validation": {"excluded_from_scoring": False},
    }
    b = assemble_unified_observational_telemetry_bundle(
        fem=fem,
        stage_diff=stage_diff,
        evaluator_result=evaluator_result,
    )
    assert set(b.keys()) == {
        "final_emission_meta",
        "fem_observability_events",
        "fem_runtime_lineage_events",
        "stage_diff_observability_events",
        "evaluator_observability_events",
        "stage_diff_surface",
    }
    assert isinstance(b["final_emission_meta"], dict)
    assert b["fem_observability_events"]
    assert b["fem_runtime_lineage_events"] == []
    assert b["stage_diff_observability_events"]
    assert b["evaluator_observability_events"]
    assert "prior_custom" not in b["stage_diff_surface"]
    assert set(b["stage_diff_surface"].keys()) <= {"snapshots", "transitions"}
    ev0 = b["evaluator_observability_events"][0]
    assert ev0["phase"] == "evaluator"
    assert "scores" not in ev0["data"]


def test_assemble_unified_observational_telemetry_bundle_optional_inputs_safe() -> None:
    b = assemble_unified_observational_telemetry_bundle(fem=None, stage_diff=None, evaluator_result=None)
    assert b["stage_diff_observability_events"] == []
    assert b["evaluator_observability_events"] == []
    assert b["fem_runtime_lineage_events"] == []
    assert b["stage_diff_surface"] == {}
    assert isinstance(b["fem_observability_events"], list)
    assert isinstance(b["final_emission_meta"], dict)
    # Normalized FEM always materializes ``dead_turn`` defaults, which yields a single dead_turn FEM event.
    assert all(e.get("owner") != "stage_diff_telemetry" for e in b["fem_observability_events"])


def test_build_fem_observability_events_no_arbitrary_pass_through_in_data() -> None:
    fem = {
        "narrative_authenticity_checked": True,
        "narrative_authenticity_evidence": {"should": "not leak"},
    }
    ev = build_fem_observability_events(fem)
    assert len(ev) == 1
    assert "evidence" not in ev[0]["data"]


def _lineage_event(events: list[dict], event_kind: str) -> dict:
    return next(event for event in events if event["event_kind"] == event_kind)


def test_build_fem_runtime_lineage_events_acceptance_outcomes_do_not_invent_fallbacks() -> None:
    unchanged = build_fem_runtime_lineage_events(
        {
            "final_route": "accept_candidate",
            "final_emitted_source": "generated_candidate",
            "post_gate_mutation_detected": False,
        }
    )
    assert [event["event_kind"] for event in unchanged] == ["gate_outcome"]
    assert unchanged[0]["gate_path"] == "accept_unchanged"

    repaired = build_fem_runtime_lineage_events(
        {
            "final_route": "accept_candidate",
            "final_emitted_source": "response_delta_repair",
            "post_gate_mutation_detected": True,
        }
    )
    assert _lineage_event(repaired, "gate_outcome")["gate_path"] == "accept_repaired"
    assert not any(event["event_kind"] == "fallback_selected" for event in repaired)


def test_build_fem_runtime_lineage_events_projects_opening_and_fail_closed_fallbacks() -> None:
    # Meta/lineage owner: exact owner buckets are asserted here because this is
    # where FEM fields become runtime-lineage events, not because this suite owns
    # final-gate fallback selection behavior.
    opening_meta = successful_opening_fem_meta(final_route="accept_candidate")
    opening = build_fem_runtime_lineage_events(opening_meta)
    assert opening_fallback_owner_bucket_from_meta(opening_meta) == OPENING_FALLBACK_OWNER_UPSTREAM_PREPARED
    opening_selected = _lineage_event(opening, "fallback_selected")
    # P1 owner vocabulary: runtime-lineage owner remains selector/application owner for now.
    # Content/prose ownership is preserved separately via fallback attribution fields.
    assert_runtime_lineage_event_matches(
        opening_selected,
        expected_runtime_fallback_lineage_event(
            fallback_kind="scene_opening",
            owner="game.final_emission_gate",
            fallback_selection_owner="game.final_emission_gate",
            fallback_content_owner="game.opening_deterministic_fallback",
            fallback_authorship_source=OPENING_FALLBACK_AUTHORSHIP_UPSTREAM_PREPARED,
            fallback_owner_bucket=OPENING_FALLBACK_OWNER_UPSTREAM_PREPARED,
        ),
    )
    assert _lineage_event(opening, "gate_outcome")["gate_path"] == "opening_fallback"

    failed_closed_meta = fail_closed_opening_fem_meta(final_route="replaced", opening_fallback_failed_closed=True)
    failed_closed = build_fem_runtime_lineage_events(failed_closed_meta)
    assert opening_fallback_owner_bucket_from_meta(failed_closed_meta) == OPENING_FALLBACK_OWNER_SEALED_GATE
    failed_closed_selected = _lineage_event(failed_closed, "fallback_selected")
    assert_runtime_lineage_event_matches(
        failed_closed_selected,
        expected_runtime_fallback_lineage_event(
            fallback_kind="opening_failed_closed",
            owner="game.final_emission_gate",
            fallback_selection_owner="game.final_emission_gate",
            fallback_content_owner="game.final_emission_gate",
            fallback_authorship_source=None,
            fallback_owner_bucket=OPENING_FALLBACK_OWNER_SEALED_GATE,
        ),
    )
    assert _lineage_event(failed_closed, "gate_outcome")["gate_path"] == "opening_failed_closed"
    assert opening_selected["fallback_kind"] != failed_closed_selected["fallback_kind"]


def test_build_fem_runtime_lineage_events_projects_strict_social_and_sanitizer_fallbacks() -> None:
    strict_social = build_fem_runtime_lineage_events(
        {
            "final_route": "replaced",
            "strict_social_active": True,
            "final_emitted_source": "deterministic_social_fallback",
        }
    )
    strict_selected = _lineage_event(strict_social, "fallback_selected")
    assert_runtime_lineage_event_matches(
        strict_selected,
        expected_runtime_fallback_lineage_event(
            fallback_kind="strict_social_fallback",
            owner="game.final_emission_gate",
            fallback_selection_owner="game.final_emission_gate",
            fallback_content_owner="game.social_exchange_emission",
            fallback_authorship_source=None,
            fallback_owner_bucket=None,
        ),
    )
    assert _lineage_event(strict_social, "gate_outcome")["gate_path"] == "strict_social_fallback"

    emergency = build_fem_runtime_lineage_events(
        {
            "final_route": "replaced",
            "strict_social_active": True,
            "final_emitted_source": "minimal_social_emergency_fallback",
        }
    )
    emergency_selected = _lineage_event(emergency, "fallback_selected")
    assert_runtime_lineage_event_matches(
        emergency_selected,
        expected_runtime_fallback_lineage_event(
            fallback_kind="minimal_social_emergency_fallback",
            owner="game.final_emission_gate",
            fallback_selection_owner="game.final_emission_gate",
            fallback_content_owner="game.social_exchange_emission",
        ),
    )
    assert _lineage_event(emergency, "gate_outcome")["gate_path"] == "strict_social_emergency"

    sanitizer = build_fem_runtime_lineage_events(
        {
            "sanitizer_empty_fallback_used": True,
            "sanitizer_empty_fallback_source": "upstream_prepared_emission.prepared_sanitizer_empty_fallback_text",
        }
    )
    fallback = _lineage_event(sanitizer, "fallback_selected")
    assert_runtime_lineage_event_matches(
        fallback,
        expected_runtime_fallback_lineage_event(
            fallback_kind="sanitizer_empty_output",
            owner="game.output_sanitizer",
            fallback_selection_owner=SANITIZER_FALLBACK_SELECTION_OWNER,
            fallback_content_owner=SANITIZER_FALLBACK_SELECTION_OWNER,
            stage="sanitizer",
        ),
    )
    assert _lineage_event(sanitizer, "gate_outcome")["gate_path"] == "sanitizer_fallback"

    sanitizer_social = build_fem_runtime_lineage_events(
        {
            "sanitizer_strict_social_fallback_used": True,
            "sanitizer_strict_social_source": "social_fallback_line_for_sanitizer.empty_output",
            "sanitizer_strict_social_selection_owner": SANITIZER_FALLBACK_SELECTION_OWNER,
            "sanitizer_strict_social_prose_owner": SANITIZER_STRICT_SOCIAL_CONTENT_OWNER,
        }
    )
    sanitizer_social_selected = _lineage_event(sanitizer_social, "fallback_selected")
    assert_runtime_lineage_event_matches(
        sanitizer_social_selected,
        expected_runtime_fallback_lineage_event(
            fallback_kind="sanitizer_strict_social",
            owner="game.output_sanitizer",
            fallback_selection_owner=SANITIZER_FALLBACK_SELECTION_OWNER,
            fallback_content_owner=SANITIZER_STRICT_SOCIAL_CONTENT_OWNER,
        ),
    )
    assert _lineage_event(sanitizer_social, "gate_outcome")["gate_path"] == "sanitizer_fallback"


def test_build_fem_runtime_lineage_events_projects_upstream_fast_fallback_split_owners() -> None:
    events = build_fem_runtime_lineage_events(
        {
            "fallback_provenance_trace": {
                "source": "fallback",
                "stage": "fallback_selector",
                "content_fingerprint": "abc123",
                "gate_exit_vs_selector_match": True,
            },
        }
    )
    selected = _lineage_event(events, "fallback_selected")
    assert_runtime_lineage_event_matches(
        selected,
        expected_runtime_fallback_lineage_event(
            fallback_kind="upstream_fast_fallback",
            owner="game.api",
            fallback_selection_owner=UPSTREAM_FAST_FALLBACK_SELECTION_OWNER,
            fallback_content_owner=UPSTREAM_FAST_FALLBACK_CONTENT_OWNER,
            source="fallback_provenance_trace",
            stage="retry",
        ),
    )
    assert not any(event.get("event_kind") == "gate_outcome" for event in events)


def test_build_fem_runtime_lineage_events_is_conservative_serializable_and_recurrence_ready() -> None:
    assert build_fem_runtime_lineage_events(None) == []
    assert build_fem_runtime_lineage_events({}) == []
    assert build_fem_runtime_lineage_events({"upstream_prepared_emission_valid": True}) == []

    events = build_fem_runtime_lineage_events(
        {
            "upstream_prepared_emission_used": True,
            "response_type_repair_used": True,
            "response_type_repair_kind": "answer_upstream_prepared_repair",
            "final_emitted_source": "answer_upstream_prepared_repair",
        }
    )
    assert _lineage_event(events, "fallback_selected")["fallback_kind"] == "response_type_prepared_emission"
    assert _lineage_event(events, "gate_outcome")["gate_path"] == "prepared_repair"
    assert all(event["recurrence_key"] for event in events)
    assert json.loads(json.dumps(events)) == events


def test_assemble_unified_observational_bundle_exposes_fem_runtime_lineage_sibling_surface() -> None:
    bundle = assemble_unified_observational_telemetry_bundle(
        fem={
            "final_route": "replaced",
            "final_emitted_source": "global_scene_fallback",
            "visibility_replacement_applied": True,
        }
    )
    events = bundle["fem_runtime_lineage_events"]
    assert _lineage_event(events, "fallback_selected")["fallback_kind"] == "visibility_hard_replacement"
    assert _lineage_event(events, "gate_outcome")["gate_path"] == "visibility_hard_replaced"


def test_build_fem_runtime_lineage_events_preserves_visibility_sealed_projection_split() -> None:
    events = build_fem_runtime_lineage_events(
        {
            "final_route": "replaced",
            "final_emitted_source": "global_scene_fallback",
            "visibility_replacement_applied": True,
            "visibility_fallback_owner_bucket": VISIBILITY_FALLBACK_OWNER_SEALED_GATE,
            "visibility_fallback_pool": "global_scene_narrative",
            "visibility_fallback_kind": "narrative_safe_fallback",
            "sealed_fallback_owner_bucket": SEALED_FALLBACK_OWNER_SEALED_GATE,
            "realization_fallback_family": "gate_terminal_repair",
        }
    )

    fallback = _lineage_event(events, "fallback_selected")
    assert fallback["fallback_kind"] == "visibility_hard_replacement"
    assert fallback["owner"] == "game.final_emission_gate"
    assert fallback["fallback_authorship_source"] is None
    assert fallback["fallback_owner_bucket"] == VISIBILITY_FALLBACK_OWNER_SEALED_GATE
    assert fallback["fallback_selection_owner"] == VISIBILITY_FALLBACK_SELECTION_OWNER
    assert fallback["fallback_content_owner"] == SEALED_FALLBACK_MODULE_CONTENT_OWNER
    assert _lineage_event(events, "gate_outcome")["gate_path"] == "visibility_hard_replaced"
    assert not any(
        event.get("fallback_kind") in {"scene_opening", "opening_failed_closed", "strict_social_fallback"}
        for event in events
    )
    assert json.loads(json.dumps(events)) == events


def test_build_fem_runtime_lineage_events_preserves_first_mention_sealed_projection_split() -> None:
    events = build_fem_runtime_lineage_events(
        {
            "final_route": "replaced",
            "final_emitted_source": "global_scene_fallback",
            "first_mention_replacement_applied": True,
            "visibility_fallback_owner_bucket": VISIBILITY_FALLBACK_OWNER_SEALED_GATE,
            "visibility_fallback_pool": "global_scene_narrative",
            "visibility_fallback_kind": "narrative_safe_fallback",
            "producer_repair_kind": "first_mention_enforcement",
        }
    )

    fallback = _lineage_event(events, "fallback_selected")
    assert fallback["fallback_kind"] == "first_mention_hard_replacement"
    assert fallback["owner"] == "game.final_emission_gate"
    assert fallback["fallback_owner_bucket"] == VISIBILITY_FALLBACK_OWNER_SEALED_GATE
    assert fallback["fallback_selection_owner"] == VISIBILITY_FALLBACK_SELECTION_OWNER
    assert fallback["fallback_content_owner"] == SEALED_FALLBACK_MODULE_CONTENT_OWNER
    assert fallback["repair_kind"] == "first_mention_enforcement"
    assert _lineage_event(events, "gate_outcome")["gate_path"] == "first_mention_hard_replaced"
    assert _lineage_event(events, "mutation")["mutation_kind"] == "first_mention_replacement_mutation"


def test_build_fem_runtime_lineage_events_preserves_referential_clarity_sealed_projection_split() -> None:
    events = build_fem_runtime_lineage_events(
        {
            "final_route": "replaced",
            "final_emitted_source": "global_scene_fallback",
            "referential_clarity_replacement_applied": True,
            "visibility_fallback_owner_bucket": VISIBILITY_FALLBACK_OWNER_SEALED_GATE,
            "visibility_fallback_pool": "global_scene_narrative",
            "visibility_fallback_kind": "narrative_safe_fallback",
            "producer_repair_kind": "referential_clarity_enforcement",
        }
    )

    fallback = _lineage_event(events, "fallback_selected")
    assert fallback["fallback_kind"] == "referential_clarity_hard_replacement"
    assert fallback["owner"] == "game.final_emission_gate"
    assert fallback["fallback_owner_bucket"] == VISIBILITY_FALLBACK_OWNER_SEALED_GATE
    assert fallback["fallback_selection_owner"] == VISIBILITY_FALLBACK_SELECTION_OWNER
    assert fallback["fallback_content_owner"] == SEALED_FALLBACK_MODULE_CONTENT_OWNER
    assert fallback["repair_kind"] == "referential_clarity_enforcement"
    assert _lineage_event(events, "gate_outcome")["gate_path"] == "referential_clarity_hard_replaced"
    assert _lineage_event(events, "mutation")["mutation_kind"] == "referential_clarity_replacement_mutation"


def test_build_fem_runtime_lineage_events_projects_referential_local_substitution_mutation() -> None:
    from game.final_emission_ownership_schema import VISIBILITY_FALLBACK_OWNER_STRICT_SOCIAL_VISIBILITY

    events = build_fem_runtime_lineage_events(
        {
            "final_route": "accept_candidate",
            "referential_clarity_local_substitution_applied": True,
            "referential_clarity_local_substitution_token": "She",
            "referential_clarity_local_substitution_replacement": "The Tavern Runner",
            "visibility_fallback_owner_bucket": VISIBILITY_FALLBACK_OWNER_STRICT_SOCIAL_VISIBILITY,
            "producer_repair_kind": "referential_clarity_local_substitution",
        }
    )

    assert not any(event.get("event_kind") == "fallback_selected" for event in events)
    mutation = _lineage_event(events, "mutation")
    assert mutation["mutation_kind"] == "referential_clarity_local_substitution_mutation"
    assert mutation["owner"] == "game.final_emission_gate"
    assert _lineage_event(events, "gate_outcome")["gate_path"] == "visibility_local_repair"


def test_project_sealed_replacement_subkind_maps_terminal_replace_sources() -> None:
    cases = (
        (successful_opening_fem_meta(final_route="replaced"), SEALED_REPLACEMENT_SUBKIND_OPENING),
        ({"final_route": "replaced", "final_emitted_source": "social_interlocutor_minimal_fallback"}, SEALED_REPLACEMENT_SUBKIND_SOCIAL_INTERLOCUTOR),
        ({"final_route": "replaced", "final_emitted_source": "passive_scene_pressure_fallback"}, SEALED_REPLACEMENT_SUBKIND_PASSIVE_SCENE_PRESSURE),
        ({"final_route": "replaced", "final_emitted_source": "npc_pursuit_neutral_fallback"}, SEALED_REPLACEMENT_SUBKIND_NPC_PURSUIT_NEUTRAL),
        ({"final_route": "replaced", "final_emitted_source": "anti_reset_local_continuation_fallback"}, SEALED_REPLACEMENT_SUBKIND_ANTI_RESET_CONTINUATION),
        ({"final_route": "replaced", "final_emitted_source": "global_scene_fallback"}, SEALED_REPLACEMENT_SUBKIND_GLOBAL_SCENE),
        ({"final_route": "replaced", "final_emitted_source": "acceptance_quality_global_scene_fallback"}, SEALED_REPLACEMENT_SUBKIND_GLOBAL_SCENE),
        ({"final_route": "replaced", "final_emitted_source": "mystery_terminal_source"}, SEALED_REPLACEMENT_SUBKIND_UNKNOWN),
        ({"final_route": "accept_candidate", "final_emitted_source": "global_scene_fallback"}, None),
    )
    for fem, expected in cases:
        assert project_sealed_replacement_subkind_from_fem(fem) == expected


def test_build_fem_runtime_lineage_events_sealed_branches_remain_distinct_read_side() -> None:
    """Gate-terminal repairs share ``gate_terminal_repair`` but lineage sub-kinds differ."""
    shared_realization = {
        "final_route": "replaced",
        "realization_fallback_family": GATE_TERMINAL_REPAIR,
        "sealed_fallback_owner_bucket": SEALED_FALLBACK_OWNER_SEALED_GATE,
    }
    branches = (
        ("social_interlocutor_minimal_fallback", SEALED_REPLACEMENT_SUBKIND_SOCIAL_INTERLOCUTOR, STRICT_SOCIAL_FALLBACK_CONTENT_OWNER),
        ("passive_scene_pressure_fallback", SEALED_REPLACEMENT_SUBKIND_PASSIVE_SCENE_PRESSURE, SEALED_FALLBACK_MODULE_CONTENT_OWNER),
        ("npc_pursuit_neutral_fallback", SEALED_REPLACEMENT_SUBKIND_NPC_PURSUIT_NEUTRAL, SEALED_FALLBACK_MODULE_CONTENT_OWNER),
        ("anti_reset_local_continuation_fallback", SEALED_REPLACEMENT_SUBKIND_ANTI_RESET_CONTINUATION, SEALED_FALLBACK_MODULE_CONTENT_OWNER),
        ("global_scene_fallback", SEALED_REPLACEMENT_SUBKIND_GLOBAL_SCENE, SEALED_FALLBACK_MODULE_CONTENT_OWNER),
    )
    projected_kinds: list[str] = []
    for final_emitted_source, expected_subkind, expected_content_owner in branches:
        events = build_fem_runtime_lineage_events(
            {
                **shared_realization,
                "final_emitted_source": final_emitted_source,
            }
        )
        fallback = _lineage_event(events, "fallback_selected")
        assert_runtime_lineage_event_matches(
            fallback,
            expected_runtime_fallback_lineage_event(
                fallback_kind=expected_subkind,
                owner="game.final_emission_gate",
                fallback_selection_owner=SEALED_FALLBACK_SELECTION_OWNER,
                fallback_content_owner=expected_content_owner,
            ),
        )
        projected_kinds.append(str(fallback["fallback_kind"]))
    assert len(set(projected_kinds)) == len(branches)


def test_build_fem_runtime_lineage_events_sealed_opening_subkind_maps_opening_content_owner() -> None:
    """``sealed_opening_fallback`` content owner matches scene-opening prose owner."""
    from game.final_emission_replay_projection import SEALED_REPLACEMENT_CONTENT_OWNER_BY_SUBKIND

    assert (
        SEALED_REPLACEMENT_CONTENT_OWNER_BY_SUBKIND[SEALED_REPLACEMENT_SUBKIND_OPENING]
        == OPENING_FALLBACK_CONTENT_OWNER
    )
    opening_meta = successful_opening_fem_meta(final_route="replaced")
    events = build_fem_runtime_lineage_events(opening_meta)
    opening_selected = _lineage_event(events, "fallback_selected")
    assert_runtime_lineage_event_matches(
        opening_selected,
        expected_runtime_fallback_lineage_event(
            fallback_kind="scene_opening",
            owner="game.final_emission_gate",
            fallback_selection_owner=OPENING_FALLBACK_SELECTION_OWNER,
            fallback_content_owner=OPENING_FALLBACK_CONTENT_OWNER,
        ),
    )


def test_build_fem_runtime_lineage_events_sealed_unknown_replacement_is_conservative() -> None:
    events = build_fem_runtime_lineage_events(
        {
            "final_route": "replaced",
            "final_emitted_source": "unclassified_terminal_fallback",
            "realization_fallback_family": GATE_TERMINAL_REPAIR,
        }
    )
    fallback = _lineage_event(events, "fallback_selected")
    assert_runtime_lineage_event_matches(
        fallback,
        expected_runtime_fallback_lineage_event(
            fallback_kind=SEALED_REPLACEMENT_SUBKIND_UNKNOWN,
            owner="game.final_emission_gate",
            fallback_selection_owner=SEALED_FALLBACK_SELECTION_OWNER,
            fallback_content_owner=SEALED_FALLBACK_UNKNOWN_CONTENT_OWNER,
        ),
    )


def test_build_fem_runtime_lineage_events_projects_neutral_speaker_grounding_bridge() -> None:
    events = build_fem_runtime_lineage_events(
        {
            "final_route": "replaced",
            "final_emitted_source": "neutral_reply_speaker_grounding_bridge",
            "response_type_repair_used": False,
        }
    )
    fallback = _lineage_event(events, "fallback_selected")
    assert_runtime_lineage_event_matches(
        fallback,
        expected_runtime_fallback_lineage_event(
            fallback_kind=SEALED_REPLACEMENT_SUBKIND_UNKNOWN,
            owner="game.final_emission_gate",
            fallback_selection_owner=SEALED_FALLBACK_SELECTION_OWNER,
            fallback_content_owner=SEALED_FALLBACK_UNKNOWN_CONTENT_OWNER,
        ),
    )


def test_acceptance_projection_runtime_lineage_delegates_to_fem_builder_when_bundle_absent() -> None:
    from tests.helpers.golden_replay_fixtures import project_synthetic_turn
    from tests.helpers.opening_fallback_evidence import successful_opening_fem_meta

    fem_meta = successful_opening_fem_meta()
    observed = project_synthetic_turn(
        scenario_id="fem_lineage_projection",
        gm_text="The road opens.",
        fem_meta=fem_meta,
    )
    expected_events = build_fem_runtime_lineage_events(fem_meta)
    assert observed["runtime_lineage_events"] == expected_events[:16]


def test_build_fem_runtime_lineage_events_projects_explicit_speaker_contract_repairs() -> None:
    for reason, expected_kind in (
        ("continuity_locked_speaker_repair", "local_rebind"),
        ("canonical_speaker_rewrite", "canonical_rewrite"),
        ("narrator_neutral_no_allowed_speaker", "narrator_neutral"),
    ):
        events = build_fem_runtime_lineage_events({"speaker_contract_enforcement_reason": reason})
        speaker = _lineage_event(events, "speaker_repair")
        mutation = _lineage_event(events, "mutation")
        assert speaker["repair_kind"] == expected_kind
        assert speaker["owner"] == "game.speaker_contract_enforcement"
        assert mutation["mutation_kind"] == "speaker_repair_mutation"
        assert all(event["recurrence_key"] for event in events)


def test_build_fem_runtime_lineage_events_projects_interaction_continuity_repairs() -> None:
    expected = {
        "repair_malformed_speaker_attribution": "continuity_malformed_attribution",
        "strip_uncued_interruption": "continuity_strip_uncued_interruption",
        "insert_explicit_bridge": "continuity_insert_bridge",
        "narration_to_dialogue": "continuity_wrap_dialogue",
    }
    for raw_type, repair_kind in expected.items():
        events = build_fem_runtime_lineage_events(
            {
                "interaction_continuity_repair": {
                    "applied": True,
                    "repair_type": raw_type,
                    "violations": ["continuity_violation"],
                }
            }
        )
        assert _lineage_event(events, "speaker_repair")["repair_kind"] == repair_kind
        assert _lineage_event(events, "mutation")["mutation_kind"] == "continuity_repair_mutation"


def test_build_fem_runtime_lineage_events_projects_explicit_mutation_evidence_without_explosion() -> None:
    events = build_fem_runtime_lineage_events(
        {
            "final_route": "accept_candidate",
            "final_emitted_source": "answer_upstream_prepared_repair",
            "response_type_repair_used": True,
            "response_type_repair_kind": "answer_upstream_prepared_repair",
            "upstream_prepared_emission_used": True,
            "post_gate_mutation_detected": True,
            "final_emission_mutation_lineage": [
                "response_type_repair",
                "response_type_repair",
                "prepared_emission_selection",
                "finalize_route_illegal_strip",
                "finalize_packaging",
                "post_gate_mutation_detected",
            ],
        }
    )
    mutations = [event for event in events if event["event_kind"] == "mutation"]
    kinds = [event["mutation_kind"] for event in mutations]
    assert kinds.count("response_type_repair_mutation") == 1
    assert kinds.count("fallback_mutation") == 1
    assert kinds.count("final_emission_mutation") == 1
    assert all(event["recurrence_key"] for event in mutations)
    assert json.loads(json.dumps(events)) == events


def test_build_fem_runtime_lineage_events_projects_sanitizer_and_unknown_post_gate_mutation() -> None:
    sanitizer = build_fem_runtime_lineage_events(
        {
            "sanitizer_lineage_changed_count": 2,
            "sanitizer_empty_fallback_used": True,
            "sanitizer_empty_fallback_source": "prepared_empty",
            "final_emission_mutation_lineage": ["sanitizer_empty_fallback"],
        }
    )
    sanitizer_kinds = {
        event["mutation_kind"] for event in sanitizer if event["event_kind"] == "mutation"
    }
    assert sanitizer_kinds == {"fallback_mutation", "sanitizer_mutation"}
    assert len([event for event in sanitizer if event.get("mutation_kind") == "fallback_mutation"]) == 1

    generic = build_fem_runtime_lineage_events({"post_gate_mutation_detected": True})
    assert _lineage_event(generic, "mutation")["mutation_kind"] == "final_emission_mutation"


def test_write_time_mutation_seam_helpers_ensure_and_patch_fem_in_place() -> None:
    gm: dict = {}
    meta = ensure_final_emission_meta_dict(gm)
    assert gm[FINAL_EMISSION_META_KEY] is meta
    meta["k"] = 1
    assert gm[FINAL_EMISSION_META_KEY]["k"] == 1

    patch_final_emission_meta(gm, {"a": 2})
    assert gm[FINAL_EMISSION_META_KEY]["a"] == 2

    # Malformed FEM gets replaced with a dict.
    gm2: dict = {FINAL_EMISSION_META_KEY: "bad"}
    patch_final_emission_meta(gm2, {"b": 3})
    assert isinstance(gm2[FINAL_EMISSION_META_KEY], dict)
    assert gm2[FINAL_EMISSION_META_KEY]["b"] == 3


def test_normalize_fem_preserves_dual_fallback_family_fields_without_collapse() -> None:
    """Observability normalization must not rewrite diegetic vs provenance family stamps."""
    raw = opening_dual_family_fem_meta(
        realization_family="legacy_diegetic_fallback",
        fallback_temporal_frame="first_impression",
    )
    normalized = normalize_final_emission_meta_for_observability(raw)
    assert normalized["fallback_family_used"] == "scene_opening"
    assert normalized[REALIZATION_FALLBACK_FAMILY_FIELD] == "legacy_diegetic_fallback"
    assert normalized["fallback_family_used"] != normalized[REALIZATION_FALLBACK_FAMILY_FIELD]


def test_golden_replay_dual_family_precedence_matches_fem_normalization() -> None:
    """Replay projection reads both normalized FEM fields independently (no collapse)."""
    from tests.helpers.golden_replay_projection import (
        REPLAY_FALLBACK_FAMILY_FEM_PRECEDENCE_KEYS,
        project_replay_fallback_family_from_fem,
    )

    raw = opening_dual_family_fem_meta(realization_family="upstream_prepared_emission")
    normalized = normalize_final_emission_meta_for_observability(raw)
    assert project_replay_fallback_family_from_fem(normalized) == "scene_opening"
    assert set(REPLAY_FALLBACK_FAMILY_FEM_PRECEDENCE_KEYS) <= set(normalized.keys())
    assert normalized[REALIZATION_FALLBACK_FAMILY_FIELD] == "upstream_prepared_emission"


def test_final_emission_meta_read_side_surface_exposes_sidecar_lane_constants() -> None:
    surface = final_emission_meta_read_side_surface()
    assert surface["final_emission_meta_key"] == FINAL_EMISSION_META_KEY
    assert surface["emission_debug_lane_key"] == EMISSION_DEBUG_LANE_KEY
    assert surface["internal_state_key"] == INTERNAL_STATE_KEY
    assert surface["final_emission_mutation_lineage_key"] == FINAL_EMISSION_MUTATION_LINEAGE_KEY
    assert surface["opening_fallback_owner_buckets"] == sorted(OPENING_FALLBACK_OWNER_BUCKETS)
    assert surface["sealed_fallback_owner_buckets"] == sorted(SEALED_FALLBACK_OWNER_BUCKETS)
    assert surface["visibility_fallback_owner_buckets"] == sorted(VISIBILITY_FALLBACK_OWNER_BUCKETS)
    registries = surface["fallback_owner_bucket_registries"]
    assert registries["opening"]["OPENING_FALLBACK_OWNER_UPSTREAM_PREPARED"] == "upstream-prepared"
    assert registries["sealed"]["SEALED_FALLBACK_OWNER_STRICT_SOCIAL_SEALED"] == "strict-social-sealed"
    assert registries["visibility"]["VISIBILITY_FALLBACK_OWNER_OPENING_VISIBILITY"] == "opening-visibility"
    assert surface["sidecar_read_helpers_preferred"] is True


def test_runtime_lineage_vocabulary_summary_includes_split_owner_fields() -> None:
    summary = runtime_lineage_vocabulary_summary()
    assert summary["event_kinds"] == sorted(
        {
            RUNTIME_LINEAGE_EVENT_FALLBACK_SELECTED,
            RUNTIME_LINEAGE_EVENT_SPEAKER_REPAIR,
            RUNTIME_LINEAGE_EVENT_MUTATION,
            RUNTIME_LINEAGE_EVENT_GATE_OUTCOME,
        }
    )
    assert RUNTIME_LINEAGE_STAGE_GATE in summary["stages"]
    assert RUNTIME_LINEAGE_STAGE_SANITIZER in summary["stages"]
    assert summary["fallback_attribution_fields"] == [
        "fallback_authorship_source",
        "fallback_owner_bucket",
        "fallback_selection_owner",
        "fallback_content_owner",
    ]
    note = str(summary["recurrence_identity_note"])
    assert "event_kind" in note
    assert "fallback_content_owner" in note
    assert "recurrence_key" in note


def test_read_side_lineage_projection_surface_includes_sealed_subkinds_and_split_owners() -> None:
    surface = read_side_lineage_projection_surface()
    assert surface["sealed_replacement_subkind_count"] == len(SEALED_REPLACEMENT_SUBKINDS)
    assert surface["sealed_replacement_subkind_tokens"] == sorted(SEALED_REPLACEMENT_SUBKINDS)
    assert surface["opening_fallback_selection_owner"] == OPENING_FALLBACK_SELECTION_OWNER
    assert surface["opening_fallback_content_owner"] == OPENING_FALLBACK_CONTENT_OWNER
    assert surface["strict_social_fallback_selection_owner"] == STRICT_SOCIAL_FALLBACK_SELECTION_OWNER
    assert surface["strict_social_fallback_content_owner"] == STRICT_SOCIAL_FALLBACK_CONTENT_OWNER
    assert surface["sanitizer_fallback_selection_owner"] == SANITIZER_FALLBACK_SELECTION_OWNER
    assert surface["sanitizer_strict_social_content_owner"] == SANITIZER_STRICT_SOCIAL_CONTENT_OWNER
    assert surface["sealed_fallback_selection_owner"] == SEALED_FALLBACK_SELECTION_OWNER
    assert surface["upstream_fast_fallback_selection_owner"] == UPSTREAM_FAST_FALLBACK_SELECTION_OWNER
    assert surface["upstream_fast_fallback_content_owner"] == UPSTREAM_FAST_FALLBACK_CONTENT_OWNER
    assert surface["upstream_fast_fallback_provenance_packager"] == UPSTREAM_FAST_FALLBACK_PROVENANCE_PACKAGER
    assert surface["sealed_replacement_content_owner_by_subkind"][SEALED_REPLACEMENT_SUBKIND_OPENING] == (
        OPENING_FALLBACK_CONTENT_OWNER
    )
    assert surface["mutation_lineage_key"] == FINAL_EMISSION_MUTATION_LINEAGE_KEY
    assert surface["legacy_sealed_or_global_replacement_token"] == "sealed_or_global_replacement"
    assert SEALED_REPLACEMENT_SUBKIND_OPENING in surface["sealed_replacement_subkind_tokens"]
    assert SEALED_REPLACEMENT_SUBKIND_UNKNOWN in surface["sealed_replacement_subkind_tokens"]


def test_ownership_schema_registry_surface_matches_meta_and_replay() -> None:
    from game.final_emission_ownership_schema import (
        OPENING_FALLBACK_CONTENT_OWNER,
        OPENING_FALLBACK_SELECTION_OWNER,
        ownership_schema_registry_surface,
        SANITIZER_FALLBACK_SELECTION_OWNER,
        SANITIZER_STRICT_SOCIAL_CONTENT_OWNER,
        SEALED_FALLBACK_SELECTION_OWNER,
        STRICT_SOCIAL_FALLBACK_CONTENT_OWNER,
        STRICT_SOCIAL_FALLBACK_SELECTION_OWNER,
        UPSTREAM_FAST_FALLBACK_CONTENT_OWNER,
        UPSTREAM_FAST_FALLBACK_SELECTION_OWNER,
        VISIBILITY_FALLBACK_SELECTION_OWNER,
    )

    schema_surface = ownership_schema_registry_surface()
    meta_surface = final_emission_meta_read_side_surface()
    replay_surface = read_side_lineage_projection_surface()

    assert schema_surface["opening_fallback_owner_buckets"] == meta_surface["opening_fallback_owner_buckets"]
    assert schema_surface["sealed_fallback_owner_buckets"] == meta_surface["sealed_fallback_owner_buckets"]
    assert schema_surface["visibility_fallback_owner_buckets"] == meta_surface["visibility_fallback_owner_buckets"]
    assert schema_surface["fallback_owner_bucket_registries"] == meta_surface["fallback_owner_bucket_registries"]

    assert schema_surface["opening_fallback_selection_owner"] == OPENING_FALLBACK_SELECTION_OWNER
    assert schema_surface["opening_fallback_content_owner"] == OPENING_FALLBACK_CONTENT_OWNER
    assert schema_surface["strict_social_fallback_selection_owner"] == STRICT_SOCIAL_FALLBACK_SELECTION_OWNER
    assert schema_surface["strict_social_fallback_content_owner"] == STRICT_SOCIAL_FALLBACK_CONTENT_OWNER
    assert schema_surface["sanitizer_fallback_selection_owner"] == SANITIZER_FALLBACK_SELECTION_OWNER
    assert schema_surface["sanitizer_strict_social_content_owner"] == SANITIZER_STRICT_SOCIAL_CONTENT_OWNER
    assert schema_surface["sealed_fallback_selection_owner"] == SEALED_FALLBACK_SELECTION_OWNER
    assert schema_surface["visibility_fallback_selection_owner"] == VISIBILITY_FALLBACK_SELECTION_OWNER
    assert schema_surface["visibility_fallback_content_owner_by_bucket"] == replay_surface[
        "visibility_fallback_content_owner_by_bucket"
    ]
    assert schema_surface["upstream_fast_fallback_selection_owner"] == UPSTREAM_FAST_FALLBACK_SELECTION_OWNER
    assert schema_surface["upstream_fast_fallback_content_owner"] == UPSTREAM_FAST_FALLBACK_CONTENT_OWNER

    assert replay_surface["opening_fallback_selection_owner"] == schema_surface["opening_fallback_selection_owner"]
    assert replay_surface["visibility_fallback_selection_owner"] == schema_surface["visibility_fallback_selection_owner"]
    assert replay_surface["upstream_fast_fallback_content_owner"] == UPSTREAM_FAST_FALLBACK_CONTENT_OWNER


def test_final_emission_meta_owner_bucket_constants_match_ownership_schema() -> None:
    from game.final_emission_meta import (
        OPENING_FALLBACK_LEGACY_COMPATIBILITY_LOCAL_AUTHORSHIP_SOURCES,
        SEALED_FALLBACK_OWNER_UNKNOWN_NONE,
    )
    from game.final_emission_ownership_schema import (
        OPENING_FALLBACK_OWNER_BUCKETS as SCHEMA_OPENING_BUCKETS,
        OPENING_FALLBACK_OWNER_UPSTREAM_PREPARED as SCHEMA_OPENING_UPSTREAM,
        SEALED_FALLBACK_OWNER_BUCKETS as SCHEMA_SEALED_BUCKETS,
        SEALED_FALLBACK_OWNER_UNKNOWN_NONE as SCHEMA_SEALED_UNKNOWN_NONE,
        VISIBILITY_FALLBACK_OWNER_BUCKETS as SCHEMA_VISIBILITY_BUCKETS,
        OPENING_FALLBACK_LEGACY_COMPATIBILITY_LOCAL_AUTHORSHIP_SOURCES as SCHEMA_LEGACY_AUTH,
    )

    assert OPENING_FALLBACK_OWNER_BUCKETS == SCHEMA_OPENING_BUCKETS
    assert OPENING_FALLBACK_OWNER_UPSTREAM_PREPARED == SCHEMA_OPENING_UPSTREAM
    assert SEALED_FALLBACK_OWNER_BUCKETS == SCHEMA_SEALED_BUCKETS
    assert SEALED_FALLBACK_OWNER_UNKNOWN_NONE == SCHEMA_SEALED_UNKNOWN_NONE
    assert VISIBILITY_FALLBACK_OWNER_BUCKETS == SCHEMA_VISIBILITY_BUCKETS
    assert OPENING_FALLBACK_LEGACY_COMPATIBILITY_LOCAL_AUTHORSHIP_SOURCES == SCHEMA_LEGACY_AUTH


def test_legacy_final_emission_meta_owner_bucket_imports_remain_stable() -> None:
    """Backward-compat: historical import paths from final_emission_meta still resolve."""
    from game.final_emission_meta import (
        OPENING_FALLBACK_OWNER_RETRY,
        SEALED_FALLBACK_OWNER_STRICT_SOCIAL_SEALED,
        VISIBILITY_FALLBACK_OWNER_OPENING_VISIBILITY,
        fallback_owner_bucket_registry_surface,
        UPSTREAM_FAST_FALLBACK_SELECTION_OWNER,
    )
    from game.final_emission_ownership_schema import (
        OPENING_FALLBACK_OWNER_RETRY as SCHEMA_RETRY,
        SEALED_FALLBACK_OWNER_STRICT_SOCIAL_SEALED as SCHEMA_STRICT_SOCIAL_SEALED,
        VISIBILITY_FALLBACK_OWNER_OPENING_VISIBILITY as SCHEMA_OPENING_VISIBILITY,
        UPSTREAM_FAST_FALLBACK_SELECTION_OWNER as SCHEMA_API_OWNER,
    )

    assert OPENING_FALLBACK_OWNER_RETRY == SCHEMA_RETRY
    assert SEALED_FALLBACK_OWNER_STRICT_SOCIAL_SEALED == SCHEMA_STRICT_SOCIAL_SEALED
    assert VISIBILITY_FALLBACK_OWNER_OPENING_VISIBILITY == SCHEMA_OPENING_VISIBILITY
    assert UPSTREAM_FAST_FALLBACK_SELECTION_OWNER == SCHEMA_API_OWNER
    registries = fallback_owner_bucket_registry_surface()
    assert registries["opening"]["OPENING_FALLBACK_OWNER_UPSTREAM_PREPARED"] == "upstream-prepared"


def test_runtime_lineage_attribution_fields_match_ownership_schema() -> None:
    from game.final_emission_ownership_schema import OWNERSHIP_LINEAGE_ATTRIBUTION_FIELDS
    from game.runtime_lineage_telemetry import RUNTIME_LINEAGE_FALLBACK_ATTRIBUTION_FIELDS

    assert RUNTIME_LINEAGE_FALLBACK_ATTRIBUTION_FIELDS == OWNERSHIP_LINEAGE_ATTRIBUTION_FIELDS


def test_upstream_opening_authorship_constant_matches_ownership_schema() -> None:
    from game.final_emission_ownership_schema import OPENING_FALLBACK_AUTHORSHIP_UPSTREAM_PREPARED as SCHEMA_AUTH

    assert OPENING_FALLBACK_AUTHORSHIP_UPSTREAM_PREPARED == SCHEMA_AUTH


def test_ownership_schema_partitions_legacy_compatibility_local_authorship_as_read_only() -> None:
    from game.final_emission_ownership_schema import (
        OPENING_FALLBACK_AUTH_UPSTREAM_PREPARED_SOURCES,
        OPENING_FALLBACK_LEGACY_COMPATIBILITY_LOCAL_AUTHORSHIP_SOURCES,
        OPENING_FALLBACK_RETIRED_SHORT_COMPATIBILITY_LOCAL_AUTHORSHIP,
        ownership_schema_registry_surface,
    )
    from tests.helpers.opening_fallback_evidence import legacy_compatibility_local_opening_authorship_source

    surface = ownership_schema_registry_surface()
    assert surface["opening_fallback_legacy_compatibility_local_read_only"] is True
    legacy = frozenset(surface["opening_fallback_legacy_compatibility_local_authorship_sources"])
    assert legacy == OPENING_FALLBACK_LEGACY_COMPATIBILITY_LOCAL_AUTHORSHIP_SOURCES
    assert legacy == frozenset({legacy_compatibility_local_opening_authorship_source()})
    assert OPENING_FALLBACK_RETIRED_SHORT_COMPATIBILITY_LOCAL_AUTHORSHIP not in legacy
    upstream_sources = frozenset(surface["opening_fallback_authorship_upstream_prepared_sources"])
    assert upstream_sources == OPENING_FALLBACK_AUTH_UPSTREAM_PREPARED_SOURCES
    assert upstream_sources.isdisjoint(legacy)


def test_production_game_modules_never_assign_compatibility_local_opening_authorship() -> None:
    """Static lock: live ``game/`` writers must not stamp retired compatibility-local authorship."""
    import re
    from pathlib import Path

    from game.final_emission_ownership_schema import (
        OPENING_FALLBACK_LEGACY_COMPATIBILITY_LOCAL_AUTHORSHIP_SOURCES,
    )

    repo = Path(__file__).resolve().parents[1]
    assign_re = re.compile(
        r"""opening_fallback_authorship_source["']?\s*=\s*["']([^"']+)["']"""
    )
    legacy_tokens = frozenset(OPENING_FALLBACK_LEGACY_COMPATIBILITY_LOCAL_AUTHORSHIP_SOURCES)
    offenders: list[str] = []
    for path in sorted((repo / "game").rglob("*.py")):
        if path.name == "final_emission_ownership_schema.py":
            continue
        for lineno, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            match = assign_re.search(line)
            if match and match.group(1) in legacy_tokens:
                offenders.append(f"{path.relative_to(repo)}:{lineno}:{match.group(1)}")
    assert offenders == []


def test_compat_local_raw_token_boundary_is_opening_fallback_evidence_only() -> None:
    """Static lock: raw compat-local authorship string literals and constant imports stay in evidence boundary."""
    import ast
    from pathlib import Path

    from game.final_emission_ownership_schema import (
        OPENING_FALLBACK_LEGACY_COMPATIBILITY_LOCAL_AUTHORSHIP_SOURCES,
    )

    repo = Path(__file__).resolve().parents[1]
    legacy_tokens = frozenset(OPENING_FALLBACK_LEGACY_COMPATIBILITY_LOCAL_AUTHORSHIP_SOURCES)
    evidence_boundary = repo / "tests" / "helpers" / "opening_fallback_evidence.py"
    allowed_production_schema = repo / "game" / "final_emission_ownership_schema.py"
    const_symbol = "OPENING_FALLBACK_AUTHORSHIP_COMPATIBILITY_LOCAL"

    literal_offenders: list[str] = []
    for path in sorted((repo / "tests").rglob("*.py")):
        if path == evidence_boundary:
            continue
        rel = path.relative_to(repo)
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.Constant) and isinstance(node.value, str):
                if node.value in legacy_tokens:
                    literal_offenders.append(f"{rel}:{node.lineno}:{node.value!r}")

    import_offenders: list[str] = []
    for path in sorted((repo / "tests").rglob("*.py")):
        if path == evidence_boundary:
            continue
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module:
                for alias in node.names:
                    if alias.name == const_symbol:
                        import_offenders.append(
                            f"{path.relative_to(repo)}:{node.lineno}:import {const_symbol}"
                        )
            if isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name == const_symbol:
                        import_offenders.append(
                            f"{path.relative_to(repo)}:{node.lineno}:import {const_symbol}"
                        )

    assert literal_offenders == [], literal_offenders
    assert import_offenders == [], import_offenders
    assert allowed_production_schema.exists()


def _compat_local_string_literal_offenders(source: str, *, legacy_tokens: frozenset[str]) -> list[str]:
    import ast

    tree = ast.parse(source)
    return [
        f"{node.lineno}:{node.value!r}"
        for node in ast.walk(tree)
        if isinstance(node, ast.Constant) and isinstance(node.value, str) and node.value in legacy_tokens
    ]


def _compat_local_constant_import_offenders(source: str, *, const_symbol: str) -> list[str]:
    import ast

    tree = ast.parse(source)
    offenders: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            for alias in node.names:
                if alias.name == const_symbol:
                    offenders.append(f"import:{alias.name}")
    return offenders


def test_failure_classification_builders_access_compat_local_only_via_legacy_helpers() -> None:
    """Static lock: classifier builders delegate compat-local evidence to legacy helpers only."""
    from pathlib import Path

    from game.final_emission_ownership_schema import (
        OPENING_FALLBACK_LEGACY_COMPATIBILITY_LOCAL_AUTHORSHIP_SOURCES,
    )

    path = Path(__file__).resolve().parent / "helpers" / "failure_classification_builders.py"
    source = path.read_text(encoding="utf-8")
    legacy_tokens = frozenset(OPENING_FALLBACK_LEGACY_COMPATIBILITY_LOCAL_AUTHORSHIP_SOURCES)
    const_symbol = "OPENING_FALLBACK_AUTHORSHIP_COMPATIBILITY_LOCAL"

    assert _compat_local_string_literal_offenders(source, legacy_tokens=legacy_tokens) == []
    assert _compat_local_constant_import_offenders(source, const_symbol=const_symbol) == []
    assert "legacy_compatibility_local_opening_classifier_row" in source
    assert "build_legacy_compatibility_local_opening_fallback_evidence" in source


def test_failure_dashboard_fixtures_access_compat_local_only_via_legacy_helpers() -> None:
    """Static lock: dashboard fixtures inject compat-local authorship only through legacy helpers."""
    from pathlib import Path

    from game.final_emission_ownership_schema import (
        OPENING_FALLBACK_LEGACY_COMPATIBILITY_LOCAL_AUTHORSHIP_SOURCES,
    )

    path = Path(__file__).resolve().parent / "helpers" / "failure_dashboard_fixtures.py"
    source = path.read_text(encoding="utf-8")
    legacy_tokens = frozenset(OPENING_FALLBACK_LEGACY_COMPATIBILITY_LOCAL_AUTHORSHIP_SOURCES)
    const_symbol = "OPENING_FALLBACK_AUTHORSHIP_COMPATIBILITY_LOCAL"

    assert _compat_local_string_literal_offenders(source, legacy_tokens=legacy_tokens) == []
    assert _compat_local_constant_import_offenders(source, const_symbol=const_symbol) == []
    assert "legacy_compatibility_local_opening_authorship_classifier_row" in source
    assert "legacy_compatibility_local_opening_authorship_meta" in source


def test_opening_fallback_compatibility_local_disabled_defaults_false_not_active_path() -> None:
    """Telemetry disabled flags default False; fail-closed paths stamp both legacy and alias keys."""
    from game.final_emission_opening_fallback import (
        OPENING_FALLBACK_COMPATIBILITY_LOCAL_DISABLED_KEY,
        OPENING_FALLBACK_LOCAL_COMPOSITION_DISABLED_KEY,
        _opening_fail_closed_meta_upstream_missing_insufficient_curated_facts,
    )

    dbg = default_response_type_debug({"required_response_type": "scene_opening"}, "resolution.metadata")
    assert dbg.get(OPENING_FALLBACK_COMPATIBILITY_LOCAL_DISABLED_KEY) is False
    assert dbg.get(OPENING_FALLBACK_LOCAL_COMPOSITION_DISABLED_KEY) is None

    meta = _opening_fail_closed_meta_upstream_missing_insufficient_curated_facts(
        {"opening_curated_facts": []},
    )
    assert meta.get(OPENING_FALLBACK_COMPATIBILITY_LOCAL_DISABLED_KEY) is True
    assert meta.get(OPENING_FALLBACK_LOCAL_COMPOSITION_DISABLED_KEY) is True
    assert meta.get("opening_fallback_authorship_source") is None


def test_compose_opening_fallback_compatibility_local_is_boundary_taxonomy_only() -> None:
    """Retired mutation kind is SEMANTIC_DISALLOWED registry residue with no production dispatch."""
    import ast
    from pathlib import Path

    from game import final_emission_boundary_contract as contract

    kind = "compose_opening_fallback_compatibility_local"
    repo = Path(__file__).resolve().parents[1]
    literal_sites: list[str] = []
    for path in sorted((repo / "game").rglob("*.py")):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.Constant) and node.value == kind:
                literal_sites.append(path.relative_to(repo).as_posix())
    assert literal_sites == ["game/final_emission_boundary_contract.py"], literal_sites
    assert contract.is_semantic_disallowed(kind)
    with pytest.raises(AssertionError, match="SEMANTIC_DISALLOWED"):
        contract.assert_final_emission_mutation_allowed(kind, source="test.static_guard")
    assert kind not in OPENING_FALLBACK_PROJECTION_FIELDS
    assert kind not in OPENING_FALLBACK_OUT_OF_BAND_TELEMETRY_FIELDS


def test_normalize_sanitizer_trace_owner_to_lineage_owner_maps_short_and_preserves_canonical() -> None:
    from game.final_emission_ownership_schema import (
        normalize_sanitizer_trace_owner_to_lineage_owner,
        SANITIZER_TRACE_SELECTION_OWNER_SHORT,
        SANITIZER_TRACE_STRICT_SOCIAL_PROSE_OWNER_SHORT,
    )

    assert normalize_sanitizer_trace_owner_to_lineage_owner(
        SANITIZER_TRACE_SELECTION_OWNER_SHORT,
        default=SANITIZER_FALLBACK_SELECTION_OWNER,
    ) == SANITIZER_FALLBACK_SELECTION_OWNER
    assert normalize_sanitizer_trace_owner_to_lineage_owner(
        SANITIZER_TRACE_STRICT_SOCIAL_PROSE_OWNER_SHORT,
        default=SANITIZER_STRICT_SOCIAL_CONTENT_OWNER,
    ) == SANITIZER_STRICT_SOCIAL_CONTENT_OWNER
    assert normalize_sanitizer_trace_owner_to_lineage_owner(
        SANITIZER_FALLBACK_SELECTION_OWNER,
        default=SANITIZER_FALLBACK_SELECTION_OWNER,
    ) == SANITIZER_FALLBACK_SELECTION_OWNER


def test_apply_sanitizer_producer_attribution_to_fem_copies_canonical_owner_fields() -> None:
    from game.final_emission_meta import apply_sanitizer_producer_attribution_to_fem
    from game.final_emission_ownership_schema import (
        SANITIZER_EMPTY_FALLBACK_OWNER_TRACE_SHORT_FIELD,
        SANITIZER_STRICT_SOCIAL_PROSE_OWNER_TRACE_SHORT_FIELD,
        SANITIZER_STRICT_SOCIAL_SELECTION_OWNER_TRACE_SHORT_FIELD,
        SANITIZER_TRACE_SELECTION_OWNER_SHORT,
        SANITIZER_TRACE_STRICT_SOCIAL_PROSE_OWNER_SHORT,
    )

    meta: dict[str, object] = {}
    apply_sanitizer_producer_attribution_to_fem(
        meta,
        {
            "sanitizer_empty_fallback_used": True,
            "sanitizer_empty_fallback_source": "upstream_prepared_emission.prepared_sanitizer_empty_fallback_text",
            "sanitizer_empty_fallback_owner": SANITIZER_FALLBACK_SELECTION_OWNER,
            SANITIZER_EMPTY_FALLBACK_OWNER_TRACE_SHORT_FIELD: SANITIZER_TRACE_SELECTION_OWNER_SHORT,
            "sanitizer_strict_social_fallback_used": True,
            "sanitizer_strict_social_selection_owner": SANITIZER_FALLBACK_SELECTION_OWNER,
            "sanitizer_strict_social_prose_owner": SANITIZER_STRICT_SOCIAL_CONTENT_OWNER,
            SANITIZER_STRICT_SOCIAL_SELECTION_OWNER_TRACE_SHORT_FIELD: SANITIZER_TRACE_SELECTION_OWNER_SHORT,
            SANITIZER_STRICT_SOCIAL_PROSE_OWNER_TRACE_SHORT_FIELD: SANITIZER_TRACE_STRICT_SOCIAL_PROSE_OWNER_SHORT,
        },
    )
    assert meta["sanitizer_empty_fallback_owner"] == SANITIZER_FALLBACK_SELECTION_OWNER
    assert meta[SANITIZER_EMPTY_FALLBACK_OWNER_TRACE_SHORT_FIELD] == SANITIZER_TRACE_SELECTION_OWNER_SHORT
    assert meta["sanitizer_strict_social_selection_owner"] == SANITIZER_FALLBACK_SELECTION_OWNER
    assert meta["sanitizer_strict_social_prose_owner"] == SANITIZER_STRICT_SOCIAL_CONTENT_OWNER


def test_build_fem_runtime_lineage_events_sanitizer_owners_idempotent_when_already_canonical() -> None:
    canonical = build_fem_runtime_lineage_events(
        {
            "sanitizer_strict_social_fallback_used": True,
            "sanitizer_strict_social_source": "social_fallback_line_for_sanitizer.empty_output",
            "sanitizer_strict_social_selection_owner": SANITIZER_FALLBACK_SELECTION_OWNER,
            "sanitizer_strict_social_prose_owner": SANITIZER_STRICT_SOCIAL_CONTENT_OWNER,
        }
    )
    legacy_short = build_fem_runtime_lineage_events(
        {
            "sanitizer_strict_social_fallback_used": True,
            "sanitizer_strict_social_source": "social_fallback_line_for_sanitizer.empty_output",
            "sanitizer_strict_social_selection_owner": "output_sanitizer",
            "sanitizer_strict_social_prose_owner": "strict_social_emission",
        }
    )
    assert _lineage_event(canonical, "fallback_selected") == _lineage_event(legacy_short, "fallback_selected")


def test_runtime_lineage_vocabulary_summary_exposes_sanitizer_legacy_short_fields() -> None:
    from game.final_emission_ownership_schema import SANITIZER_TRACE_OWNER_LEGACY_SHORT_FIELDS

    summary = runtime_lineage_vocabulary_summary()
    assert summary["sanitizer_trace_owner_legacy_short_fields"] == list(SANITIZER_TRACE_OWNER_LEGACY_SHORT_FIELDS)


def test_stamp_retry_terminal_fallback_producer_metadata_stamps_retry_bucket() -> None:
    from game.realization_provenance import REALIZATION_FALLBACK_FAMILY_FIELD, RETRY_TERMINAL_FALLBACK

    meta: dict[str, object] = {REALIZATION_FALLBACK_FAMILY_FIELD: RETRY_TERMINAL_FALLBACK}
    stamp_retry_terminal_fallback_producer_metadata(meta)
    assert meta["opening_fallback_owner_bucket"] == OPENING_FALLBACK_OWNER_RETRY


def test_stamp_upstream_prepared_opening_producer_metadata_stamps_upstream_bucket() -> None:
    from game.upstream_response_repairs import OPENING_FALLBACK_AUTHORSHIP_UPSTREAM_PREPARED

    meta: dict[str, object] = {
        "opening_fallback_authorship_source": OPENING_FALLBACK_AUTHORSHIP_UPSTREAM_PREPARED,
        "fallback_family_used": "scene_opening",
    }
    stamp_upstream_prepared_opening_producer_metadata(meta)
    assert meta["opening_fallback_owner_bucket"] == OPENING_FALLBACK_OWNER_UPSTREAM_PREPARED


def test_build_upstream_prepared_opening_fallback_payload_stamps_family_and_owner_bucket() -> None:
    from game.upstream_response_repairs import build_upstream_prepared_opening_fallback_payload
    from game.realization_provenance import REALIZATION_FALLBACK_FAMILY_FIELD, UPSTREAM_PREPARED_EMISSION

    payload = build_upstream_prepared_opening_fallback_payload(
        {
            "opening_curated_facts": ["Rain on stone."],
            "opening_fallback_context_source": "opening_curated_facts",
            "visible_facts": ["Rain on stone."],
        }
    )
    assert payload[REALIZATION_FALLBACK_FAMILY_FIELD] == UPSTREAM_PREPARED_EMISSION
    assert payload["opening_fallback_owner_bucket"] == OPENING_FALLBACK_OWNER_UPSTREAM_PREPARED
