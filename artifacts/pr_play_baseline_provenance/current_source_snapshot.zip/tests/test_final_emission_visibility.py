from __future__ import annotations

from copy import deepcopy

import pytest

import game.api_turn_support as api_turn_support
import game.final_emission_finalize as emission_finalize
import game.final_emission_gate as feg
from game.attribution_read_views import SEALED_FALLBACK_OWNER_SEALED_GATE
from game.defaults import default_scene, default_session, default_world
from game.final_emission_gate import apply_final_emission_gate
from game.final_emission_text_formatting import _normalize_text
from game.final_emission_text_legacy_semantic_repair import (
    _decompress_overpacked_sentences,
    _repair_fragmentary_participial_splits,
)
from game.interaction_context import rebuild_active_scene_entities, set_social_target
from game.narration_visibility import (
    validate_player_facing_first_mentions,
    validate_player_facing_referential_clarity,
)
from game.realization_provenance import GATE_TERMINAL_REPAIR, REALIZATION_FALLBACK_FAMILY_FIELD
from game.storage import get_scene_runtime
from tests.helpers.opening_fallback_evidence import (
    assert_final_emission_meta_contains,
    assert_first_mention_default_metadata,
    assert_first_mention_pass_metadata,
    assert_first_mention_replacement_metadata,
    assert_first_mention_skipped_metadata,
    assert_referential_clarity_default_metadata,
    assert_referential_clarity_pass_metadata,
    assert_referential_clarity_replacement_metadata,
    assert_referential_clarity_skipped_metadata,
    assert_sealed_fallback_owner_bucket,
    assert_visibility_pass_metadata,
    assert_visibility_projection_smoke,
    assert_visibility_replacement_metadata,
)
from tests.helpers.replay_fem_read_smoke import final_emission_meta_from_output


pytestmark = pytest.mark.unit

# Ownership note:
# This file owns semantic visibility, first-mention, and referential-clarity
# legality expectations with game/narration_visibility.py, plus last-mile stripping
# of appended global-visibility stock contamination via final-emission helpers.
# Final-gate tests should cover ordering, routing, projection, and integration seams only.

GLOBAL_VISIBILITY_FALLBACK = "For a breath, the scene holds while voices shift around you."
VISIBLE_FACT = "A brazier throws orange sparks over the checkpoint."


def _assert_grounded_visibility_stock_fallback(text: str) -> None:
    """Visibility replace path should prefer concrete scene anchors over generic 'scene holds' stock."""
    low = str(text or "").lower()
    assert "scene holds" not in low
    assert "voices shift around you" not in low
    assert "brazier" in low or "checkpoint" in low or "rain" in low


DISCOVERABLE_FACT = "The missing patrol was last seen near the old stone bridge."
HIDDEN_FACT = "The checkpoint taxes are funding an Ash Cowl payoff."


def _base_visibility_bundle():
    session = default_session()
    world = default_world()
    world["npcs"].append(
        {
            "id": "lord_aldric",
            "name": "Lord Aldric",
            "location": "castle_keep",
        }
    )
    scene = default_scene("frontier_gate")
    scene["scene"]["visible_facts"] = [VISIBLE_FACT]
    scene["scene"]["discoverable_clues"] = [DISCOVERABLE_FACT]
    scene["scene"]["hidden_facts"] = [HIDDEN_FACT]
    sid = "frontier_gate"
    session["active_scene_id"] = sid
    session["scene_state"]["active_scene_id"] = sid
    rebuild_active_scene_entities(session, world, sid, scene_envelope=scene)
    scene["scene_state"] = dict(session["scene_state"])
    return session, world, scene, sid


def _rich_scene_visibility_bundle():
    session = default_session()
    world = default_world()
    scene = default_scene("frontier_gate")
    sid = "frontier_gate"
    session["active_scene_id"] = sid
    session["scene_state"]["active_scene_id"] = sid
    rebuild_active_scene_entities(session, world, sid, scene_envelope=scene)
    scene["scene_state"] = dict(session["scene_state"])
    return session, world, scene, sid


def _visibility_bundle_with_extra_addressables(*addressables: dict):
    session, world, scene, sid = _base_visibility_bundle()
    scene["scene"]["addressables"].extend(deepcopy(list(addressables)))
    rebuild_active_scene_entities(session, world, sid, scene_envelope=scene)
    scene["scene_state"] = dict(session["scene_state"])
    return session, world, scene, sid


def _finalize_via_turn_support(
    text: str,
    *,
    session: dict,
    world: dict,
    scene: dict,
    resolution: dict | None = None,
) -> dict:
    scene["scene_state"] = dict(session["scene_state"])
    out, _narr_meta = api_turn_support._finalize_player_facing_for_turn(
        {"player_facing_text": text, "tags": []},
        resolution=resolution,
        session=session,
        world=world,
        scene=scene,
    )
    assert out["_player_facing_emission_finalized"] is True
    return out


def test_pipeline_replaces_offscene_known_npc_reference():
    session, world, scene, _sid = _base_visibility_bundle()

    out = _finalize_via_turn_support(
        "Lord Aldric watches the checkpoint from the square.",
        session=session,
        world=world,
        scene=scene,
    )

    _assert_grounded_visibility_stock_fallback(out["player_facing_text"])
    assert out["tags"] == [
        "final_emission_gate_replaced",
        "visibility_enforcement_replaced",
        "visibility_violation:unseen_entity_reference",
    ]
    # The sealed owner bucket here is a visibility-pipeline projection lock; the
    # sealed helper module owns only metadata/route shaping, not output selection.
    meta = final_emission_meta_from_output(out)
    assert_visibility_replacement_metadata(
        meta,
        violation_kinds=["unseen_entity_reference"],
        checked_entities=[
            {
                "entity_id": "lord_aldric",
                "matched_aliases": ["lord aldric"],
            }
        ],
        final_route="replaced",
        final_emitted_source="global_scene_fallback",
        visibility_fallback_owner_bucket=SEALED_FALLBACK_OWNER_SEALED_GATE,
        visibility_fallback_pool="global_scene_narrative",
        visibility_fallback_kind="narrative_safe_fallback",
    )
    assert meta[REALIZATION_FALLBACK_FAMILY_FIELD] == GATE_TERMINAL_REPAIR
    assert_sealed_fallback_owner_bucket(meta, SEALED_FALLBACK_OWNER_SEALED_GATE)


def test_pipeline_allows_visible_npc_reference():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = "Guard Captain stands near the gate."

    out = _finalize_via_turn_support(
        candidate,
        session=session,
        world=world,
        scene=scene,
    )

    assert out["player_facing_text"] == candidate
    assert out["tags"] == []
    assert_visibility_pass_metadata(
        final_emission_meta_from_output(out),
        checked_entities=[
            {
                "entity_id": "guard_captain",
                "matched_aliases": ["guard captain"],
            }
        ],
    )


def test_pipeline_allows_active_interlocutor_reference():
    session, world, scene, _sid = _base_visibility_bundle()
    set_social_target(session, "tavern_runner")
    candidate = 'Tavern Runner leans in and says, "Keep your hood up in this rain."'

    out = _finalize_via_turn_support(
        candidate,
        session=session,
        world=world,
        scene=scene,
    )

    assert out["player_facing_text"] == candidate
    assert out["tags"] == []
    meta = final_emission_meta_from_output(out)
    assert meta["active_interlocutor_id"] == "tavern_runner"
    assert_visibility_pass_metadata(
        meta,
        checked_entities=[
            {
                "entity_id": "tavern_runner",
                "matched_aliases": ["tavern runner"],
            }
        ],
    )


def test_pipeline_replaces_hidden_fact_assertion():
    session, world, scene, _sid = _base_visibility_bundle()

    out = _finalize_via_turn_support(
        HIDDEN_FACT,
        session=session,
        world=world,
        scene=scene,
    )

    _assert_grounded_visibility_stock_fallback(out["player_facing_text"])
    assert out["tags"] == [
        "final_emission_gate_replaced",
        "visibility_enforcement_replaced",
        "visibility_violation:undiscovered_fact_assertion",
    ]
    assert_visibility_replacement_metadata(
        final_emission_meta_from_output(out),
        violation_kinds=["undiscovered_fact_assertion"],
        checked_facts=[
            {
                "kind": "hidden_fact_strings",
                "fact": "the checkpoint taxes are funding an ash cowl payoff",
                "match_kind": "exact",
            }
        ],
    )


def test_pipeline_replaces_discoverable_but_undiscovered_fact_assertion():
    session, world, scene, _sid = _base_visibility_bundle()

    out = _finalize_via_turn_support(
        DISCOVERABLE_FACT,
        session=session,
        world=world,
        scene=scene,
    )

    _assert_grounded_visibility_stock_fallback(out["player_facing_text"])
    assert out["tags"] == [
        "final_emission_gate_replaced",
        "visibility_enforcement_replaced",
        "visibility_violation:undiscovered_fact_assertion",
    ]
    assert_visibility_replacement_metadata(
        final_emission_meta_from_output(out),
        violation_kinds=["undiscovered_fact_assertion"],
        checked_facts=[
            {
                "kind": "discoverable_fact_strings",
                "fact": "the missing patrol was last seen near the old stone bridge",
                "match_kind": "exact",
            }
        ],
    )


def test_pipeline_allows_visible_fact_assertion():
    session, world, scene, _sid = _base_visibility_bundle()

    out = _finalize_via_turn_support(
        VISIBLE_FACT,
        session=session,
        world=world,
        scene=scene,
    )

    assert out["player_facing_text"] == VISIBLE_FACT
    assert out["tags"] == []
    assert_visibility_pass_metadata(
        final_emission_meta_from_output(out),
        checked_facts=[
            {
                "kind": "visible_fact_strings",
                "fact": "a brazier throws orange sparks over the checkpoint",
                "match_kind": "exact",
            }
        ],
    )


def test_pipeline_visibility_metadata_captures_entity_and_fact_matches():
    session, world, scene, _sid = _base_visibility_bundle()

    out = _finalize_via_turn_support(
        f"Lord Aldric says {HIDDEN_FACT}",
        session=session,
        world=world,
        scene=scene,
    )

    meta = final_emission_meta_from_output(out)
    _assert_grounded_visibility_stock_fallback(out["player_facing_text"])
    assert_visibility_replacement_metadata(
        meta,
        violation_kinds=[
            "unseen_entity_reference",
            "undiscovered_fact_assertion",
        ],
        checked_entities=[
            {
                "entity_id": "lord_aldric",
                "matched_aliases": ["lord aldric"],
            }
        ],
        checked_facts=[
            {
                "kind": "hidden_fact_strings",
                "fact": "the checkpoint taxes are funding an ash cowl payoff",
                "match_kind": "substring",
            }
        ],
    )
    assert [sample["kind"] for sample in meta["visibility_violation_sample"]] == [
        "unseen_entity_reference",
        "undiscovered_fact_assertion",
    ]


def test_pipeline_visibility_enforcement_is_read_only_for_discovery_state(monkeypatch):
    session, world, scene, sid = _base_visibility_bundle()
    runtime = get_scene_runtime(session, sid)
    runtime["discovered_clues"].append("Known clue.")
    runtime["revealed_hidden_facts"].append("Known secret.")
    session["clue_knowledge"] = {
        "known_clue": {
            "text": "Known clue.",
            "source_scene": sid,
        }
    }
    scene["scene"]["visible_facts"].append("The rain has started to ease.")

    monkeypatch.setattr(api_turn_support, "apply_repeated_description_guard", lambda gm, session, scene_id: None)
    monkeypatch.setattr(api_turn_support, "update_scene_momentum_runtime", lambda session, scene_id, gm: {})

    before_session = deepcopy(session)
    before_world = deepcopy(world)
    before_scene = deepcopy(scene)
    before_runtime = deepcopy(get_scene_runtime(session, sid))
    before_clue_knowledge = deepcopy(session["clue_knowledge"])

    out = _finalize_via_turn_support(
        HIDDEN_FACT,
        session=session,
        world=world,
        scene=scene,
    )

    _assert_grounded_visibility_stock_fallback(out["player_facing_text"])
    assert get_scene_runtime(session, sid) == before_runtime
    assert session["clue_knowledge"] == before_clue_knowledge
    assert session == before_session
    assert world == before_world
    assert scene == before_scene


def test_pipeline_replaces_pronoun_before_first_explicit_entity():
    """C2: leading pronoun clause is dropped (strip/visibility), not replaced with composed intro."""
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = "He leans closer through the rain. Guard Captain studies your face."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    assert out["player_facing_text"] == "Guard Captain studies your face."
    meta = final_emission_meta_from_output(out)
    assert_first_mention_pass_metadata(meta, violation_kinds=[])


def test_pipeline_replaces_unearned_familiarity_first_intro():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = "Guard Captain stands near the gate; you recognize him immediately."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    assert out["player_facing_text"] != candidate
    meta = final_emission_meta_from_output(out)
    assert_first_mention_replacement_metadata(meta, violation_kind="first_mention_unearned_familiarity")


def test_pipeline_replaces_first_mention_missing_grounding():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = "Guard Captain appears."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    assert out["player_facing_text"] != candidate
    meta = final_emission_meta_from_output(out)
    assert_first_mention_replacement_metadata(meta, violation_kind="first_mention_missing_grounding")


def test_pipeline_allows_grounded_explicit_first_intro():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = "Guard Captain stands near the gate."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    assert out["player_facing_text"] == candidate
    meta = final_emission_meta_from_output(out)
    assert_first_mention_pass_metadata(meta, violation_kinds=[])


def test_pipeline_allows_grounded_active_interlocutor_intro():
    session, world, scene, _sid = _base_visibility_bundle()
    set_social_target(session, "tavern_runner")
    candidate = 'Tavern Runner beside the shuttered bar says, "Keep your hood low."'

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    assert out["player_facing_text"] == candidate
    meta = final_emission_meta_from_output(out)
    assert_first_mention_pass_metadata(meta)
    assert meta["active_interlocutor_id"] == "tavern_runner"


def test_pipeline_allows_opening_scene_composition_with_later_grounded_first_entity_mention():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = (
        "Nearby, cart wheels hiss over the wet stones while vendors shout under the awning, "
        "and Guard Captain calls for the line to keep moving at the gate."
    )

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    assert out["player_facing_text"] == candidate
    meta = final_emission_meta_from_output(out)
    assert_first_mention_pass_metadata(meta, violation_kinds=[])


def test_pipeline_first_mention_metadata_records_checked_entities():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = "Guard Captain appears."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    meta = final_emission_meta_from_output(out)
    checked = meta["first_mention_checked_entities"]
    assert isinstance(checked, list)
    assert checked
    first = checked[0]
    assert first["entity_id"] == "guard_captain"
    assert "matched_alias" in first
    assert "first_offset" in first
    assert "grounding_present" in first
    assert "violation_kinds" in first


def test_pipeline_visibility_failure_skips_first_mention_but_keeps_default_meta_shape():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = "Lord Aldric watches the checkpoint from the square."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    _assert_grounded_visibility_stock_fallback(out["player_facing_text"])
    meta = final_emission_meta_from_output(out)
    assert_first_mention_default_metadata(meta)
    assert_referential_clarity_default_metadata(meta)
    assert_visibility_replacement_metadata(meta)
    assert_first_mention_skipped_metadata(meta)
    assert_referential_clarity_skipped_metadata(meta)


def test_pipeline_first_mention_fallback_also_satisfies_gate_when_replacement_needed():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = "He leans closer through the rain. Guard Captain studies your face."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    meta = final_emission_meta_from_output(out)
    assert_first_mention_pass_metadata(meta)
    validation = validate_player_facing_first_mentions(
        out["player_facing_text"],
        session=session,
        scene=scene,
        world=world,
    )
    assert validation["ok"] is True


def test_pipeline_opening_scene_pronoun_failure_prefers_grounded_visible_scene_fallback():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = "He watches the line in silence. Guard Captain studies the press at the gate."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    meta = final_emission_meta_from_output(out)
    # Strip-path owner lock: pronoun clause dropped without first-mention replacement metadata.
    assert meta["first_mention_replacement_applied"] is False
    assert out["player_facing_text"] != GLOBAL_VISIBILITY_FALLBACK
    assert out["player_facing_text"] == "Guard Captain studies the press at the gate."
    assert "guard captain" in out["player_facing_text"].lower()
    assert "gate" in out["player_facing_text"].lower()
    assert meta["final_emitted_source"] == "generated_candidate"


def test_pipeline_composed_scene_intro_avoids_repeated_trivial_verbs_when_fact_backed_actions_exist():
    session, world, scene, _sid = _rich_scene_visibility_bundle()
    candidate = "He leans closer through the rain. Guard Captain studies your face."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    text = out["player_facing_text"].lower()
    meta = final_emission_meta_from_output(out)
    # Strip-path owner lock: pronoun clause dropped without first-mention replacement metadata.
    assert meta["first_mention_replacement_applied"] is False
    assert meta["final_emitted_source"] == "generated_candidate"
    assert "guard captain" in text
    validation = validate_player_facing_first_mentions(
        out["player_facing_text"],
        session=session,
        scene=scene,
        world=world,
    )
    assert validation["ok"] is True


def test_pipeline_visibility_and_first_mention_metadata_coexist():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = "Guard Captain stands near the gate."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    meta = final_emission_meta_from_output(out)
    # Multi-owner wiring smoke: visibility, first-mention, and referential layers coexist on one pass path.
    assert_visibility_projection_smoke(meta)
    assert_first_mention_default_metadata(meta)
    assert_referential_clarity_default_metadata(meta)
    assert_visibility_pass_metadata(meta)
    assert_first_mention_pass_metadata(meta)
    assert_referential_clarity_pass_metadata(meta)


def test_pipeline_referential_clarity_allows_single_named_referent_followed_by_pronoun():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = "Guard Captain leans closer. He studies your face."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    assert out["player_facing_text"] == candidate
    meta = final_emission_meta_from_output(out)
    assert_referential_clarity_pass_metadata(meta, include_default_shape=True, violation_kinds=[])
    assert "referential_clarity_enforcement_replaced" not in out["tags"]


def test_pipeline_referential_clarity_allows_singular_they_for_single_local_person_referent():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = "Guard Captain leans closer. Their voice drops to a whisper."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    assert out["player_facing_text"] == candidate
    meta = final_emission_meta_from_output(out)
    assert_referential_clarity_pass_metadata(meta, include_default_shape=True, violation_kinds=[])


def test_pipeline_referential_clarity_replaces_same_sentence_ambiguous_pronoun():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = "Guard Captain and Tavern Runner trade hard looks. He steps forward."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    assert out["player_facing_text"] != candidate
    meta = final_emission_meta_from_output(out)
    assert_referential_clarity_replacement_metadata(meta, violation_kind="ambiguous_entity_reference")
    assert "referential_clarity_enforcement_replaced" in out["tags"]
    assert "referential_clarity_violation:ambiguous_entity_reference" in out["tags"]


def test_pipeline_referential_clarity_replaces_next_sentence_ambiguous_pronoun():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = "Guard Captain speaks with Tavern Runner near the brazier. He lowers his voice."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    assert out["player_facing_text"] != candidate
    meta = final_emission_meta_from_output(out)
    assert_referential_clarity_replacement_metadata(meta, violation_kind="ambiguous_entity_reference")


def test_pipeline_referential_clarity_allows_explicit_reanchor():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = "Guard Captain and Tavern Runner trade hard looks. Guard Captain steps forward."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    assert out["player_facing_text"] == candidate
    meta = final_emission_meta_from_output(out)
    assert_referential_clarity_pass_metadata(meta)


def test_pipeline_referential_clarity_allows_descriptor_reanchor_when_unique():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = "Guard Captain and Tavern Runner argue near the gate. The captain steps closer."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    meta = final_emission_meta_from_output(out)
    assert out["player_facing_text"] == candidate
    assert_referential_clarity_pass_metadata(meta, include_default_shape=True, violation_kinds=[])


def test_pipeline_referential_clarity_replaces_ambiguous_descriptor_reanchor():
    session, world, scene, _sid = _visibility_bundle_with_extra_addressables(
        {
            "id": "left_guard",
            "name": "Left Guard",
            "scene_id": "frontier_gate",
            "kind": "scene_actor",
            "addressable": True,
            "address_priority": 4,
            "address_roles": ["guard"],
            "aliases": ["left guard"],
        }
    )
    candidate = "Two guards block the way. The guard taps the pommel of a sheathed sword."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    meta = final_emission_meta_from_output(out)
    assert out["player_facing_text"] != candidate
    assert_referential_clarity_replacement_metadata(
        meta,
        include_default_shape=True,
        violation_kind="ambiguous_entity_reference",
    )
    assert "referential_clarity_enforcement_replaced" in out["tags"]


def test_pipeline_referential_clarity_allows_unique_nonperson_pronoun():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = "Guard Captain stands near the gate holding the lantern. Its light catches the rain."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    meta = final_emission_meta_from_output(out)
    assert out["player_facing_text"] == candidate
    assert_referential_clarity_pass_metadata(meta, include_default_shape=True)


def test_pipeline_referential_clarity_replaces_ambiguous_nonperson_pronoun():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = "Guard Captain sets the lantern beside the note. It glints in the dark."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    meta = final_emission_meta_from_output(out)
    assert out["player_facing_text"] != candidate
    assert_referential_clarity_replacement_metadata(
        meta,
        include_default_shape=True,
        violation_kind="ambiguous_entity_reference",
    )
    assert "referential_clarity_enforcement_replaced" in out["tags"]


def test_pipeline_referential_clarity_replaces_neuter_pronoun_in_person_only_context():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = "The captain stands near the gate with the courier. It sways in the rain."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    meta = final_emission_meta_from_output(out)
    assert out["player_facing_text"] != candidate
    assert_referential_clarity_replacement_metadata(meta, violation_kind="ambiguous_entity_reference")


def test_pipeline_referential_clarity_allows_clear_quoted_speaker_tag():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = 'Guard Captain stands near the gate. "Open the gate," he says.'

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    meta = final_emission_meta_from_output(out)
    assert out["player_facing_text"] == candidate
    assert_referential_clarity_pass_metadata(meta, include_default_shape=True)


def test_pipeline_referential_clarity_replaces_ambiguous_quoted_speaker_tag():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = 'Guard Captain and Tavern Runner stand near the gate. "Back away," he says.'

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    meta = final_emission_meta_from_output(out)
    assert out["player_facing_text"] != candidate
    assert_referential_clarity_replacement_metadata(meta, violation_kind="ambiguous_entity_reference")
    assert "referential_clarity_enforcement_replaced" in out["tags"]


def test_pipeline_referential_clarity_replaces_referent_drift_after_new_competitor():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = "Guard Captain leans closer. Tavern Runner answers from the doorway. He folds his arms."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    assert out["player_facing_text"] != candidate
    meta = final_emission_meta_from_output(out)
    assert_referential_clarity_replacement_metadata(
        meta,
        violation_kinds_any=("referent_drift", "ambiguous_entity_reference"),
    )


def test_pipeline_referential_clarity_replaces_singular_they_with_multiple_active_person_candidates():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = "Guard Captain and Tavern Runner watch you closely. Their voices stay low."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    meta = final_emission_meta_from_output(out)
    assert out["player_facing_text"] != candidate
    assert_referential_clarity_replacement_metadata(
        meta,
        include_default_shape=True,
        violation_kind="ambiguous_entity_reference",
    )
    assert "referential_clarity_enforcement_replaced" in out["tags"]


def test_pipeline_referential_clarity_metadata_shape_always_present_on_pass():
    session, world, scene, _sid = _base_visibility_bundle()
    candidate = "Guard Captain leans closer. He studies your face."

    out = _finalize_via_turn_support(candidate, session=session, world=world, scene=scene)

    meta = final_emission_meta_from_output(out)
    assert_referential_clarity_default_metadata(meta)
    assert isinstance(meta["referential_clarity_checked_entities"], list)
    assert isinstance(meta["referential_clarity_violation_sample"], list)


def test_validate_player_facing_referential_clarity_records_referent_drift():
    session, world, scene, _sid = _base_visibility_bundle()
    result = validate_player_facing_referential_clarity(
        "Guard Captain leans closer. Tavern Runner answers from the doorway. He folds his arms.",
        session=session,
        scene=scene,
        world=world,
    )

    kinds = [v.get("kind") for v in result["violations"] if isinstance(v, dict)]
    assert "referent_drift" in kinds


def test_validate_player_facing_first_mentions_pronoun_before_explicit_entity():
    session, world, scene, _sid = _base_visibility_bundle()
    result = validate_player_facing_first_mentions(
        "He leans in. Guard Captain watches the road.",
        session=session,
        scene=scene,
        world=world,
    )
    kinds = [v.get("kind") for v in result["violations"] if isinstance(v, dict)]
    assert "pronoun_before_first_explicit_entity" in kinds


def test_validate_player_facing_first_mentions_unearned_familiarity():
    session, world, scene, _sid = _base_visibility_bundle()
    result = validate_player_facing_first_mentions(
        "You recognize Guard Captain immediately.",
        session=session,
        scene=scene,
        world=world,
    )
    kinds = [v.get("kind") for v in result["violations"] if isinstance(v, dict)]
    assert "first_mention_unearned_familiarity" in kinds


def test_validate_player_facing_first_mentions_accepts_grounded_intro():
    session, world, scene, _sid = _base_visibility_bundle()
    result = validate_player_facing_first_mentions(
        "Guard Captain stands near the gate.",
        session=session,
        scene=scene,
        world=world,
    )
    assert result["ok"] is True


def test_validate_player_facing_first_mentions_accepts_opening_scene_sentence_grounded_by_opener_and_action():
    session, world, scene, _sid = _base_visibility_bundle()
    result = validate_player_facing_first_mentions(
        (
            "Nearby, cart wheels hiss over the wet stones while vendors shout under the awning, "
            "and Guard Captain calls for the line to keep moving at the gate."
        ),
        session=session,
        scene=scene,
        world=world,
    )
    assert result["ok"] is True


@pytest.mark.parametrize(
    "candidate",
    [
        "Guard Captain is there.",
        "Tavern Runner is present.",
    ],
)
def test_validate_player_facing_first_mentions_rejects_vague_presence_only_openings(candidate: str):
    session, world, scene, _sid = _base_visibility_bundle()
    result = validate_player_facing_first_mentions(
        candidate,
        session=session,
        scene=scene,
        world=world,
    )
    kinds = [v.get("kind") for v in result["violations"] if isinstance(v, dict)]
    assert "first_mention_missing_grounding" in kinds


def test_sentence_decompression_splits_semicolon_alternatives():
    text = (
        "Off to Galinor's left, two alleyways present themselves; "
        "one is narrow and shadowy, the other wider and lively, leading toward the tavern."
    )
    out = _decompress_overpacked_sentences(text)

    assert "; one is narrow and shadowy" not in out.lower()
    assert out.count(".") >= 3
    assert "two alleyways present themselves" in out.lower()
    assert "narrow and shadowy" in out.lower()
    assert "wider and lively" in out.lower()


def test_sentence_decompression_splits_long_participial_tail():
    text = (
        "Nearby, the tavern runner energetically shouts offers of warm stew above the rain-slick crowd as wagons creak "
        "through the gate, hinting at deeper tensions surrounding the missing patrol."
    )
    out = _decompress_overpacked_sentences(text)

    assert ", hinting at deeper tensions surrounding the missing patrol" not in out.lower()
    assert out.count(".") >= 2
    assert "tavern runner" in out.lower()
    assert "missing patrol" in out.lower()


def test_fragmentary_participial_split_repair_anchors_to_previous_sentence():
    text = (
        "Nearby, a tavern runner calls out urgently. "
        "Offering both warm stew and rumors, their voice cutting through the din."
    )
    repaired, applied = _repair_fragmentary_participial_splits(text)

    assert applied is True
    assert "They offer both warm stew and rumors." in repaired
    assert "Their voice cuts through the din." in repaired


def test_fragmentary_participial_split_repair_uses_sparse_it_subject_for_hinting():
    text = "The rain taps steadily on the awning. Hinting at trouble just beyond the square."
    repaired, applied = _repair_fragmentary_participial_splits(text)

    assert applied is True
    assert "It hints at trouble just beyond the square." in repaired


def test_fragmentary_participial_split_repair_preserves_uncertain_suggesting_clause():
    text = "A stranger watches from the edge of the crowd. Suggesting he knows more than he says."
    repaired, applied = _repair_fragmentary_participial_splits(text)

    assert applied is False
    assert repaired == text


def test_final_emission_gate_does_not_export_sentence_micro_smooth_helper() -> None:
    import game.final_emission_gate as feg

    assert not hasattr(feg, "_micro_smooth_post_repair_sentences")


def test_finalization_pipeline_metadata_for_micro_smoothing():
    session, world, scene, _sid = _base_visibility_bundle()
    repaired_candidate = (
        "Nearby, a tavern runner calls out urgently, offering both warm stew and rumors, their voice cutting."
    )
    repaired_out = _finalize_via_turn_support(
        repaired_candidate,
        session=session,
        world=world,
        scene=scene,
    )
    fem = final_emission_meta_from_output(repaired_out)
    assert fem["sentence_decompression_applied"] is False
    assert fem["sentence_fragment_repair_applied"] is False
    assert fem["sentence_micro_smoothing_applied"] is False
    assert fem.get("final_emission_boundary_semantic_repair_disabled") is True

    plain_out = _finalize_via_turn_support(
        "Guard Captain stands near the gate.",
        session=session,
        world=world,
        scene=scene,
    )
    assert final_emission_meta_from_output(plain_out)["sentence_decompression_applied"] is False
    assert final_emission_meta_from_output(plain_out)["sentence_fragment_repair_applied"] is False
    assert final_emission_meta_from_output(plain_out)["sentence_micro_smoothing_applied"] is False


# --- Appended global-visibility stock stripping (last-mile finalization ownership) ---


def test_strip_appended_global_visibility_stock_multi_sentence_trailing():
    raw = (
        "The clerk taps the ledger. "
        "For a breath, the scene holds while voices shift around you."
    )
    stripped = emission_finalize.strip_appended_route_illegal_contamination_sentences(raw)
    assert stripped == "The clerk taps the ledger."


def test_strip_appended_global_visibility_stock_alt_sentence_variant():
    raw = "Fog hugs the river tents. For a breath, the scene stays still."
    assert emission_finalize.strip_appended_route_illegal_contamination_sentences(raw) == "Fog hugs the river tents."


def test_strip_placeholder_stock_single_sentence_output_unchanged():
    solo = "For a breath, the scene stays still."
    assert emission_finalize.strip_appended_route_illegal_contamination_sentences(solo) == solo


def test_strip_preserves_dialogue_sentence_containing_for_a_breath_stock_phrase():
    text = 'The runner shrugs. "For a breath, the scene stays still," she adds with a smirk.'
    assert emission_finalize.strip_appended_route_illegal_contamination_sentences(text) == text


def test_strip_preserves_interruption_setup_strips_only_trailing_stock_sentence():
    intr = (
        "The clerk starts to answer, but a shout from the square cuts across the room. "
        "For a breath, the scene holds while voices shift around you."
    )
    out = emission_finalize.strip_appended_route_illegal_contamination_sentences(intr)
    assert "shout from the square" in out.lower()
    assert "voices shift around you" not in out.lower()


def test_strip_preserves_paragraph_break_when_stripping_within_second_block():
    raw = "First block line.\n\nSecond block body. For a breath, the scene stays still."
    got = emission_finalize.strip_appended_route_illegal_contamination_sentences(raw)
    assert "\n\n" in got
    assert "First block line." in got
    assert "Second block body." in got
    assert "scene stays still" not in got.lower()


def test_strip_does_not_remove_unrelated_multi_sentence_atmosphere():
    raw = (
        "Mist threads between the tents. "
        "Somewhere a dog barks once, and the sound thins in damp air."
    )
    assert emission_finalize.strip_appended_route_illegal_contamination_sentences(raw) == raw


def test_finalize_emission_output_post_containment_reseals_appended_stock(monkeypatch):
    """Block I containment can revert to selector text after exit fingerprinting; stock strip must still win."""
    selector = (
        "Rain drums steady on the slate roof above. "
        "For a breath, the scene stays still."
    )
    out = {
        "player_facing_text": selector,
        "_final_emission_meta": {"final_route": "accept_candidate"},
        "tags": [],
        "metadata": {},
    }

    def _simulate_containment_revert(o: dict, **kwargs):
        o["player_facing_text"] = selector
        return False

    monkeypatch.setattr(
        emission_finalize,
        "finalize_upstream_fallback_overwrite_containment",
        _simulate_containment_revert,
    )
    pre = _normalize_text(selector)
    finalized = emission_finalize.finalize_emission_output(out, pre_gate_text=pre, fast_path=True)
    pft = (finalized.get("player_facing_text") or "").lower()
    assert "rain drums" in pft
    assert "scene stays still" not in pft
    fem = final_emission_meta_from_output(finalized) or {}
    lineage = fem.get("final_emission_mutation_lineage")
    assert "finalize_route_illegal_strip" in lineage
    assert "finalize_packaging" in lineage
    assert "post_gate_mutation_detected" in lineage


def test_visibility_safe_fallback_final_emitted_source_snapshot() -> None:
    """Visibility replace uses sealed tuples for text; FEM source pins global_scene_fallback today."""
    session, world, scene, sid = _base_visibility_bundle()
    out = apply_final_emission_gate(
        {"player_facing_text": "Lord Aldric watches the checkpoint from the square.", "tags": []},
        resolution={"kind": "observe", "prompt": "I look."},
        session=session,
        scene_id=sid,
        world=world,
        scene=scene,
    )
    tl = [str(t) for t in (out.get("tags") or []) if isinstance(t, str)]
    assert "visibility_enforcement_replaced" in tl
    fem = final_emission_meta_from_output(out)
    assert_final_emission_meta_contains(
        fem,
        final_route="replaced",
        final_emitted_source="global_scene_fallback",
    )
    assert fem.get(REALIZATION_FALLBACK_FAMILY_FIELD) == GATE_TERMINAL_REPAIR
    assert_sealed_fallback_owner_bucket(fem, SEALED_FALLBACK_OWNER_SEALED_GATE)
