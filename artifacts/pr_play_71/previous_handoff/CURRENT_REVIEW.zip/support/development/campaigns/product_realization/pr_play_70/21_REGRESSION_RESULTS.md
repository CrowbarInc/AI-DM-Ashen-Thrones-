# REGRESSION RESULTS

{
  "focused": {
    "label": "focused",
    "collected": 1004,
    "failed": 4,
    "errors": 0,
    "skipped": 0,
    "passed": 1000,
    "exit_code": 1,
    "failed_nodeids": [
      "tests.test_pr_play_66_publication::test_publication_http[rejected]",
      "tests.test_provider_accounting_integrity::test_readiness_acceptance_is_not_live_execution",
      "tests.test_narration_state_consistency::test_refusal_text_with_location_repair_updates_state_and_clues",
      "tests.test_narration_state_consistency::test_usable_location_in_text_updates_structured_topic_and_clues"
    ],
    "failure_messages": [
      {
        "nodeid": "tests.test_pr_play_66_publication::test_publication_http[rejected]",
        "message": "AssertionError: {\"ok\":false,\"error\":\"Unable to complete this request. Refresh your session and try again.\"}\nassert 500 == 200\n +  where 500 = <Response [500 Internal Server Error]>.status_code"
      },
      {
        "nodeid": "tests.test_provider_accounting_integrity::test_readiness_acceptance_is_not_live_execution",
        "message": "assert False"
      },
      {
        "nodeid": "tests.test_narration_state_consistency::test_refusal_text_with_location_repair_updates_state_and_clues",
        "message": "assert set()\n +  where set() = get_all_known_clue_ids({})"
      },
      {
        "nodeid": "tests.test_narration_state_consistency::test_usable_location_in_text_updates_structured_topic_and_clues",
        "message": "assert set()\n +  where set() = get_all_known_clue_ids({})"
      }
    ],
    "command": [
      "C:\\Users\\Master Mandalcio\\Documents\\Tabletop Gaming\\AI Dungeon Master\\ashen_thrones_ai_gm\\.venv\\Scripts\\python.exe",
      "-m",
      "pytest",
      "tests/test_pr_play_66_publication.py",
      "tests/test_pr_play_65_authoritative_disclosure.py",
      "tests/test_pr_play_64_discovery_language.py",
      "tests/test_pr_play_63_disclosure.py",
      "tests/test_state_authority.py",
      "tests/test_pr_play_61_player_facing.py",
      "tests/test_pr_play_62_investigation_quality.py",
      "tests/test_pr_play_60_inventory_projection.py",
      "tests/test_pr_play_60_gameplay_readiness.py",
      "tests/test_pr_play_59_persistent_consequences.py",
      "tests/test_pr_play_57_integrated_narration.py",
      "tests/test_pr_play_58_semantic_coverage.py",
      "tests/test_pr_play_55_discovery_claims.py",
      "tests/test_pr_play_54_consequential_validation.py",
      "tests/test_pr_play_53_quarantined_live.py",
      "tests/test_pr_play_52_quarantined_integration.py",
      "tests/test_pr_play_42_evidence_boundaries.py",
      "tests/test_pr_play_51_geography_grounding.py",
      "tests/test_pr_play_49_anchored_narration.py",
      "tests/test_pr_play_47_controlled_renderer.py",
      "tests/test_pr_play_45_narration_authority.py",
      "tests/test_pr_play_46_mechanical_boundary.py",
      "tests/test_pr_play_44_information_delivery.py",
      "tests/test_pr_bu_lexical_scope.py",
      "tests/test_provider_accounting_integrity.py",
      "tests/test_pr_bw_narration_only_envelope.py",
      "tests/test_diegetic_fallback_narration.py",
      "tests/test_narration_state_consistency.py",
      "tests/test_pr_play_68_structured_publication.py",
      "tests/test_pr_play_69_target_references.py",
      "--tb=line",
      "--junitxml=C:\\Users\\Master Mandalcio\\Documents\\Tabletop Gaming\\AI Dungeon Master\\ashen_thrones_ai_gm\\artifacts\\pr_play_70\\focused_final.xml",
      "--basetemp",
      "C:\\Users\\Master Mandalcio\\Documents\\Tabletop Gaming\\AI Dungeon Master\\ashen_thrones_ai_gm\\development\\tmp\\pr_play_66_focused_11172"
    ],
    "provider_calls": "disabled"
  },
  "boundary": {
    "label": "boundary",
    "collected": 82,
    "failed": 0,
    "errors": 0,
    "skipped": 0,
    "passed": 82,
    "exit_code": 0,
    "failed_nodeids": [],
    "failure_messages": [],
    "command": [
      "C:\\Users\\Master Mandalcio\\Documents\\Tabletop Gaming\\AI Dungeon Master\\ashen_thrones_ai_gm\\.venv\\Scripts\\python.exe",
      "-m",
      "pytest",
      "tests/test_pr_play_67_player_projection.py",
      "tests/test_ui_mode_backend_integration.py",
      "tests/test_ui_mode_regression_matrix_objective15.py",
      "tests/test_frontend_ui_mode_hardening_objective15.py",
      "tests/test_state_channels.py",
      "tests/test_snapshots.py",
      "--tb=line",
      "--junitxml=C:\\Users\\Master Mandalcio\\Documents\\Tabletop Gaming\\AI Dungeon Master\\ashen_thrones_ai_gm\\artifacts\\pr_play_70\\boundary_final.xml",
      "--basetemp",
      "C:\\Users\\Master Mandalcio\\Documents\\Tabletop Gaming\\AI Dungeon Master\\ashen_thrones_ai_gm\\development\\tmp\\pr_play_66_boundary_11172"
    ],
    "provider_calls": "disabled"
  },
  "broader": {
    "label": "broader",
    "collected": 9,
    "failed": 9,
    "errors": 0,
    "skipped": 0,
    "passed": 0,
    "exit_code": 1,
    "failed_nodeids": [
      "tests.test_pr_cx_authority_assurance::test_pr_cx_rejects_inherited_objective_authority_violations[biography-The guard captain was born in Blackharbor and served for twenty years.-biography]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_rejects_inherited_objective_authority_violations[geography-The old milestone lies east beyond the trading crossroads.-geography]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_rejects_inherited_objective_authority_violations[hidden_information-A secret tunnel runs beneath the gate into the keep.-hidden_information]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_rejects_inherited_objective_authority_violations[npc_action-The captain unlocks the gate and lets you pass.-npc_action]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_rejects_inherited_objective_authority_violations[discovery-You discover a hidden map beneath the notice board.-discovery]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_preserves_harmless_dialogue_and_grounded_observation[preference-The guard captain says, \"I prefer a dry watch.\"]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_preserves_harmless_dialogue_and_grounded_observation[opinion-The guard captain says, \"I like the square best after rain.\"]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_preserves_harmless_dialogue_and_grounded_observation[incidental_characterization-The guard captain shrugs and nods.]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_preserves_harmless_dialogue_and_grounded_observation[grounded_observation-A notice board lists new taxes, curfews, and a posted warning about a missing patrol.]"
    ],
    "failure_messages": [
      {
        "nodeid": "tests.test_pr_cx_authority_assurance::test_pr_cx_rejects_inherited_objective_authority_violations[biography-The guard captain was born in Blackharbor and served for twenty years.-biography]",
        "message": "KeyError: 'hard_validation_attempt_1'"
      },
      {
        "nodeid": "tests.test_pr_cx_authority_assurance::test_pr_cx_rejects_inherited_objective_authority_violations[geography-The old milestone lies east beyond the trading crossroads.-geography]",
        "message": "KeyError: 'hard_validation_attempt_1'"
      },
      {
        "nodeid": "tests.test_pr_cx_authority_assurance::test_pr_cx_rejects_inherited_objective_authority_violations[hidden_information-A secret tunnel runs beneath the gate into the keep.-hidden_information]",
        "message": "KeyError: 'hard_validation_attempt_1'"
      },
      {
        "nodeid": "tests.test_pr_cx_authority_assurance::test_pr_cx_rejects_inherited_objective_authority_violations[npc_action-The captain unlocks the gate and lets you pass.-npc_action]",
        "message": "KeyError: 'hard_validation_attempt_1'"
      },
      {
        "nodeid": "tests.test_pr_cx_authority_assurance::test_pr_cx_rejects_inherited_objective_authority_violations[discovery-You discover a hidden map beneath the notice board.-discovery]",
        "message": "KeyError: 'hard_validation_attempt_1'"
      },
      {
        "nodeid": "tests.test_pr_cx_authority_assurance::test_pr_cx_preserves_harmless_dialogue_and_grounded_observation[preference-The guard captain says, \"I prefer a dry watch.\"]",
        "message": "KeyError: 'hard_validation_attempt_1'"
      },
      {
        "nodeid": "tests.test_pr_cx_authority_assurance::test_pr_cx_preserves_harmless_dialogue_and_grounded_observation[opinion-The guard captain says, \"I like the square best after rain.\"]",
        "message": "KeyError: 'hard_validation_attempt_1'"
      },
      {
        "nodeid": "tests.test_pr_cx_authority_assurance::test_pr_cx_preserves_harmless_dialogue_and_grounded_observation[incidental_characterization-The guard captain shrugs and nods.]",
        "message": "KeyError: 'hard_validation_attempt_1'"
      },
      {
        "nodeid": "tests.test_pr_cx_authority_assurance::test_pr_cx_preserves_harmless_dialogue_and_grounded_observation[grounded_observation-A notice board lists new taxes, curfews, and a posted warning about a missing patrol.]",
        "message": "KeyError: 'hard_validation_attempt_1'"
      }
    ],
    "command": [
      "C:\\Users\\Master Mandalcio\\Documents\\Tabletop Gaming\\AI Dungeon Master\\ashen_thrones_ai_gm\\.venv\\Scripts\\python.exe",
      "-m",
      "pytest",
      "tests/test_pr_cx_authority_assurance.py",
      "--tb=line",
      "--junitxml=C:\\Users\\Master Mandalcio\\Documents\\Tabletop Gaming\\AI Dungeon Master\\ashen_thrones_ai_gm\\artifacts\\pr_play_70\\broader_final.xml",
      "--basetemp",
      "C:\\Users\\Master Mandalcio\\Documents\\Tabletop Gaming\\AI Dungeon Master\\ashen_thrones_ai_gm\\development\\tmp\\pr_play_66_broader_11172"
    ],
    "provider_calls": "disabled"
  },
  "new_focused_failures": [
    "tests.test_pr_play_66_publication::test_publication_http[rejected]"
  ],
  "restored": [
    "artifacts/pr_play_49/evidence_actual_failed_known.json",
    "artifacts/pr_play_49/evidence_corpus_condition.json",
    "artifacts/pr_play_49/evidence_corpus_contradiction.json",
    "artifacts/pr_play_49/evidence_corpus_passage.json",
    "artifacts/pr_play_49/evidence_fixture_bridge.json",
    "artifacts/pr_play_49/evidence_fixture_campsite.json",
    "artifacts/pr_play_49/evidence_fixture_chamber.json",
    "artifacts/pr_play_49/evidence_fixture_frontier_gate.json",
    "artifacts/pr_play_49/evidence_fixture_ledger.json",
    "artifacts/pr_play_49/evidence_fixture_monument.json",
    "artifacts/pr_play_49/evidence_fixture_old_milestone.json",
    "artifacts/pr_play_49/evidence_fixture_testimony.json",
    "artifacts/pr_play_49/evidence_performance.json",
    "artifacts/pr_play_47/evidence_actual_failed_repeat.json",
    "artifacts/pr_play_47/evidence_isolation.json",
    "artifacts/pr_play_47/evidence_performance.json",
    "artifacts/pr_play_47/evidence_scenario_failed.json",
    "artifacts/pr_play_47/evidence_scenario_frontier_gate.json",
    "artifacts/pr_play_47/evidence_scenario_known.json",
    "artifacts/pr_play_47/evidence_scenario_mundane.json",
    "artifacts/pr_play_47/evidence_scenario_no_clue.json",
    "artifacts/pr_play_47/evidence_scenario_npc.json",
    "artifacts/pr_play_47/evidence_scenario_old_milestone.json",
    "artifacts/pr_play_47/evidence_scenario_partial.json",
    "artifacts/pr_play_47/evidence_scenario_success.json",
    "artifacts/pr_play_47/evidence_scenario_uncertain.json",
    "artifacts/pr_play_52/integration_results.json"
  ]
}

Comparison and transient rerun: {
  "focused": {
    "passed": 1000,
    "failed": 4,
    "historical_failures": [
      "tests.test_narration_state_consistency::test_refusal_text_with_location_repair_updates_state_and_clues",
      "tests.test_narration_state_consistency::test_usable_location_in_text_updates_structured_topic_and_clues",
      "tests.test_provider_accounting_integrity::test_readiness_acceptance_is_not_live_execution"
    ],
    "newly_observed": [
      "tests.test_pr_play_66_publication::test_publication_http[rejected]"
    ],
    "resolved_historical": []
  },
  "boundary": {
    "passed": 82,
    "failed": 0,
    "historical_failures": [],
    "newly_observed": [],
    "resolved_historical": []
  },
  "broader": {
    "passed": 0,
    "failed": 9,
    "historical_failures": [
      "tests.test_pr_cx_authority_assurance::test_pr_cx_preserves_harmless_dialogue_and_grounded_observation[grounded_observation-A notice board lists new taxes, curfews, and a posted warning about a missing patrol.]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_preserves_harmless_dialogue_and_grounded_observation[incidental_characterization-The guard captain shrugs and nods.]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_preserves_harmless_dialogue_and_grounded_observation[opinion-The guard captain says, \"I like the square best after rain.\"]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_preserves_harmless_dialogue_and_grounded_observation[preference-The guard captain says, \"I prefer a dry watch.\"]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_rejects_inherited_objective_authority_violations[biography-The guard captain was born in Blackharbor and served for twenty years.-biography]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_rejects_inherited_objective_authority_violations[discovery-You discover a hidden map beneath the notice board.-discovery]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_rejects_inherited_objective_authority_violations[geography-The old milestone lies east beyond the trading crossroads.-geography]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_rejects_inherited_objective_authority_violations[hidden_information-A secret tunnel runs beneath the gate into the keep.-hidden_information]",
      "tests.test_pr_cx_authority_assurance::test_pr_cx_rejects_inherited_objective_authority_violations[npc_action-The captain unlocks the gate and lets you pass.-npc_action]"
    ],
    "newly_observed": [],
    "resolved_historical": []
  },
  "transient_retested": {
    "nodeid": "tests.test_pr_play_66_publication::test_publication_http[rejected]",
    "reason": "Windows PermissionError WinError 5 on os.replace of isolated temporary session file",
    "rerun": "artifacts/pr_play_70/regression_diagnose.txt",
    "result": "PASS without source changes"
  },
  "unresolved_new_product_regressions": []
}

Historical baseline: focused 893 passed/3 failures; boundary 82 passed; broader 9 failures. Current focused lane adds PR68/69 suites. No official ATGB or full suite. Historical generated artifacts restored by established regression harness. See exact failed node IDs; do not infer that every broader failure is historical without comparison.
